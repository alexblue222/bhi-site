"""base_api — the host surface the (free) keyboard base exposes to paid expansion modules.

Soft discovery (no hard imports between extensions — the `bl_ext.<repo>.<id>` path
varies by install location, so importing the base by name is fragile):

  - The base, on register(), publishes a BaseAPI instance into
    `bpy.app.driver_namespace["base_api"]`.
  - A guest module, at its OWN register(), calls `connect(info)`. If the base is
    already up it registers immediately; if not, it queues in
    `["base_api_pending"]` and the base drains that queue when it comes up. So
    either load order works.
  - A guest degrades gracefully (shows "requires Base Plugin") when `get()` is None.

Source of truth is ALWAYS Blender. get_actions() is a live scan, never a store; the
paid Action DB mirrors it into SQLite for curation but never becomes authoritative.

v2 surface is deliberately small: get_actions, the hotkey service (assign/clear/
get_bindings), and the module registry. UI-mount helpers wait until the Pie Builder
exists to validate them (an API needs a consumer to be designed right).
"""
import bpy

from . import keymap_engine as engine

API_VERSION = (1, 1)  # 1.1: native-override edit surface (rebind/disable/restore + consent)

_DNS_KEY = "base_api"
_PENDING_KEY = "base_api_pending"


class BaseAPI:
    API_VERSION = API_VERSION

    def __init__(self):
        self._modules = {}   # module_id -> info dict

    # --- shared GPU widget toolkit (so guest GPU modules don't reinvent it) ---
    def widgets(self):
        """The base's gpu_widgets module (TextField, draw_button/toggle, rect/text,
        hit). Guest modules call this instead of importing the base by name (which
        breaks across install repos)."""
        from . import gpu_widgets
        return gpu_widgets

    # --- shared scan primitive (live; Blender is source of truth) -------------
    def get_actions(self, refresh=False):
        """All registered operators as {idname,label,desc,source}. The one list
        every expansion pulls from. refresh=True forces a re-enumeration."""
        if refresh:
            engine.invalidate_catalog()
        return engine.catalog()

    def source_of(self, idname):
        return engine.source_of_idname(idname)

    # --- hotkey service (persisted + context-correct, owned by the base) ------
    def assign(self, idname, key_type, ctrl=False, alt=False, shift=False, mode=None, override=False):
        """Add an addon-kc binding (the isolated/reversible path). With override=True,
        if key+mods is already bound NATIVELY (user kc), retarget that native kmi to
        `idname` in place instead — an invasive edit, so it needs consent. Falls back
        to a plain addon-kc assign when there's no native binding to override."""
        # Note: override/conflict-resolution for an already-occupied key is handled in
        # the inspector — a key Blender binds many times (across keymaps + event values)
        # can't be cleanly auto-taken-over here. This adds the binding; empty combos work
        # immediately, conflicts surface in the keyboard/inspector for the user to resolve.
        return engine.assign(idname, key_type, ctrl=ctrl, alt=alt, shift=shift, mode=mode)

    def clear(self, key_type, ctrl=False, alt=False, shift=False, mode=None):
        return engine.clear_assignment(key_type, ctrl=ctrl, alt=alt, shift=shift, mode=mode)

    # --- native overrides (USER keyconfig; invasive, reversible, consent-gated) ---
    def rebind(self, key_type, ctrl, alt, shift,
               new_key_type, new_ctrl=False, new_alt=False, new_shift=False, mode=None):
        """Move an existing native shortcut to a new key+mods (reversible)."""
        return engine.rebind_existing(bpy.context, key_type, ctrl, alt, shift,
                                      new_key_type, new_ctrl, new_alt, new_shift, mode=mode)

    def disable(self, key_type, ctrl=False, alt=False, shift=False, mode=None):
        """Disable an existing native shortcut in place (reversible)."""
        return engine.disable_binding(bpy.context, key_type, ctrl, alt, shift, mode=mode)

    def restore_one(self, key_type, ctrl=False, alt=False, shift=False, mode=None):
        """Restore one native shortcut we edited back to Blender's factory default."""
        return engine.restore_one(bpy.context, key_type, ctrl, alt, shift, mode=mode)

    def restore_all(self):
        """Restore every native shortcut we edited; clear the overrides store."""
        return engine.restore_all()

    def native_edits_consented(self):
        return engine.native_edits_consented()

    def set_native_edits_consented(self, value=True):
        return engine.set_native_edits_consented(value)

    def get_bindings(self):
        """The user's hotkey state: addon-kc persisted bindings PLUS our active native
        overrides (so the UI can flag which native keys we've edited)."""
        return {
            "bindings": engine.get_bindings(),
            "native_overrides": engine.list_overrides(),
        }

    # --- module registry (host/guest) ----------------------------------------
    def register_module(self, info):
        """Register a guest module. `info` is a dict; only `id` is required."""
        mid = (info or {}).get("id")
        if not mid:
            return False
        self._modules[mid] = info
        return True

    def unregister_module(self, module_id):
        self._modules.pop(module_id, None)

    def modules(self):
        return list(self._modules.values())


def get():
    """The live BaseAPI, or None if the base isn't loaded. Guests check this."""
    return bpy.app.driver_namespace.get(_DNS_KEY)


def connect(info):
    """Guest helper: call from a guest module's register(). Registers with the base
    if present, else queues until the base comes up. Returns the BaseAPI or None."""
    api = get()
    if api is not None:
        api.register_module(info)
        return api
    bpy.app.driver_namespace.setdefault(_PENDING_KEY, []).append(info)
    return None


def register():
    api = BaseAPI()
    bpy.app.driver_namespace[_DNS_KEY] = api
    # drain guests that loaded before us (load-order independence)
    for info in bpy.app.driver_namespace.get(_PENDING_KEY, []):
        api.register_module(info)
    bpy.app.driver_namespace[_PENDING_KEY] = []
    return api


def unregister():
    bpy.app.driver_namespace.pop(_DNS_KEY, None)
