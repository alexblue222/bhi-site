"""Standalone visual keyboard-shortcut editor — prototype.

v1 of the keyboard system for the modular plugin ecosystem. Built standalone
(no base_api / registry yet) so the visual + interaction model can be proven and
iterated fast. Will later be wrapped as the first dogfood module of the base.

Load for dev (no extension packaging yet): add the parent folder to sys.path,
`import keyboard_proto`, then `keyboard_proto.register()`.
"""

from . import key_icons
from . import keyboard_ui
from . import keymap_engine
from . import gpu_keyboard
from . import base_api


def register():
    base_api.register()   # publish base_api first so guests can discover it
    key_icons.init()
    keyboard_ui.register()
    gpu_keyboard.register()
    # re-apply the user's persisted hotkeys (base service). Deferred via a 0s timer
    # so the addon keyconfig is fully built before we write into it on startup.
    # Wrapped to return None — a timer callback returning a number reschedules itself.
    import bpy

    def _apply_once():
        keymap_engine.apply_persisted()
        return None
    bpy.app.timers.register(_apply_once, first_interval=0.0)


def unregister():
    keymap_engine.clear_all_ours()  # don't orphan our addon-kc bindings on reload
    gpu_keyboard.unregister()
    keyboard_ui.unregister()
    key_icons.cleanup()
    base_api.unregister()
