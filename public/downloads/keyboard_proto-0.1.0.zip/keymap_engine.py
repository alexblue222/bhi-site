"""Keymap logic engine for the visual keyboard-shortcut editor add-on.

Pure logic layer: read bindings, scan modifier combos, detect conflicts,
assign/clear bindings. No UI, no gpu, no previews.

Write-isolation choice
----------------------
We READ from `wm.keyconfigs.user` (the merged user keyconfig, which reflects
what the user actually has bound) but WRITE only to `wm.keyconfigs.addon`.
The addon keyconfig is isolated and reversible: Blender discards it when the
add-on is disabled, so our assignments never permanently mutate the user's
config and can't leave orphaned bindings behind. In v1 we never write to the
user keyconfig.

Conventions
-----------
- `key_type` is a Blender key enum string ('A', 'ONE', 'SLASH', ...).
- Modifier args are bools; kmi modifier fields are ints (0/1) -> compare via bool().
- A kmi "matches" a requested value if `kmi.value in {value, 'ANY'}`.
- All read paths are defensive: missing keyconfigs/keymaps return None or empty,
  never raise.
"""

import bpy
import os
import json

# Fallback keymap when a mode has no specific map. assign()/clear now resolve the
# target keymap from the active context mode (see _target_keymap) so a binding made
# while viewing Edit/Sculpt/Pose lands in that mode's keymap, not always 3D View.
_ADDON_KEYMAP_NAME = "3D View"
_ADDON_SPACE_TYPE = "VIEW_3D"

# Persisted-bindings file (base service): survives Blender restarts. Lives in the
# user CONFIG dir so it's the same path whether dev-loaded or installed as an
# extension. apply_persisted() re-applies these to the addon kc on load.
_BINDINGS_FILE = "bindings.json"
_BINDINGS_DIRNAME = "keyboard_proto"

# Native-overrides file: snapshots of native (user-kc) kmis we've edited in place,
# plus the one-time consent flag. SEPARATE from bindings.json because these touch
# Blender's REAL keymap (invasive, must be reversible) — keeping the stores apart
# means a corrupt/cleared overrides file can never poison our isolated addon-kc
# bindings. Shape: {"consented": bool, "edits": [<override record>, ...]}.
_OVERRIDES_FILE = "overrides.json"

_PRESS_VALUES = {"PRESS", "ANY"}

# Bindings WE created, tracked explicitly. The addon keyconfig is SHARED by every
# enabled add-on, so we must never clear/replace an item we didn't create. Each
# entry: (key_type, ctrl, alt, shift, idname). Session-scoped, which matches the
# lifetime of runtime-added addon-kc bindings (gone on Blender restart anyway).
# ponytail: a flat list, not a registry class — fine at this scale.
_OURS = []


def _ours_sig(km_name, key_type, ctrl, alt, shift):
    # km_name included so bindings in different keymaps (Mesh vs Object Mode) don't
    # collide in the "is this ours?" guard now that we write to per-mode keymaps.
    return (km_name, key_type, bool(ctrl), bool(alt), bool(shift))


def _is_ours(km_name, kmi):
    """True if this addon-kc kmi is one WE created (tracked in _OURS) — not another
    add-on's. Guards remove/rebind so we only delete our own bindings."""
    return _ours_sig(km_name, kmi.type, kmi.ctrl, kmi.alt, kmi.shift) in _OURS


# --- source attribution (which plugin owns a binding) ------------------------
# Blender doesn't tag binding ownership, so we attribute by keyconfig + operator
# namespace. User keyconfig => native Blender. Addon keyconfig => grouped by the
# operator id prefix; recognised prefixes map to pretty add-on names, the rest
# fall back to their namespace. ponytail: heuristic, but the only signal available.
NATIVE = "Blender"

_GENERIC_MODULES = {
    "object", "mesh", "transform", "view3d", "wm", "screen", "curve", "armature",
    "pose", "sculpt", "paint", "gpencil", "grease_pencil", "node", "anim", "render",
    "outliner", "uv", "image", "clip", "sequencer", "graph", "action", "nla", "mask",
    "ed", "ui", "console", "info", "text", "font", "lattice", "mball", "particle",
    "fluid", "rigidbody", "cloth", "constraint", "material", "texture", "world",
    "scene", "collection", "brush", "gizmogroup", "workspace", "preferences",
    "import_scene", "export_scene", "import_mesh", "export_mesh", "file", "asset",
    "camera", "light", "speaker", "surface", "marker", "buttons", "cachefile",
}

# group-key -> pretty add-on name (extend freely)
_KNOWN_ADDONS = {
    "node.nw": "Node Wrangler",
    "object.boolean": "BoolTool",
    "object.ml": "MachineTools",
    "nsolve": "nFlow",
    "retopoflow": "RetopoFlow",
    "hops": "Hard Ops",
    "mesh.hops": "Hard Ops",
    "bc": "BoxCutter",
    "mesh.bc": "BoxCutter",
}


def _group_key(idname):
    """A stable grouping key for an add-on binding, derived from the operator id."""
    parts = idname.split(".")
    ns = parts[0]
    if ns in _GENERIC_MODULES and len(parts) > 1:
        return f"{ns}.{parts[1].split('_')[0]}"  # e.g. object.boolean, node.nw
    return ns                                     # e.g. nsolve, hops, retopoflow


def _source_of(idname, kc_name):
    """Pretty source label for a binding. kc_name: 'user' -> Blender, else add-on."""
    if kc_name == "user":
        return NATIVE
    key = _group_key(idname)
    if key in _KNOWN_ADDONS:
        return _KNOWN_ADDONS[key]
    ns = idname.split(".")[0]
    if ns in _KNOWN_ADDONS:
        return _KNOWN_ADDONS[ns]
    if ns in _GENERIC_MODULES:
        # an add-on rebinding a native operator (no clean owner) -> catch-all
        return "Other"
    return ns.replace("_", " ").title()  # non-native namespace = likely a real add-on


def _src_ok(source, enabled_sources):
    return enabled_sources is None or source in enabled_sources


# --- internal helpers --------------------------------------------------------

def _user_kc():
    wm = getattr(bpy.context, "window_manager", None)
    if wm is None:
        return None
    return getattr(getattr(wm, "keyconfigs", None), "user", None)


def _addon_kc():
    wm = getattr(bpy.context, "window_manager", None)
    if wm is None:
        return None
    return getattr(getattr(wm, "keyconfigs", None), "addon", None)


def _is_kbd(kmi):
    return getattr(kmi, "map_type", None) == "KEYBOARD" and getattr(kmi, "active", False)


def _value_matches(kmi, value):
    return getattr(kmi, "value", None) in {value, "ANY"}


def _mods_match(kmi, ctrl, alt, shift):
    return (
        bool(kmi.ctrl) == bool(ctrl)
        and bool(kmi.alt) == bool(alt)
        and bool(kmi.shift) == bool(shift)
    )


def _prettify(idname):
    """Human label from an operator idname. Try bl_label, else titlecase tail."""
    try:
        module, _, op = idname.partition(".")
        fn = getattr(getattr(bpy.ops, module, None), op, None)
        if fn is not None:
            # rna_type.name carries the operator's bl_label
            label = fn.get_rna_type().name
            if label:
                return label
    except Exception:
        pass
    # ponytail: fallback prettifier; good enough when bl_label lookup is unavailable.
    return idname.split(".")[-1].replace("_", " ").strip().title() or idname


def _menu_label(menu_idname):
    """bl_label of a Menu/Panel class id, or the id itself."""
    cls = getattr(bpy.types, menu_idname, None)
    return getattr(cls, "bl_label", None) or menu_idname


def _label_for(kmi):
    """Best human label for a binding. Generic callers (call_menu/pie/panel) are
    near-useless on their own — append the actual menu/panel name from properties."""
    base = _prettify(kmi.idname)
    try:
        if kmi.idname in {"wm.call_menu", "wm.call_menu_pie", "wm.call_panel"}:
            nm = getattr(kmi.properties, "name", None)
            if nm:
                return f"{base}: {_menu_label(nm)}"
    except Exception:
        pass
    return base


def _desc_for(idname):
    """The operator's tooltip/description (plain-English 'what it does')."""
    try:
        module, _, op = idname.partition(".")
        fn = getattr(getattr(bpy.ops, module, None), op, None)
        if fn is not None:
            return fn.get_rna_type().description or ""
    except Exception:
        pass
    return ""


def _iter_user_kmis(context, key_type):
    """Yield active keyboard kmis matching key_type across the relevant keymaps.

    Scans BOTH the user keyconfig (existing/native bindings) and the addon
    keyconfig (our own assignments). This is deliberate: our assignments live in
    the addon kc, so reading both makes assigned keys light up as bound, and an
    assignment landing on an already-bound key naturally reads as a conflict
    (>1 match) — which is exactly the orange corner-light behaviour we want.
    """
    names = relevant_keymap_names(context)
    for kc_name, kc in (("user", _user_kc()), ("addon", _addon_kc())):
        if kc is None:
            continue
        for name in names:
            km = kc.keymaps.get(name)
            if km is None:
                continue
            for kmi in km.keymap_items:
                if not _is_kbd(kmi):
                    continue
                if getattr(kmi, "type", None) != key_type:
                    continue
                yield name, kmi, _source_of(kmi.idname, kc_name), kc_name


def _scan_key(context, key_type, enabled_sources=None):
    """One pass over all active keyboard bindings on `key_type`.

    Returns (combos, counts):
      combos: {(ctrl,alt,shift): {"idname","keymap","label","source"}} — first per combo
      counts: {(ctrl,alt,shift): int} — number of active bindings (for conflicts)
    Captures EVERY modifier combination, including multi-modifier ones (Ctrl+Shift+F).
    `enabled_sources` (a set of source labels) filters by plugin; None = all sources.
    """
    combos = {}
    counts = {}
    for name, kmi, src, _kc in _iter_user_kmis(context, key_type):
        if not _src_ok(src, enabled_sources):
            continue
        if not _value_matches(kmi, "PRESS"):
            continue
        sig = (bool(kmi.ctrl), bool(kmi.alt), bool(kmi.shift))
        counts[sig] = counts.get(sig, 0) + 1
        if sig not in combos:
            combos[sig] = {"idname": kmi.idname, "keymap": name,
                           "label": _label_for(kmi), "desc": _desc_for(kmi.idname),
                           "source": src}
    return combos, counts


# --- public API --------------------------------------------------------------

# View-mode override: lets the UI display a chosen context (Object/Edit/Sculpt…)
# regardless of Blender's live mode. None = follow the live context.mode.
# ponytail: module global instead of threading a param through every function.
_VIEW_MODE = None

# context label -> (mode key, extra keymaps layered on Window/Screen/3D View)
VIEW_MODES = [
    ("Object", "OBJECT", ["Object Mode", "Object Non-modal"]),
    ("Edit", "EDIT_MESH", ["Mesh"]),
    ("Sculpt", "SCULPT", ["Sculpt"]),
    ("Pose", "POSE", ["Pose"]),
    ("Paint", "PAINT_TEXTURE", ["Image Paint"]),
]
_MODE_KEYMAPS = {m: extra for _lbl, m, extra in VIEW_MODES}


def set_view_mode(mode):
    """Override which context's keymaps to show (a mode key, or None for live)."""
    global _VIEW_MODE
    _VIEW_MODE = mode


def get_view_mode():
    return _VIEW_MODE


def relevant_keymap_names(context):
    """Keymaps that apply to the chosen (or live) mode (only ones that exist)."""
    mode = _VIEW_MODE or getattr(context, "mode", None)
    names = ["Window", "Screen", "3D View"] + _MODE_KEYMAPS.get(mode, ["Object Mode", "Object Non-modal"])
    kc = _user_kc()
    if kc is None:
        return []
    return [n for n in names if kc.keymaps.get(n) is not None]


def _current_mode():
    """The mode bindings should target: the UI's view-mode override, else Blender's
    live mode. bpy.context.mode values ('OBJECT','EDIT_MESH','SCULPT',...) line up
    with the VIEW_MODES keys, so they map straight through."""
    if _VIEW_MODE:
        return _VIEW_MODE
    return getattr(bpy.context, "mode", None) or "OBJECT"


def _keymap_space_type(name):
    """Space type Blender uses for a keymap of this name (read from the user kc, the
    source of truth). Must match or kc.keymaps.new makes a stray non-merging map."""
    kc = _user_kc()
    km = kc.keymaps.get(name) if kc else None
    return getattr(km, "space_type", "EMPTY") if km else "EMPTY"


def _target_keymap(mode=None):
    """(keymap_name, space_type) a new binding for `mode` should be written to.
    Uses the mode's most-specific keymap (Mesh/Sculpt/Pose/Object Mode), so a
    binding made on a given context tab is active in that context — fixing the v1
    bug where every write went to '3D View' regardless of the tab being viewed."""
    mode = mode or _current_mode()
    name = _MODE_KEYMAPS.get(mode, [_ADDON_KEYMAP_NAME])[0]
    return name, _keymap_space_type(name)


def binding_for(context, key_type, ctrl, alt, shift, enabled_sources=None):
    """First active kmi matching key_type + exact modifiers + PRESS/ANY (+ source filter)."""
    for name, kmi, src, _kc in _iter_user_kmis(context, key_type):
        if not _src_ok(src, enabled_sources):
            continue
        if not _value_matches(kmi, "PRESS"):
            continue
        if not _mods_match(kmi, ctrl, alt, shift):
            continue
        return {
            "idname": kmi.idname,
            "keymap": name,
            "label": _label_for(kmi),
            "desc": _desc_for(kmi.idname),
            "source": src,
        }
    return None


def conflict_for(context, key_type, ctrl, alt, shift, enabled_sources=None):
    """True if >1 active kmi match the same key_type + modifiers + PRESS/ANY."""
    count = 0
    for _, kmi, src, _kc in _iter_user_kmis(context, key_type):
        if not _src_ok(src, enabled_sources):
            continue
        if not _value_matches(kmi, "PRESS"):
            continue
        if _mods_match(kmi, ctrl, alt, shift):
            count += 1
            if count > 1:
                return True
    return False


def bindings_at(context, key_type, ctrl, alt, shift, enabled_sources=None):
    """Every active kmi at this exact key+modifiers, in scan order. First entry is the
    one Blender most-likely fires; the rest are shadowed. Feeds the conflict tooltip
    ('what's bound doubly here'). ponytail: scan order ≈ resolution order — good enough
    for a debug readout; exact handler-stack winner is a deeper job if it ever matters."""
    out = []
    for name, kmi, src, kc_name in _iter_user_kmis(context, key_type):
        if not _src_ok(src, enabled_sources):
            continue
        if not _value_matches(kmi, "PRESS"):
            continue
        if not _mods_match(kmi, ctrl, alt, shift):
            continue
        out.append({"idname": kmi.idname, "keymap": name, "label": _label_for(kmi),
                    "source": src, "kc": kc_name, "ours": kc_name == "addon" and _is_ours(name, kmi)})
    return out


def key_state(context, key_type, active_mods, enabled_sources=None):
    """State of a key under the active modifier filter + modifier-participation variants.

    A variant dot lights if that modifier participates in ANY binding on the key, alone
    or combined — so a Ctrl+Shift+F binding lights both the Ctrl and Shift dots.
    `enabled_sources` filters to specific plugins; None = all.
    """
    ctrl = bool(active_mods.get("ctrl", False))
    alt = bool(active_mods.get("alt", False))
    shift = bool(active_mods.get("shift", False))
    combos, counts = _scan_key(context, key_type, enabled_sources)

    sig = (ctrl, alt, shift)
    b = combos.get(sig)
    variants = {
        "none": (False, False, False) in combos,
        "shift": any(s for (c, a, s) in combos),
        "ctrl": any(c for (c, a, s) in combos),
        "alt": any(a for (c, a, s) in combos),
    }
    return {
        "bound": b is not None,
        "idname": b["idname"] if b else None,
        "label": b["label"] if b else None,
        "conflict": counts.get(sig, 0) > 1,
        "variants": variants,
    }


def source_of_idname(idname):
    """Source label from an idname alone (no keyconfig) — for the operator catalog.
    Native modules -> 'Blender'; known/non-native namespaces -> add-on name."""
    key = _group_key(idname)
    if key in _KNOWN_ADDONS:
        return _KNOWN_ADDONS[key]
    ns = idname.split(".")[0]
    if ns in _KNOWN_ADDONS:
        return _KNOWN_ADDONS[ns]
    if ns in _GENERIC_MODULES:
        return NATIVE
    return ns.replace("_", " ").title()


_CATALOG = None


def catalog():
    """All registered operators as {idname,label,desc,source}, sorted by label. Cached."""
    global _CATALOG
    if _CATALOG is not None:
        return _CATALOG
    items = []
    for mod_name in dir(bpy.ops):
        mod = getattr(bpy.ops, mod_name, None)
        if mod is None:
            continue
        for op_name in dir(mod):
            idname = f"{mod_name}.{op_name}"
            try:
                rna = getattr(mod, op_name).get_rna_type()
                label = rna.name or idname
                desc = rna.description or ""
            except Exception:
                label, desc = idname, ""
            items.append({"idname": idname, "label": label, "desc": desc,
                          "source": source_of_idname(idname)})
    items.sort(key=lambda d: d["label"].lower())
    _CATALOG = items
    return _CATALOG


def invalidate_catalog():
    """Drop the cached operator scan so the next catalog() re-enumerates bpy.ops
    (e.g. after a new add-on is enabled). Source of truth is always Blender."""
    global _CATALOG
    _CATALOG = None


def keys_bound_to(context, idname, enabled_sources=None):
    """Reverse lookup: every (key_type, ctrl, alt, shift) this operator is bound to,
    across the relevant keymaps. Used to highlight a script's keys on the board."""
    out = []
    names = relevant_keymap_names(context)
    for kc_name, kc in (("user", _user_kc()), ("addon", _addon_kc())):
        if kc is None:
            continue
        for name in names:
            km = kc.keymaps.get(name)
            if km is None:
                continue
            for kmi in km.keymap_items:
                if not _is_kbd(kmi) or kmi.idname != idname:
                    continue
                if enabled_sources is not None and _source_of(kmi.idname, kc_name) not in enabled_sources:
                    continue
                out.append((kmi.type, bool(kmi.ctrl), bool(kmi.alt), bool(kmi.shift)))
    return out


def all_combo_bindings(context, key_type):
    """binding_for(...) for each single-modifier combo (and no-mod)."""
    return {
        "none": binding_for(context, key_type, False, False, False),
        "shift": binding_for(context, key_type, False, False, True),
        "ctrl": binding_for(context, key_type, True, False, False),
        "alt": binding_for(context, key_type, False, True, False),
    }


def key_combos(context, key_type, enabled_sources=None):
    """Every bound modifier combo on the key, INCLUDING multi-modifier (Ctrl+Shift+F).

    Returns a list ordered no-mod first, then by modifier count. Each entry:
    {"ctrl","alt","shift","mods" (display str), "label", "idname", "source", "conflict"}.
    """
    combos, counts = _scan_key(context, key_type, enabled_sources)
    out = []
    for (c, a, s), b in combos.items():
        mods = " + ".join(x for x, on in (("Ctrl", c), ("Alt", a), ("Shift", s)) if on) or "(plain)"
        out.append({
            "ctrl": c, "alt": a, "shift": s, "mods": mods,
            "label": b["label"], "idname": b["idname"], "desc": b.get("desc", ""),
            "source": b["source"], "conflict": counts.get((c, a, s), 0) > 1,
        })
    out.sort(key=lambda d: (d["ctrl"] + d["alt"] + d["shift"], not d["ctrl"], not d["alt"], not d["shift"]))
    return out


def available_sources(context, key_types):
    """Distinct source labels present across the given key types, Blender first.

    Used to build the ribbon of plugin toggles. Scans the relevant keymaps once per key.
    """
    srcs = set()
    for kt in key_types:
        for _, kmi, src, _kc in _iter_user_kmis(context, kt):
            if _value_matches(kmi, "PRESS"):
                srcs.add(src)
    rest = sorted(s for s in srcs if s != NATIVE)
    return ([NATIVE] if NATIVE in srcs else []) + rest


def _valid_idname(idname):
    """idname looks like an operator and its module exists under bpy.ops."""
    if not isinstance(idname, str) or "." not in idname:
        return False
    module = idname.split(".")[0]
    return getattr(bpy.ops, module, None) is not None


def _our_kmis_in(km, key_type=None, ctrl=None, alt=None, shift=None):
    """Yield kmis in km that WE created (match a tracked signature). Optional filter."""
    for kmi in list(km.keymap_items):
        if getattr(kmi, "map_type", None) != "KEYBOARD":
            continue
        sig = _ours_sig(km.name, kmi.type, kmi.ctrl, kmi.alt, kmi.shift)
        if sig not in _OURS:
            continue
        if key_type is not None and kmi.type != key_type:
            continue
        if ctrl is not None and not _mods_match(kmi, ctrl, alt, shift):
            continue
        yield kmi


def assign(idname, key_type, ctrl=False, alt=False, shift=False, value="PRESS", mode=None):
    """Create a kmi in the addon keyconfig, in the keymap matching `mode` (or the
    active context mode), replacing only our own dup. Persists across restarts."""
    if not _valid_idname(idname):
        return {"ok": False, "error": "invalid idname (need 'module.operator')", "idname": idname}

    kc = _addon_kc()
    if kc is None:
        return {"ok": False, "error": "no addon keyconfig (run inside Blender)", "idname": idname}

    km_name, space_type = _target_keymap(mode)
    try:
        km = kc.keymaps.new(name=km_name, space_type=space_type)
        # Replace ONLY an item we created at this exact key+mods (never another add-on's).
        for kmi in _our_kmis_in(km, key_type, ctrl, alt, shift):
            km.keymap_items.remove(kmi)
        km.keymap_items.new(
            idname, type=key_type, value=value,
            ctrl=ctrl, alt=alt, shift=shift,
        )
        sig = _ours_sig(km_name, key_type, ctrl, alt, shift)
        if sig not in _OURS:
            _OURS.append(sig)
    except Exception as e:
        return {"ok": False, "error": str(e), "idname": idname}

    _persist_add(km_name, space_type, idname, key_type, ctrl, alt, shift, value)
    return {"ok": True, "error": None, "idname": idname}


def clear_assignment(key_type, ctrl=False, alt=False, shift=False, mode=None):
    """Remove our own matching kmi from the keymap for `mode` (or active mode)."""
    kc = _addon_kc()
    if kc is None:
        return {"ok": False, "removed": 0}
    km_name, _space = _target_keymap(mode)
    km = kc.keymaps.get(km_name)
    if km is None:
        _persist_remove(km_name, key_type, ctrl, alt, shift)
        return {"ok": True, "removed": 0}
    removed = 0
    try:
        for kmi in _our_kmis_in(km, key_type, ctrl, alt, shift):
            km.keymap_items.remove(kmi)
            removed += 1
    except Exception:
        return {"ok": False, "removed": removed}
    sig = _ours_sig(km_name, key_type, ctrl, alt, shift)
    if sig in _OURS:
        _OURS.remove(sig)
    _persist_remove(km_name, key_type, ctrl, alt, shift)
    return {"ok": True, "removed": removed}


def _our_keymaps(kc):
    """All addon-kc keymaps that contain at least one binding we created."""
    out = []
    for km in kc.keymaps:
        if any(True for _ in _our_kmis_in(km)):
            out.append(km)
    return out


def our_assignments():
    """Keyboard items WE created across all addon-kc keymaps (tracked, not the whole shared kc)."""
    kc = _addon_kc()
    if kc is None:
        return []
    out = []
    for km in kc.keymaps:
        for kmi in _our_kmis_in(km):
            out.append({
                "km": km.name,
                "idname": kmi.idname,
                "type": kmi.type,
                "ctrl": bool(kmi.ctrl),
                "alt": bool(kmi.alt),
                "shift": bool(kmi.shift),
            })
    return out


def clear_all_ours():
    """Remove every live binding we created (all keymaps). Called on teardown so
    reloads don't orphan items. Does NOT touch the persisted JSON — apply_persisted
    re-creates them on next load (that's how bindings survive restarts)."""
    kc = _addon_kc()
    if kc is None:
        _OURS.clear()
        return
    for km in kc.keymaps:
        for kmi in _our_kmis_in(km):
            km.keymap_items.remove(kmi)
    _OURS.clear()


# --- persistence (base service: bindings survive Blender restarts) -----------

def _bindings_path():
    d = bpy.utils.user_resource('CONFIG', path=_BINDINGS_DIRNAME, create=True)
    return os.path.join(d, _BINDINGS_FILE)


def _persist_load():
    try:
        with open(_bindings_path(), "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, list) else []
    except (FileNotFoundError, ValueError, OSError):
        return []


def _persist_save(records):
    try:
        with open(_bindings_path(), "w", encoding="utf-8") as f:
            json.dump(records, f, indent=1)
    except OSError:
        pass


def _rec_matches(r, km_name, key_type, ctrl, alt, shift):
    return (r.get("km") == km_name and r.get("type") == key_type
            and bool(r.get("ctrl")) == bool(ctrl) and bool(r.get("alt")) == bool(alt)
            and bool(r.get("shift")) == bool(shift))


def _persist_add(km_name, space_type, idname, key_type, ctrl, alt, shift, value):
    recs = [r for r in _persist_load() if not _rec_matches(r, km_name, key_type, ctrl, alt, shift)]
    recs.append({"km": km_name, "space": space_type, "idname": idname, "type": key_type,
                 "ctrl": bool(ctrl), "alt": bool(alt), "shift": bool(shift), "value": value})
    _persist_save(recs)


def _persist_remove(km_name, key_type, ctrl, alt, shift):
    recs = [r for r in _persist_load() if not _rec_matches(r, km_name, key_type, ctrl, alt, shift)]
    _persist_save(recs)


def apply_persisted():
    """Re-create persisted bindings in the addon kc + repopulate _OURS. Idempotent —
    safe to call on every register/load. Returns count applied."""
    kc = _addon_kc()
    if kc is None:
        return 0
    applied = 0
    for r in _persist_load():
        if not _valid_idname(r.get("idname", "")):
            continue
        try:
            km = kc.keymaps.new(name=r["km"], space_type=r.get("space", "EMPTY"))
            sig = _ours_sig(r["km"], r["type"], r["ctrl"], r["alt"], r["shift"])
            # skip if we already have it live (idempotent on repeated calls)
            if any(_ours_sig(km.name, k.type, k.ctrl, k.alt, k.shift) == sig
                   for k in km.keymap_items if getattr(k, "map_type", None) == "KEYBOARD"):
                if sig not in _OURS:
                    _OURS.append(sig)
                continue
            km.keymap_items.new(r["idname"], type=r["type"], value=r.get("value", "PRESS"),
                                ctrl=r["ctrl"], alt=r["alt"], shift=r["shift"])
            if sig not in _OURS:
                _OURS.append(sig)
            applied += 1
        except Exception:
            continue
    return applied


def get_bindings():
    """The user's persisted bindings (base_api surface). Source = the JSON store."""
    return _persist_load()


# --- native edits (USER keyconfig, invasive, reversible) ---------------------
# Everything above writes only to the addon kc (isolated/reversible-by-disable).
# The functions below edit Blender's REAL (user) keymap in place — exactly like
# Preferences > Keymap does: a rebind moves the kmi, a disable flips kmi.active.
# Reversibility is the whole game: before the FIRST edit of any native kmi we
# snapshot its original state into overrides.json (tier 2). restore_* returns it
# to Blender's FACTORY default (keyconfigs.default), NOT to our snapshot — the
# snapshot may itself already be a user-modified value, so it isn't authority.

# Tier-1 session baseline: filled once per session by session_baseline_scan().
# ponytail: module global, mirrors _OURS / _VIEW_MODE — no registry class needed.
_SESSION_BASELINE = None


def _overrides_path():
    d = bpy.utils.user_resource('CONFIG', path=_BINDINGS_DIRNAME, create=True)
    return os.path.join(d, _OVERRIDES_FILE)


def _overrides_load():
    """The overrides store: {"consented": bool, "edits": [...]}. Defensive default."""
    try:
        with open(_overrides_path(), "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            return {"consented": False, "edits": []}
        data.setdefault("consented", False)
        data.setdefault("edits", [])
        if not isinstance(data["edits"], list):
            data["edits"] = []
        return data
    except (FileNotFoundError, ValueError, OSError):
        return {"consented": False, "edits": []}


def _overrides_save(store):
    try:
        with open(_overrides_path(), "w", encoding="utf-8") as f:
            json.dump(store, f, indent=1)
    except OSError:
        pass


def native_edits_consented():
    """Has the user given one-time consent to edit native shortcuts? (persisted)."""
    return bool(_overrides_load().get("consented"))


def set_native_edits_consented(value=True):
    """Persist the one-time consent flag. The consent DIALOG is another workstream;
    we only own the state. Edit ops refuse with {'error':'needs_consent'} until set."""
    store = _overrides_load()
    store["consented"] = bool(value)
    _overrides_save(store)
    return {"ok": True, "consented": store["consented"]}


def _ov_matches(r, km_name, key_type, ctrl, alt, shift):
    """An override record matches by keymap + the CURRENT (edited) key+mods — the
    coordinate the UI/caller still sees on the board after the edit."""
    return (r.get("km") == km_name and r.get("cur_type") == key_type
            and bool(r.get("cur_ctrl")) == bool(ctrl) and bool(r.get("cur_alt")) == bool(alt)
            and bool(r.get("cur_shift")) == bool(shift))


def _persist_override_add(record):
    """Append/replace an override record, keyed on km + ORIGINAL coordinate (so we
    snapshot a given native kmi exactly once even across repeated edits)."""
    def same_origin(r):
        return (r.get("km") == record["km"] and r.get("orig_type") == record["orig_type"]
                and bool(r.get("orig_ctrl")) == bool(record["orig_ctrl"])
                and bool(r.get("orig_alt")) == bool(record["orig_alt"])
                and bool(r.get("orig_shift")) == bool(record["orig_shift"]))
    store = _overrides_load()
    store["edits"] = [r for r in store["edits"] if not same_origin(r)]
    store["edits"].append(record)
    _overrides_save(store)


def _persist_override_remove(km_name, key_type, ctrl, alt, shift):
    """Drop the override record matching a CURRENT coordinate (after a restore)."""
    store = _overrides_load()
    store["edits"] = [r for r in store["edits"]
                      if not _ov_matches(r, km_name, key_type, ctrl, alt, shift)]
    _overrides_save(store)


def list_overrides():
    """Active native edits — for the 'native edits active' indicator + Restore All."""
    return _overrides_load().get("edits", [])


def _existing_override(km_name, key_type, ctrl, alt, shift):
    """The override record for a kmi at this CURRENT coordinate, if we've edited it."""
    for r in _overrides_load().get("edits", []):
        if _ov_matches(r, km_name, key_type, ctrl, alt, shift):
            return r
    return None


def _iter_user_km(context):
    """Yield (keymap_name, km) over the relevant USER-kc keymaps only. Native edits
    live in the user kc exclusively — never the addon kc (that's the isolated path)."""
    kc = _user_kc()
    if kc is None:
        return
    for name in relevant_keymap_names(context):
        km = kc.keymaps.get(name)
        if km is not None:
            yield name, km


def _find_user_kmi(context, key_type, ctrl, alt, shift, mode=None, idname=None):
    """The first active native kmi matching key_type + exact mods + PRESS/ANY, with
    its keymap. `idname` (when given) disambiguates among several bindings sharing the
    combo — without it, operations hit the wrong one. USER kc only; returns (km, kmi)
    or (None, None)."""
    for _name, km in _iter_user_km(context):
        for kmi in km.keymap_items:
            if not _is_kbd(kmi):
                continue
            if getattr(kmi, "type", None) != key_type:
                continue
            if not _value_matches(kmi, "PRESS"):
                continue
            if not _mods_match(kmi, ctrl, alt, shift):
                continue
            if idname is not None and kmi.idname != idname:
                continue
            return km, kmi
    return None, None


def _snapshot_record(km, kmi):
    """Snapshot a native kmi's ORIGINAL state (tier 2) before our first edit of it.
    cur_* start equal to orig_* and get rewritten by each edit so the UI can still
    locate the binding at its live coordinate."""
    return {
        "km": km.name,
        "space": getattr(km, "space_type", "EMPTY"),
        "origin": "modified",   # "modified" (factory kmi we changed) | "added" (we created it)
        "orig_type": kmi.type, "orig_ctrl": bool(kmi.ctrl), "orig_alt": bool(kmi.alt),
        "orig_shift": bool(kmi.shift), "orig_value": kmi.value,
        "orig_idname": kmi.idname, "orig_active": bool(kmi.active),
        "cur_type": kmi.type, "cur_ctrl": bool(kmi.ctrl), "cur_alt": bool(kmi.alt),
        "cur_shift": bool(kmi.shift), "cur_value": kmi.value,
        "cur_idname": kmi.idname, "cur_active": bool(kmi.active),
    }


def _snapshot_added(km, kmi):
    """Snapshot for a binding WE created in the user kc (origin='added'): restore/remove
    DELETES it (there's no factory to revert to). cur_* still track it for the UI."""
    rec = _snapshot_record(km, kmi)
    rec["origin"] = "added"
    return rec


def _is_added(km_name, key_type, ctrl, alt, shift, idname=None):
    """True if a binding at this CURRENT coordinate is one we added (not factory)."""
    for r in _overrides_load().get("edits", []):
        if r.get("origin") == "added" and _ov_matches(r, km_name, key_type, ctrl, alt, shift):
            if idname is None or r.get("cur_idname") == idname:
                return True
    return False


def _ensure_snapshot(km, kmi, key_type, ctrl, alt, shift):
    """Snapshot before first edit (tier 2): reuse the existing override record if we
    already edited this kmi, else snapshot its ORIGINAL state now. Returns the record."""
    rec = _existing_override(km.name, key_type, ctrl, alt, shift)
    if rec is None:
        rec = _snapshot_record(km, kmi)
    return rec


def _commit_override(rec, kmi):
    """Refresh the record's cur_* from the live (just-edited) kmi and persist it."""
    rec["cur_type"] = kmi.type
    rec["cur_ctrl"] = bool(kmi.ctrl)
    rec["cur_alt"] = bool(kmi.alt)
    rec["cur_shift"] = bool(kmi.shift)
    rec["cur_value"] = kmi.value
    rec["cur_idname"] = kmi.idname
    rec["cur_active"] = bool(kmi.active)
    _persist_override_add(rec)


def _consent_guard():
    if not native_edits_consented():
        return {"ok": False, "error": "needs_consent"}
    return None


def rebind_existing(context, key_type, ctrl, alt, shift,
                    new_key_type, new_ctrl=False, new_alt=False, new_shift=False,
                    mode=None, idname=None):
    """Move an existing native kmi to a new key+mods (in place, user kc). Snapshots
    its original state first so it's reversible. `idname` targets the right binding
    when several share the combo. Returns {ok, error}."""
    guard = _consent_guard()
    if guard:
        return guard
    km, kmi = _find_user_kmi(context, key_type, ctrl, alt, shift, mode, idname=idname)
    if kmi is None:
        return {"ok": False, "error": "no matching native binding"}
    rec = _ensure_snapshot(km, kmi, key_type, ctrl, alt, shift)
    try:
        kmi.type = new_key_type
        kmi.ctrl = bool(new_ctrl)
        kmi.alt = bool(new_alt)
        kmi.shift = bool(new_shift)
    except Exception as e:
        return {"ok": False, "error": str(e)}
    _commit_override(rec, kmi)
    return {"ok": True, "error": None}


def set_operator_of(context, key_type, ctrl, alt, shift, new_idname, mode=None, idname=None):
    """Change the operator a native kmi is bound to (in place, user kc). Snapshots
    first. `idname` targets the right binding when several share the combo (matches the
    OLD operator). Validates new_idname like assign() does. Returns {ok, error}."""
    guard = _consent_guard()
    if guard:
        return guard
    if not _valid_idname(new_idname):
        return {"ok": False, "error": "invalid idname (need 'module.operator')", "idname": new_idname}
    km, kmi = _find_user_kmi(context, key_type, ctrl, alt, shift, mode, idname=idname)
    if kmi is None:
        return {"ok": False, "error": "no matching native binding"}
    rec = _ensure_snapshot(km, kmi, key_type, ctrl, alt, shift)
    try:
        kmi.idname = new_idname
    except Exception as e:
        return {"ok": False, "error": str(e)}
    _commit_override(rec, kmi)
    return {"ok": True, "error": None}


def disable_binding(context, key_type, ctrl, alt, shift, mode=None, idname=None):
    """Disable a native kmi (kmi.active=False) — like unticking it in Preferences.
    Snapshots first so it's reversible. `idname` targets the right one when several
    share the combo. Returns {ok, error}."""
    guard = _consent_guard()
    if guard:
        return guard
    km, kmi = _find_user_kmi(context, key_type, ctrl, alt, shift, mode, idname=idname)
    if kmi is None:
        return {"ok": False, "error": "no matching native binding"}
    rec = _ensure_snapshot(km, kmi, key_type, ctrl, alt, shift)
    try:
        kmi.active = False
    except Exception as e:
        return {"ok": False, "error": str(e)}
    _commit_override(rec, kmi)
    return {"ok": True, "error": None}


def override_assign(context, idname, key_type, ctrl=False, alt=False, shift=False, mode=None):
    """Make key+combo run ONLY `idname`: disable EVERY active native binding at this
    combo across the relevant keymaps (each reversible via restore), then add our own
    addon-kc binding. This fixes 'assign created a conflict and my op didn't fire' —
    a key bound in several keymaps (Object Mode + 3D View, etc.) needs all of them
    silenced, not just one. Consent-gated (it edits the real keymap)."""
    guard = _consent_guard()
    if guard:
        return guard
    if not _valid_idname(idname):
        return {"ok": False, "error": "invalid idname (need 'module.operator')", "idname": idname}
    disabled = 0
    kc = _user_kc()
    if kc is not None:
        for name in relevant_keymap_names(context):
            km = kc.keymaps.get(name)
            if km is None:
                continue
            for kmi in list(km.keymap_items):
                if (_is_kbd(kmi) and getattr(kmi, "type", None) == key_type
                        and _value_matches(kmi, "PRESS") and _mods_match(kmi, ctrl, alt, shift)
                        and kmi.active):
                    rec = _ensure_snapshot(km, kmi, key_type, ctrl, alt, shift)
                    try:
                        kmi.active = False
                        _commit_override(rec, kmi)
                        disabled += 1
                    except Exception:
                        pass
    res = assign(idname, key_type, ctrl=ctrl, alt=alt, shift=shift, mode=mode)
    res["disabled_native"] = disabled
    return res


def _default_kmi_for(km_name, idname, type_, ctrl, alt, shift):
    """The factory kmi from keyconfigs.default matching (km, idname, key+mods), or
    None. keyconfigs.default holds Blender's factory + addon defaults, SEPARATE from
    the user kc — so it's the real restore authority, not our snapshot."""
    wm = getattr(bpy.context, "window_manager", None)
    kc = getattr(getattr(wm, "keyconfigs", None), "default", None)
    if kc is None:
        return None
    km = kc.keymaps.get(km_name)
    if km is None:
        return None
    for kmi in km.keymap_items:
        if getattr(kmi, "map_type", None) != "KEYBOARD":
            continue
        if kmi.idname == idname and kmi.type == type_ \
                and bool(kmi.ctrl) == bool(ctrl) and bool(kmi.alt) == bool(alt) \
                and bool(kmi.shift) == bool(shift):
            return kmi
    return None


def _restore_kmi_to_factory(km, kmi, rec):
    """Return a live user kmi to Blender's FACTORY default. Strategy, most-authoritative
    first: (1) copy values from the matching kmi in keyconfigs.default; (2) Blender's
    own km.restore_item_to_default(kmi); (3) fall back to our snapshot's orig_* values.
    Defensive: any step that errors falls through to the next."""
    # (1) factory values from the default keyconfig (matched on the ORIGINAL coords).
    src = _default_kmi_for(km.name, rec.get("orig_idname"), rec.get("orig_type"),
                           rec.get("orig_ctrl"), rec.get("orig_alt"), rec.get("orig_shift"))
    if src is not None:
        try:
            kmi.type = src.type
            kmi.ctrl = src.ctrl
            kmi.alt = src.alt
            kmi.shift = src.shift
            kmi.value = src.value
            kmi.idname = src.idname
            kmi.active = src.active
            return True
        except Exception:
            pass
    # (2) our tier-2 snapshot — the reliable revert to pre-edit state. MUST come before
    # restore_item_to_default: for a binding NOT in keyconfigs.default (an add-on binding,
    # or a synthetic one) Blender's restore no-ops but reports success, which would strand
    # the kmi at its edited coordinate. The snapshot always sets it back.
    try:
        kmi.type = rec.get("orig_type", kmi.type)
        kmi.ctrl = bool(rec.get("orig_ctrl", kmi.ctrl))
        kmi.alt = bool(rec.get("orig_alt", kmi.alt))
        kmi.shift = bool(rec.get("orig_shift", kmi.shift))
        kmi.value = rec.get("orig_value", kmi.value)
        kmi.idname = rec.get("orig_idname", kmi.idname)
        kmi.active = bool(rec.get("orig_active", kmi.active))
        return True
    except Exception:
        pass
    # (3) last resort: Blender's built-in restore (5.x: keymap.restore_item_to_default).
    restore = getattr(km, "restore_item_to_default", None)
    if callable(restore):
        try:
            restore(kmi)
            return True
        except Exception:
            pass
    return False


def restore_one(context, key_type, ctrl, alt, shift, mode=None):
    """Restore a single edited native binding to factory default. key_type+mods is the
    CURRENT (edited) coordinate shown on the board. Drops its override record."""
    # ponytail: km name varies per record; just scan our edits for the live coordinate.
    for r in list(_overrides_load().get("edits", [])):
        if not (r.get("cur_type") == key_type and bool(r.get("cur_ctrl")) == bool(ctrl)
                and bool(r.get("cur_alt")) == bool(alt) and bool(r.get("cur_shift")) == bool(shift)):
            continue
        kc = _user_kc()
        km = kc.keymaps.get(r["km"]) if kc else None
        if km is None:
            _persist_override_remove(r["km"], key_type, ctrl, alt, shift)
            return {"ok": True, "restored": 0, "error": "keymap gone; record cleared"}
        # find the live kmi at the CURRENT coordinate (match on edited idname too,
        # so we grab the one we moved, not a same-key sibling we never touched).
        target = None
        for kmi in km.keymap_items:
            # don't gate on active: a disabled-by-us kmi has active=False but is still ours.
            if getattr(kmi, "map_type", None) != "KEYBOARD":
                continue
            if kmi.type == r.get("cur_type") and bool(kmi.ctrl) == bool(r.get("cur_ctrl")) \
                    and bool(kmi.alt) == bool(r.get("cur_alt")) and bool(kmi.shift) == bool(r.get("cur_shift")) \
                    and kmi.idname == r.get("cur_idname"):
                target = kmi
                break
        if target is None:
            _persist_override_remove(r["km"], key_type, ctrl, alt, shift)
            return {"ok": False, "restored": 0, "error": "live kmi not found; record cleared"}
        ok = _restore_kmi_to_factory(km, target, r)
        _persist_override_remove(r["km"], key_type, ctrl, alt, shift)
        return {"ok": ok, "restored": 1 if ok else 0, "error": None if ok else "restore failed"}
    return {"ok": False, "restored": 0, "error": "no override at that coordinate"}


def restore_all():
    """Restore every native edit we made to factory default, then clear the overrides
    store (keeps the consent flag). Defensive: skips records whose keymap/kmi vanished."""
    store = _overrides_load()
    edits = store.get("edits", [])
    kc = _user_kc()
    restored = 0
    for r in edits:
        km = kc.keymaps.get(r["km"]) if kc else None
        if km is None:
            continue
        for kmi in km.keymap_items:
            if kmi.type == r.get("cur_type") and bool(kmi.ctrl) == bool(r.get("cur_ctrl")) \
                    and bool(kmi.alt) == bool(r.get("cur_alt")) and bool(kmi.shift) == bool(r.get("cur_shift")) \
                    and kmi.idname == r.get("cur_idname"):
                if _restore_kmi_to_factory(km, kmi, r):
                    restored += 1
                break
    store["edits"] = []
    _overrides_save(store)
    return {"ok": True, "restored": restored}


# --- per-binding edit surface (origin-aware: targets ONE specific binding) -------
# The combo-level fns above hit the first kmi at a key+mods; a combo often holds
# several (native + other add-ons), so the UI passes idname+kc to disambiguate.

def assign_native(context, idname, key_type, ctrl=False, alt=False, shift=False, mode=None):
    """Assign into Blender's NATIVE (user) keyconfig — ONE binding, no separate 'ours'
    layer (which caused duplicate 'Blender + you' entries). If the combo already has a
    native binding, change ITS operator in place (snapshot original → restorable); if
    empty, add a new kmi tracked as 'added' (remove/restore deletes it). Consent-gated."""
    guard = _consent_guard()
    if guard:
        return guard
    if not _valid_idname(idname):
        return {"ok": False, "error": "invalid idname (need 'module.operator')", "idname": idname}
    km, kmi = _find_user_kmi(context, key_type, ctrl, alt, shift, mode)
    if kmi is not None:                       # occupied → change in place (snapshotted)
        return set_operator_of(context, key_type, ctrl, alt, shift, idname, mode)
    ukc = _user_kc()
    km_name, _sp = _target_keymap(mode)
    km = ukc.keymaps.get(km_name) if ukc else None
    if km is None:
        return {"ok": False, "error": f"no user keymap '{km_name}'", "idname": idname}
    try:
        kmi = km.keymap_items.new(idname, type=key_type, value="PRESS",
                                  ctrl=bool(ctrl), alt=bool(alt), shift=bool(shift))
    except Exception as e:
        return {"ok": False, "error": str(e), "idname": idname}
    _commit_override(_snapshot_added(km, kmi), kmi)
    return {"ok": True, "error": None, "idname": idname}


def remove_binding(context, key_type, ctrl, alt, shift, idname=None, kc=None, mode=None):
    """Make ONE specific binding stop firing. A binding WE added (native, tracked) →
    delete it. A factory native binding → disable + snapshot (reversible via restore).
    Legacy addon-kc 'ours' → delete; another add-on's → disable. `idname`+`kc` pick it."""
    # legacy addon-kc path (kept for any bindings made before native unification)
    if kc == "addon":
        akc = _addon_kc()
        if akc is not None:
            for name in relevant_keymap_names(context):
                km = akc.keymaps.get(name)
                if km is None:
                    continue
                for kmi in list(km.keymap_items):
                    if not (_is_kbd(kmi) and kmi.type == key_type and _value_matches(kmi, "PRESS")
                            and _mods_match(kmi, ctrl, alt, shift)
                            and (idname is None or kmi.idname == idname)):
                        continue
                    if _is_ours(name, kmi):
                        sig = _ours_sig(name, kmi.type, kmi.ctrl, kmi.alt, kmi.shift)
                        if sig in _OURS:
                            _OURS.remove(sig)
                        km.keymap_items.remove(kmi)
                        _persist_remove(name, key_type, ctrl, alt, shift)
                        return {"ok": True, "removed": "ours"}
                    try:
                        kmi.active = False
                        return {"ok": True, "removed": "disabled-addon"}
                    except Exception as e:
                        return {"ok": False, "error": str(e)}
    # native (user kc)
    guard = _consent_guard()
    if guard:
        return guard
    km, kmi = _find_user_kmi(context, key_type, ctrl, alt, shift, mode, idname=idname)
    if kmi is None:
        return {"ok": False, "error": "no matching native binding"}
    if _is_added(km.name, key_type, ctrl, alt, shift, idname):   # ours → delete outright
        km.keymap_items.remove(kmi)
        _persist_override_remove(km.name, key_type, ctrl, alt, shift)
        return {"ok": True, "removed": "added-deleted"}
    rec = _ensure_snapshot(km, kmi, key_type, ctrl, alt, shift)  # factory → disable, reversible
    try:
        kmi.active = False
    except Exception as e:
        return {"ok": False, "error": str(e)}
    _commit_override(rec, kmi)
    return {"ok": True, "removed": "disabled"}


def rebind_binding(context, key_type, ctrl, alt, shift, idname, kc,
                   new_key, new_ctrl=False, new_alt=False, new_shift=False, mode=None):
    """Move ONE binding to a new key+mods, CLEARING the old spot. Ours → delete + recreate
    at the new coordinate (addon kc). Native → move in place (user kc, reversible)."""
    if kc == "addon":
        rm = remove_binding(context, key_type, ctrl, alt, shift, idname=idname, kc="addon")
        if not rm.get("ok"):
            return rm
        return assign(idname, new_key, ctrl=new_ctrl, alt=new_alt, shift=new_shift, mode=mode)
    return rebind_existing(context, key_type, ctrl, alt, shift,
                           new_key, new_ctrl, new_alt, new_shift, mode=mode, idname=idname)


def restore_combo(context, key_type, ctrl, alt, shift):
    """Reset a key+combo to Blender FACTORY: drop our addon-kc additions here and
    restore_item_to_default every user-kc kmi here (works with no override record — the
    kmi remembers its own factory state; also re-enables ones we disabled). Drops matching
    override records."""
    removed = restored = 0
    akc = _addon_kc()
    if akc is not None:
        for name in relevant_keymap_names(context):
            km = akc.keymaps.get(name)
            if km is None:
                continue
            for kmi in list(km.keymap_items):
                if (getattr(kmi, "map_type", None) == "KEYBOARD" and kmi.type == key_type
                        and _mods_match(kmi, ctrl, alt, shift) and _is_ours(name, kmi)):
                    sig = _ours_sig(name, kmi.type, kmi.ctrl, kmi.alt, kmi.shift)
                    if sig in _OURS:
                        _OURS.remove(sig)
                    km.keymap_items.remove(kmi)
                    removed += 1
            _persist_remove(name, key_type, ctrl, alt, shift)
    ukc = _user_kc()
    if ukc is not None:
        for name in relevant_keymap_names(context):
            km = ukc.keymaps.get(name)
            if km is None:
                continue
            restore = getattr(km, "restore_item_to_default", None)
            for kmi in list(km.keymap_items):
                if not (getattr(kmi, "map_type", None) == "KEYBOARD" and kmi.type == key_type
                        and _mods_match(kmi, ctrl, alt, shift)):
                    continue
                if _is_added(name, key_type, ctrl, alt, shift, kmi.idname):   # ours → delete
                    km.keymap_items.remove(kmi)
                    removed += 1
                elif callable(restore):                                        # factory → revert
                    try:
                        restore(kmi)
                        restored += 1
                    except Exception:
                        pass
            _persist_override_remove(name, key_type, ctrl, alt, shift)
    return {"ok": True, "removed": removed, "restored": restored}


def bound_index(context, enabled_sources=None):
    """{idname: 'C·S·D'-style hotkey label} for every operator bound in the relevant
    keymaps — so the library can show which scripts already have a key. First binding wins."""
    out = {}
    names = relevant_keymap_names(context)
    for kc_name, kc in (("user", _user_kc()), ("addon", _addon_kc())):
        if kc is None:
            continue
        for name in names:
            km = kc.keymaps.get(name)
            if km is None:
                continue
            for kmi in km.keymap_items:
                if not _is_kbd(kmi) or not _value_matches(kmi, "PRESS"):
                    continue
                if enabled_sources is not None and _source_of(kmi.idname, kc_name) not in enabled_sources:
                    continue
                if kmi.idname in out:
                    continue
                mods = "".join(m for m, on in (("C·", kmi.ctrl), ("A·", kmi.alt), ("S·", kmi.shift)) if on)
                out[kmi.idname] = f"{mods}{kmi.type}"
    return out


def session_baseline_scan(context):
    """Tier-1 baseline: call once per session on first plugin open. Records the current
    user-kc keybindings (coordinate -> idname/source) and which sources are present, so
    we can later tell native from add-on. Lightweight; cached in a module global.
    Returns the baseline dict (re-scans only if not yet built)."""
    global _SESSION_BASELINE
    if _SESSION_BASELINE is not None:
        return _SESSION_BASELINE
    bindings = []
    sources = set()
    for name, km in _iter_user_km(context):
        for kmi in km.keymap_items:
            if not _is_kbd(kmi) or not _value_matches(kmi, "PRESS"):
                continue
            src = _source_of(kmi.idname, "user")
            sources.add(src)
            bindings.append({
                "km": name, "type": kmi.type, "ctrl": bool(kmi.ctrl),
                "alt": bool(kmi.alt), "shift": bool(kmi.shift),
                "idname": kmi.idname, "source": src,
            })
    _SESSION_BASELINE = {"bindings": bindings, "sources": sorted(sources)}
    return _SESSION_BASELINE


def native_override_state():
    """Compact map of our active native edits for UI: {(km,type,ctrl,alt,shift): record}
    keyed on the CURRENT coordinate. Used by base_api.get_bindings to flag edited keys."""
    out = {}
    for r in list_overrides():
        out[(r.get("km"), r.get("cur_type"), bool(r.get("cur_ctrl")),
             bool(r.get("cur_alt")), bool(r.get("cur_shift")))] = r
    return out


def demo_native(context):
    """Headless round-trip for the native-edit path that LEAVES NO TRACE.

    Picks a real native binding (or seeds a temp one in the user kc if none is
    found), rebinds it, asserts it moved, restores it to factory default, asserts
    it's back, and clears the overrides store. Returns {ok, checks} or asserts.
    Run via: import keyboard_proto.keymap_engine as e; print(e.demo_native(bpy.context))
    """
    checks = []
    ok = True

    def check(name, cond):
        nonlocal ok
        cond = bool(cond)
        ok = ok and cond
        checks.append({name: cond})

    # Save state so the demo never alters the user's real config or consent.
    prior_consent = native_edits_consented()
    prior_edits = list(_overrides_load().get("edits", []))
    seeded = None  # (km, kmi) we created and must remove on cleanup

    try:
        kc = _user_kc()
        if kc is None:
            return {"ok": False, "checks": [{"no user keyconfig": True}]}

        set_native_edits_consented(True)  # ungate the edit ops for the demo

        # A spare key+mods very unlikely to be natively bound: Ctrl+Alt+Shift+F19.
        spare_type, spare = "F19", (True, True, True)          # (ctrl, alt, shift)
        dest_type, dest = "F20", (True, True, True)
        km_name = "Window"  # always present; space_type EMPTY

        # Find an existing native binding to rebind; else seed a temp one.
        km, kmi = _find_user_kmi(context, spare_type, *spare)
        if kmi is None:
            km = kc.keymaps.get(km_name)
            if km is None:
                return {"ok": False, "checks": [{"no Window keymap": True}]}
            kmi = km.keymap_items.new("wm.splash", type=spare_type, value="PRESS",
                                      ctrl=True, alt=True, shift=True)
            seeded = (km, kmi)
        orig_idname = kmi.idname

        # 1) rebind it to the dest coordinate.
        res = rebind_existing(context, spare_type, *spare, dest_type, *dest)
        check("rebind ok", res.get("ok"))

        # 2) it moved: nothing at source, something (ours) at dest.
        _km_s, at_src = _find_user_kmi(context, spare_type, *spare)
        _km_d, at_dest = _find_user_kmi(context, dest_type, *dest)
        check("source now empty", at_src is None)
        check("dest now bound", at_dest is not None and at_dest.idname == orig_idname)
        check("override recorded", len(list_overrides()) == len(prior_edits) + 1)

        # 3) restore to factory: dest empties, source comes back (factory had it there
        #    only if we seeded — for a real native binding factory restores its own spot).
        rr = restore_one(context, dest_type, *dest)
        check("restore ok", rr.get("ok"))
        _km_d2, at_dest2 = _find_user_kmi(context, dest_type, *dest)
        check("dest empty after restore", at_dest2 is None)
        check("override cleared", len(list_overrides()) == len(prior_edits))
    except Exception as e:
        ok = False
        checks.append({"exception": str(e)})
    finally:
        # Cleanup: remove any seeded kmi, wipe demo overrides, restore prior consent.
        try:
            if seeded is not None:
                skm, _skmi = seeded
                for kmi in list(skm.keymap_items):
                    if getattr(kmi, "map_type", None) == "KEYBOARD" \
                            and kmi.idname == "wm.splash" and kmi.ctrl and kmi.alt and kmi.shift \
                            and kmi.type in ("F19", "F20"):
                        skm.keymap_items.remove(kmi)
            store = _overrides_load()
            store["edits"] = prior_edits
            store["consented"] = prior_consent
            _overrides_save(store)
        except Exception as e:
            checks.append({"cleanup exception": str(e)})

    return {"ok": ok, "checks": checks}


def selftest(context):
    """In-Blender verification: read path + assign/list/clear round-trip."""
    checks = []
    ok = True

    def check(name, cond):
        nonlocal ok
        cond = bool(cond)
        ok = ok and cond
        checks.append({name: cond})

    try:
        names = relevant_keymap_names(context)
        check("relevant_keymap_names non-empty", len(names) > 0)

        # Obscure combo unlikely to collide: Ctrl+J -> wm.splash.
        test_idname, test_key = "wm.splash", "J"
        clear_assignment(test_key, ctrl=True)  # ensure clean start

        res = assign(test_idname, test_key, ctrl=True)
        check("assign ok", res.get("ok"))

        present = any(
            a["idname"] == test_idname and a["type"] == test_key
            and a["ctrl"] and not a["alt"] and not a["shift"]
            for a in our_assignments()
        )
        check("our_assignments shows it", present)

        cleared = clear_assignment(test_key, ctrl=True)
        check("clear ok", cleared.get("ok"))
        check("removed >= 1", cleared.get("removed", 0) >= 1)

        gone = not any(
            a["idname"] == test_idname and a["type"] == test_key and a["ctrl"]
            for a in our_assignments()
        )
        check("assignment gone after clear", gone)
    except Exception as e:
        ok = False
        checks.append({"exception": str(e)})

    return {"ok": ok, "checks": checks}
