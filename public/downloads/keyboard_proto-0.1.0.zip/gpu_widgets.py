"""gpu_widgets — reusable GPU UI widgets for the base + every GPU module.

Built once here so the Action DB (and later Pie Builder, Decks) don't each
reinvent text input. Self-contained: owns its own gpu shader + blf draw helpers,
so a consumer only needs to (a) call a widget's draw() from its POST_PIXEL draw
callback and (b) feed Blender modal events to the widget's handle_event()/on_click().

The headline widget is TextField — a proper single-line editor with caret,
selection, clipboard, and full mid-string editing (a real tier above the v1
append-only search box). Button/Toggle are thin draw+hit helpers.

Hard-won rule honoured: nothing here stores an operator instance; consumers keep
widget instances at module level in their own files.

ponytail: word-jump (ctrl+arrow) and double-click word-select deferred — arrow/
home/end/shift-select/clipboard cover the real editing need. Multiline editor is
a separate later widget (Action DB notes), not this.
"""
import bpy
import gpu
import blf
from gpu_extras.batch import batch_for_shader

_shader = gpu.shader.from_builtin('UNIFORM_COLOR')
_FONT = 0

# ---- draw primitives (self-contained so widgets work without gpu_keyboard) ----

def rect(x, y, w, h, color):
    verts = ((x, y), (x + w, y), (x + w, y + h), (x, y + h))
    batch = batch_for_shader(_shader, 'TRI_FAN', {"pos": verts})
    _shader.bind()
    _shader.uniform_float("color", color)
    batch.draw(_shader)


def text(x, y, size, color, s):
    blf.size(_FONT, size)
    blf.color(_FONT, *color)
    blf.position(_FONT, x, y, 0)
    blf.draw(_FONT, s)


def text_w(s, size):
    blf.size(_FONT, size)
    return blf.dimensions(_FONT, s)[0]


def hit(r, mx, my):
    """Is (mx,my) inside rect r=(x,y,w,h)?"""
    if not r:
        return False
    x, y, w, h = r
    return x <= mx <= x + w and y <= my <= y + h


# ---- Button / Toggle (thin: draw + report hit) -------------------------------

def draw_button(r, label, size=13, fill=(0.22, 0.42, 0.25, 1.0), fg=(0.95, 0.97, 0.95, 1.0)):
    x, y, w, h = r
    rect(x, y, w, h, fill)
    tw = text_w(label, size)
    text(x + (w - tw) / 2, y + (h - size) / 2, size, fg, label)


def draw_toggle(r, label, on, size=13, on_col=(0.24, 0.45, 0.78, 1.0), off_col=(0.16, 0.16, 0.19, 1.0)):
    x, y, w, h = r
    rect(x, y, w, h, on_col if on else off_col)
    fg = (0.96, 0.97, 1.0, 1.0) if on else (0.55, 0.55, 0.6, 1.0)
    tw = text_w(label, size)
    text(x + (w - tw) / 2, y + (h - size) / 2, size, fg, label)


# ---- TextField ---------------------------------------------------------------

class TextField:
    """Single-line GPU text editor. Caret, selection, clipboard, mid-string edits.

    Usage in a modal operator:
        f = TextField()                       # module-level in the consumer
        # draw:  f.draw(x, y, w, h)
        # click: f.on_click(mx, my, extend=event.shift)
        # keys:  if f.focused and f.handle_event(event): return {'RUNNING_MODAL'}
    """
    PAD = 8

    def __init__(self, text="", placeholder="", size=14, numeric=False):
        self.text = text
        self.placeholder = placeholder
        self.size = size
        self.numeric = numeric
        self.caret = len(text)
        self.sel_anchor = None        # selection spans [sel_anchor, caret]; None = no selection
        self.focused = False
        self._rect = None
        self._scroll = 0.0            # horizontal px scroll so the caret stays visible

    # --- selection helpers ---
    def _sel_range(self):
        if self.sel_anchor is None or self.sel_anchor == self.caret:
            return None
        return (min(self.sel_anchor, self.caret), max(self.sel_anchor, self.caret))

    def selected_text(self):
        r = self._sel_range()
        return self.text[r[0]:r[1]] if r else ""

    def _delete_selection(self):
        r = self._sel_range()
        self.sel_anchor = None
        if not r:
            return False
        a, b = r
        self.text = self.text[:a] + self.text[b:]
        self.caret = a
        return True

    def select_all(self):
        self.sel_anchor = 0
        self.caret = len(self.text)

    def set_text(self, s):
        self.text = s
        self.caret = len(s)
        self.sel_anchor = None

    def value(self):
        """Return numeric value when numeric=True. float (or int if no dot) or None if empty/invalid."""
        if not self.numeric or not self.text:
            return None
        try:
            return int(self.text) if '.' not in self.text else float(self.text)
        except ValueError:
            return None

    # --- clipboard ---
    def _copy(self):
        sel = self.selected_text()
        if sel:
            bpy.context.window_manager.clipboard = sel

    def _paste(self):
        self._delete_selection()
        s = (bpy.context.window_manager.clipboard or "").replace("\n", " ").replace("\r", "")
        self.text = self.text[:self.caret] + s + self.text[self.caret:]
        self.caret += len(s)

    # --- caret movement ---
    def _move(self, t, extend):
        if extend and self.sel_anchor is None:
            self.sel_anchor = self.caret
        if not extend:
            self.sel_anchor = None
        if t == 'LEFT_ARROW':
            self.caret = max(0, self.caret - 1)
        elif t == 'RIGHT_ARROW':
            self.caret = min(len(self.text), self.caret + 1)
        elif t == 'HOME':
            self.caret = 0
        elif t == 'END':
            self.caret = len(self.text)

    def _numeric_allowed(self, ch):
        """True if appending ch keeps the field a valid partial number."""
        if ch == '-':
            return self.caret == 0 and '-' not in self.text
        if ch == '.':
            return '.' not in self.text
        return ch.isdigit()

    def handle_event(self, event):
        """Mutate state from a Blender modal event. Returns True if consumed.
        Caller should only route events here while self.focused. RET/ESC/TAB are
        NOT consumed (return False) so the consumer can commit/cancel/blur."""
        if event.value != 'PRESS':
            return False
        t = event.type
        if t in ('RET', 'NUMPAD_ENTER', 'ESC', 'TAB'):
            return False
        if event.ctrl and t == 'A':
            self.select_all(); return True
        if event.ctrl and t == 'C':
            self._copy(); return True
        if event.ctrl and t == 'X':
            self._copy(); self._delete_selection(); return True
        if event.ctrl and t == 'V':
            self._paste(); return True
        if t in ('LEFT_ARROW', 'RIGHT_ARROW', 'HOME', 'END'):
            self._move(t, event.shift); return True
        if t == 'BACK_SPACE':
            if not self._delete_selection() and self.caret > 0:
                self.text = self.text[:self.caret - 1] + self.text[self.caret:]
                self.caret -= 1
            return True
        if t in ('DEL', 'DELETE'):
            if not self._delete_selection():
                self.text = self.text[:self.caret] + self.text[self.caret + 1:]
            return True
        ch = event.unicode or ""
        if ch and ch.isprintable():
            if self.numeric and not self._numeric_allowed(ch):
                return True  # swallow disallowed char
            self._delete_selection()
            self.text = self.text[:self.caret] + ch + self.text[self.caret:]
            self.caret += len(ch)
            return True
        return True  # focused: swallow other keys so they don't leak to the viewport

    # --- mouse ---
    def _index_at_x(self, mx):
        """Caret index nearest to mouse x, accounting for pad + scroll."""
        if not self._rect:
            return len(self.text)
        x = self._rect[0] + self.PAD - self._scroll
        blf.size(_FONT, self.size)
        best_i, best_d = 0, abs(mx - x)
        acc = 0.0
        for i, ch in enumerate(self.text):
            acc = blf.dimensions(_FONT, self.text[:i + 1])[0]
            cx = x + acc
            d = abs(mx - cx)
            if d < best_d:
                best_d, best_i = d, i + 1
        return best_i

    def on_click(self, mx, my, extend=False):
        """Focus + position caret. Returns True if the click landed in the field."""
        if not hit(self._rect, mx, my):
            self.focused = False
            return False
        self.focused = True
        idx = self._index_at_x(mx)
        if extend:
            if self.sel_anchor is None:
                self.sel_anchor = self.caret
        else:
            self.sel_anchor = None
        self.caret = idx
        return True

    def on_drag(self, mx, my):
        """Extend selection to mouse during a drag (caller tracks the drag)."""
        if self.sel_anchor is None:
            self.sel_anchor = self.caret
        self.caret = self._index_at_x(mx)

    # --- draw ---
    def draw(self, x, y, w, h,
             bg=(0.06, 0.06, 0.08, 1.0), fg=(0.95, 0.96, 1.0, 1.0),
             ph=(0.45, 0.47, 0.52, 1.0), sel=(0.20, 0.40, 0.70, 1.0),
             accent=(0.30, 0.60, 1.0, 1.0)):
        self._rect = (x, y, w, h)
        rect(x, y, w, h, bg)
        if self.focused:
            rect(x, y, w, 2, accent)
        blf.size(_FONT, self.size)
        ty = y + (h - self.size) / 2 + 1
        inner_l = x + self.PAD
        inner_r = x + w - self.PAD

        # keep caret in view (horizontal scroll)
        caret_px = blf.dimensions(_FONT, self.text[:self.caret])[0]
        visible = w - 2 * self.PAD
        if caret_px - self._scroll > visible:
            self._scroll = caret_px - visible
        if caret_px - self._scroll < 0:
            self._scroll = caret_px
        self._scroll = max(0.0, self._scroll)

        tx = inner_l - self._scroll

        # clip text/selection to the inner field
        blf.enable(_FONT, blf.CLIPPING)
        blf.clipping(_FONT, inner_l, y, inner_r, y + h)

        # selection highlight
        r = self._sel_range()
        if r:
            ax = tx + blf.dimensions(_FONT, self.text[:r[0]])[0]
            bx = tx + blf.dimensions(_FONT, self.text[:r[1]])[0]
            ax = max(ax, inner_l); bx = min(bx, inner_r)
            if bx > ax:
                rect(ax, y + 4, bx - ax, h - 8, sel)

        if self.text:
            text(tx, ty, self.size, fg, self.text)
        elif self.placeholder and not self.focused:
            text(inner_l, ty, self.size, ph, self.placeholder)

        # caret
        if self.focused:
            cx = tx + caret_px
            cx = min(max(cx, inner_l), inner_r)
            rect(cx, y + 4, 1.5, h - 8, fg)

        blf.disable(_FONT, blf.CLIPPING)


# ---- Dropdown ----------------------------------------------------------------

class Dropdown:
    """Single-select dropdown. Closed box shows current value; click opens popup list.

    Usage in a modal operator (module-level, same pattern as TextField):
        dd = Dropdown(options=["Red", "Green", "Blue"], value="Red")
        # draw pass — call draw() for the closed control, then draw_popup() LAST
        # so the popup always renders on top of other widgets:
        #   dd.draw(x, y, w, h)
        #   ...draw other widgets...
        #   dd.draw_popup()          # no-op when closed
        #
        # click routing (before key routing):
        #   if dd.on_click(mx, my): return {'RUNNING_MODAL'}
        #
        # on_click returns True when it handled the event.
        # Check dd.just_selected after on_click to react to a new selection.

    Popup draws below the control. It caps at _MAX_ROWS rows; scroll is deferred.
    # ponytail: popup scroll deferred — cap at _MAX_ROWS for now, add scroll when needed.
    """
    PAD = 8
    ROW_H = 26
    _MAX_ROWS = 10  # ponytail: hard cap; proper scroll later if lists exceed this

    def __init__(self, options=None, value=None, placeholder="Select…", size=14):
        self.options = list(options) if options else []
        self.value = value
        self.placeholder = placeholder
        self.size = size
        self.is_open = False
        self.just_selected = False   # True for one frame after user picks an option
        self._rect = None            # set at draw() time
        self._option_rects = []      # parallel to self.options[:_MAX_ROWS], set at draw_popup()
        self._hovered = -1           # index under mouse (-1 = none)

    def set_options(self, options):
        self.options = list(options)
        self._option_rects = []
        self.is_open = False

    def set_value(self, v):
        self.value = v

    # --- draw helpers ---
    def _draw_caret(self, x, y, w, h):
        """Draw a tiny ▼ as three stacked rects (no triangle primitive needed)."""
        cx = x + w - self.PAD - 6
        cy = y + h // 2
        rect(cx,     cy - 1, 6, 2, (0.65, 0.67, 0.72, 1.0))
        rect(cx + 1, cy - 3, 4, 2, (0.65, 0.67, 0.72, 1.0))
        rect(cx + 2, cy - 5, 2, 2, (0.65, 0.67, 0.72, 1.0))

    def draw(self, x, y, w, h,
             bg=(0.06, 0.06, 0.08, 1.0), fg=(0.95, 0.96, 1.0, 1.0),
             ph=(0.45, 0.47, 0.52, 1.0), accent=(0.30, 0.60, 1.0, 1.0)):
        """Draw the closed control. Call draw_popup() afterwards (after all other widgets)."""
        self._rect = (x, y, w, h)
        rect(x, y, w, h, bg)
        if self.is_open:
            rect(x, y, w, 2, accent)
        label = self.value if self.value is not None else self.placeholder
        color = fg if self.value is not None else ph
        ty = y + (h - self.size) / 2 + 1
        text(x + self.PAD, ty, self.size, color, label)
        self._draw_caret(x, y, w, h)

    def draw_popup(self, mx=-1, my=-1,
                   bg=(0.10, 0.10, 0.13, 1.0), fg=(0.90, 0.92, 1.0, 1.0),
                   sel=(0.20, 0.40, 0.70, 0.9), hover=(0.16, 0.18, 0.24, 1.0),
                   sel_fg=(1.0, 1.0, 1.0, 1.0)):
        """Draw the open popup list below the control. No-op when closed.
        Pass current mouse coords so the hovered row is highlighted.
        Consumer should call this last in the draw callback so it renders on top."""
        if not self.is_open or not self._rect:
            return
        x, y, w, h = self._rect
        n = min(len(self.options), self._MAX_ROWS)
        pop_h = n * self.ROW_H
        py = y - pop_h            # drop below the control
        rect(x, py, w, pop_h, bg)
        self._option_rects = []
        for i, opt in enumerate(self.options[:n]):
            ry = py + (n - 1 - i) * self.ROW_H   # top option at top of popup
            r = (x, ry, w, self.ROW_H)
            self._option_rects.append(r)
            is_sel = opt == self.value
            is_hov = hit(r, mx, my)
            fill = sel if is_sel else (hover if is_hov else None)
            if fill:
                rect(x, ry, w, self.ROW_H, fill)
            text(x + self.PAD, ry + (self.ROW_H - self.size) / 2 + 1,
                 self.size, sel_fg if is_sel else fg, opt)

    def on_click(self, mx, my):
        """Handle a left-click. Returns True if consumed.

        Contract:
        - Closed + click inside control  → open, return True.
        - Open + click on an option      → select, close, set just_selected=True, return True.
        - Open + click outside           → close, return True.
        - Closed + click outside         → return False (not our event).
        """
        self.just_selected = False
        if not self.is_open:
            if hit(self._rect, mx, my):
                self.is_open = True
                return True
            return False
        # open: check options first
        for i, r in enumerate(self._option_rects):
            if hit(r, mx, my):
                self.value = self.options[i]
                self.is_open = False
                self.just_selected = True
                return True
        # click outside while open → close
        self.is_open = False
        return True


# ---- pure-logic selftest (no GPU needed) -------------------------------------

class _FakeEvent:
    def __init__(self, type, value='PRESS', unicode='', ctrl=False, shift=False, alt=False):
        self.type = type; self.value = value; self.unicode = unicode
        self.ctrl = ctrl; self.shift = shift; self.alt = alt


def demo():
    """assert-based check of the editing logic. Returns a summary dict."""
    f = TextField()
    for ch in "hello":
        f.handle_event(_FakeEvent(ch.upper(), unicode=ch))
    assert f.text == "hello" and f.caret == 5, (f.text, f.caret)

    # caret left x2, insert mid-string
    f.handle_event(_FakeEvent('LEFT_ARROW'))
    f.handle_event(_FakeEvent('LEFT_ARROW'))
    f.handle_event(_FakeEvent('X', unicode='x'))
    assert f.text == "helxlo" and f.caret == 4, (f.text, f.caret)

    # backspace mid-string
    f.handle_event(_FakeEvent('BACK_SPACE'))
    assert f.text == "hello" and f.caret == 3, (f.text, f.caret)

    # delete forward
    f.handle_event(_FakeEvent('DEL'))
    assert f.text == "helo" and f.caret == 3, (f.text, f.caret)

    # shift+home selects to start, type replaces selection
    f.handle_event(_FakeEvent('END'))
    f.handle_event(_FakeEvent('HOME', shift=True))
    assert f.selected_text() == "helo", f.selected_text()
    f.handle_event(_FakeEvent('Z', unicode='Z'))
    assert f.text == "Z" and f.caret == 1, (f.text, f.caret)

    # select-all + delete
    f.set_text("abcdef")
    f.handle_event(_FakeEvent('A', ctrl=True))
    f.handle_event(_FakeEvent('BACK_SPACE'))
    assert f.text == "" and f.caret == 0, (f.text, f.caret)

    # clipboard round-trip
    f.set_text("copyme")
    f.handle_event(_FakeEvent('A', ctrl=True))
    f.handle_event(_FakeEvent('C', ctrl=True))
    f.handle_event(_FakeEvent('END'))
    f.handle_event(_FakeEvent('V', ctrl=True))
    assert f.text == "copymecopyme", f.text

    # RET/ESC/TAB are not consumed (consumer handles them)
    assert f.handle_event(_FakeEvent('RET')) is False
    assert f.handle_event(_FakeEvent('ESC')) is False

    demo_widgets()
    return {"ok": True, "final": f.text}


def demo_widgets():
    """assert-based checks for Dropdown and numeric TextField."""

    # --- Dropdown: open → select → close ---
    dd = Dropdown(options=["Alpha", "Beta", "Gamma"], placeholder="Pick one")
    assert dd.value is None
    assert not dd.is_open

    # Simulate draw() having set _rect (no GPU in headless mode)
    dd._rect = (10, 10, 200, 30)

    # Click inside closed control → opens
    assert dd.on_click(50, 20) is True
    assert dd.is_open

    # Simulate draw_popup() having set _option_rects for 3 options.
    # Popup goes below control: y=10, pop_h=3*26=78 → py=10-78=-68
    # draw_popup loop: ry = py + (n-1-i)*ROW_H → i=0(Alpha)→-16, i=1(Beta)→-42, i=2(Gamma)→-68
    # _option_rects appended in i order so index matches options list.
    dd._option_rects = [
        (10, -16, 200, 26),   # options[0]="Alpha" drawn at top of popup (highest ry)
        (10, -42, 200, 26),   # options[1]="Beta"
        (10, -68, 200, 26),   # options[2]="Gamma" at bottom
    ]

    # Click "Beta" (options[1], rect y=-42, extends to -42+26=-16)
    assert dd.on_click(50, -30) is True   # -30 is inside (-42 to -16)
    assert dd.value == "Beta"
    assert not dd.is_open
    assert dd.just_selected

    # Re-open, then click outside → closes, nothing selected
    dd._rect = (10, 10, 200, 30)
    dd.on_click(50, 20)     # open again
    assert dd.is_open
    dd._option_rects = [(10, -16, 200, 26), (10, -42, 200, 26), (10, -68, 200, 26)]
    dd.on_click(500, 500)   # outside → close
    assert not dd.is_open
    assert not dd.just_selected
    assert dd.value == "Beta"   # unchanged

    # Click outside while closed → not consumed
    assert dd.on_click(500, 500) is False

    # set_options resets state
    dd.set_options(["X", "Y"])
    assert dd.options == ["X", "Y"] and not dd.is_open

    # --- numeric TextField ---
    nf = TextField(numeric=True)
    for ch in "12a.3-":
        nf.handle_event(_FakeEvent(ch.upper(), unicode=ch))
    # 'a' rejected; '-' at non-zero caret rejected; second '.' rejected if already present
    assert nf.text == "12.3", repr(nf.text)
    assert nf.value() == 12.3, nf.value()

    # integer (no dot)
    nf2 = TextField(numeric=True)
    for ch in "42":
        nf2.handle_event(_FakeEvent(ch.upper(), unicode=ch))
    assert nf2.value() == 42
    assert isinstance(nf2.value(), int)

    # leading minus allowed at caret=0
    nf3 = TextField(numeric=True)
    for ch in "-7.5":
        nf3.handle_event(_FakeEvent(ch.upper(), unicode=ch))
    assert nf3.text == "-7.5", nf3.text
    assert nf3.value() == -7.5

    # empty → None
    nf4 = TextField(numeric=True)
    assert nf4.value() is None

    # numeric=False field unaffected (letters still work)
    plain = TextField()
    assert plain.value() is None   # always None when not numeric


# ---- live test harness (a window with real editable fields) ------------------
# Doubles as the reference for how a module consumes TextField from a modal.

_TEST_HANDLE = "_widget_test_handle"
_TEST_WIN_PTR = None
_TEST_FIELDS = []
_TEST_MOUSE = (-1, -1)
_TEST_DRAG = None     # the field currently being drag-selected


def _test_clear_handles():
    for h in bpy.app.driver_namespace.get(_TEST_HANDLE, []):
        try:
            bpy.types.SpaceView3D.draw_handler_remove(h, 'WINDOW')
        except Exception:
            pass
    bpy.app.driver_namespace[_TEST_HANDLE] = []


def _test_draw():
    try:
        ctx = bpy.context
        region = ctx.region
        win = ctx.window
        if region is None or win is None:
            return
        if _TEST_WIN_PTR is not None and win.as_pointer() != _TEST_WIN_PTR:
            return
        rect(0, 0, region.width, region.height, (0.11, 0.11, 0.13, 1.0))
        cx = max(60, (region.width - 560) / 2)
        top = region.height - 120
        text(cx, top + 50, 20, (0.95, 0.96, 1.0, 1.0), "GPU TextField — live test")
        text(cx, top + 24, 12, (0.55, 0.57, 0.63, 1.0),
             "click to focus · type · arrows/Home/End · Shift-select · Ctrl+A/C/X/V · Esc closes")
        labels = ["Field A (placeholder)", "Field B (prefilled)"]
        for i, f in enumerate(_TEST_FIELDS):
            fy = top - 30 - i * 96
            text(cx, fy + 34, 12, (0.6, 0.62, 0.68, 1.0), labels[i])
            f.draw(cx, fy, 460, 30)
            sel = f.selected_text()
            readout = "text=%r  caret=%d  sel=%r" % (f.text, f.caret, sel)
            text(cx, fy - 22, 12, (0.5, 0.7, 0.95, 1.0), readout)
    except Exception:
        import traceback
        traceback.print_exc()
    finally:
        try:
            gpu.state.blend_set('NONE')
        except Exception:
            pass


def _biggest_area(screen):
    best = None
    for a in screen.areas:
        if best is None or a.width * a.height > best.width * best.height:
            best = a
    return best


class KBD_OT_widget_test(bpy.types.Operator):
    bl_idname = "kbd.widget_test"
    bl_label = "Widget Test (overlay)"
    bl_options = {'INTERNAL'}

    def invoke(self, context, event):
        global _TEST_WIN_PTR, _TEST_FIELDS, _TEST_DRAG
        self._win = context.window
        _TEST_WIN_PTR = context.window.as_pointer()
        _TEST_FIELDS = [TextField(placeholder="type here…"),
                        TextField(text="edit me — Ctrl+A then type")]
        _TEST_DRAG = None
        _test_clear_handles()
        self._handle = bpy.types.SpaceView3D.draw_handler_add(_test_draw, (), 'WINDOW', 'POST_PIXEL')
        bpy.app.driver_namespace.setdefault(_TEST_HANDLE, []).append(self._handle)
        context.window_manager.modal_handler_add(self)
        for a in context.window.screen.areas:
            a.tag_redraw()
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        global _TEST_MOUSE, _TEST_DRAG
        if self._win is not None:
            try:
                for a in self._win.screen.areas:
                    a.tag_redraw()
            except Exception:
                pass
        in_win = (context.window is not None and _TEST_WIN_PTR is not None
                  and context.window.as_pointer() == _TEST_WIN_PTR)

        if event.type == 'MOUSEMOVE':
            if in_win:
                _TEST_MOUSE = (event.mouse_region_x, event.mouse_region_y)
                if _TEST_DRAG is not None:
                    _TEST_DRAG.on_drag(*_TEST_MOUSE)
                    return {'RUNNING_MODAL'}
            return {'PASS_THROUGH'}

        if event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
            _TEST_DRAG = None
            return {'RUNNING_MODAL'} if in_win else {'PASS_THROUGH'}

        # route keys to the focused field first
        focused = next((f for f in _TEST_FIELDS if f.focused), None)
        if focused is not None and event.value == 'PRESS' and event.type not in (
                'LEFTMOUSE', 'RIGHTMOUSE', 'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE',
                'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE'):
            if focused.handle_event(event):
                return {'RUNNING_MODAL'}
            if event.type in ('RET', 'NUMPAD_ENTER'):
                focused.focused = False
                return {'RUNNING_MODAL'}
            # ESC falls through to close

        if event.type in {'ESC', 'RIGHTMOUSE'} and event.value == 'PRESS':
            self._finish(context)
            return {'CANCELLED'}

        if event.type == 'LEFTMOUSE' and event.value == 'PRESS' and in_win:
            mx, my = event.mouse_region_x, event.mouse_region_y
            for f in _TEST_FIELDS:
                if f.on_click(mx, my, extend=event.shift):
                    _TEST_DRAG = f
                else:
                    f.focused = False
            return {'RUNNING_MODAL'}

        return {'PASS_THROUGH'}

    def _finish(self, context):
        global _TEST_WIN_PTR
        h = getattr(self, "_handle", None)
        if h is not None:
            try:
                bpy.types.SpaceView3D.draw_handler_remove(h, 'WINDOW')
            except Exception:
                pass
            handles = bpy.app.driver_namespace.get(_TEST_HANDLE, [])
            if h in handles:
                handles.remove(h)
            self._handle = None
        _TEST_WIN_PTR = None
        win = getattr(self, "_win", None)
        if win is not None:
            try:
                with context.temp_override(window=win):
                    bpy.ops.wm.window_close()
            except Exception:
                pass


class KBD_OT_widget_test_window(bpy.types.Operator):
    bl_idname = "kbd.widget_test_window"
    bl_label = "Widget Test"
    bl_description = "Open the GPU widget test in its own window"

    def execute(self, context):
        prev = set(context.window_manager.windows)
        try:
            bpy.ops.wm.window_new()
        except Exception as e:
            self.report({'ERROR'}, f"could not open window: {e}")
            return {'CANCELLED'}
        new = [w for w in context.window_manager.windows if w not in prev]
        if not new:
            return {'CANCELLED'}
        win = new[-1]
        area = _biggest_area(win.screen)
        try:
            if area.type != 'VIEW_3D':
                area.type = 'VIEW_3D'
            sp = area.spaces.active
            sp.show_region_ui = False
            sp.show_region_toolbar = False
            sp.show_region_header = False
            if hasattr(sp, "overlay"):
                sp.overlay.show_overlays = False
            sp.show_gizmo = False
        except Exception:
            pass
        region = next((r for r in area.regions if r.type == 'WINDOW'), None)
        with context.temp_override(window=win, area=area, region=region):
            bpy.ops.kbd.widget_test('INVOKE_DEFAULT')
        return {'FINISHED'}


def register_test():
    _test_clear_handles()
    bpy.utils.register_class(KBD_OT_widget_test)
    bpy.utils.register_class(KBD_OT_widget_test_window)


def unregister_test():
    _test_clear_handles()
    for c in (KBD_OT_widget_test_window, KBD_OT_widget_test):
        try:
            bpy.utils.unregister_class(c)
        except Exception:
            pass
