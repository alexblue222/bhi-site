"""GPU-drawn visual keyboard in a DEDICATED WINDOW, with a side inspector.

Opens its own Blender window (drag it to another monitor), draws a big crisp keyboard
on the left and an inspector panel on the right listing the selected key's assigned
shortcuts — including multi-modifier combos (Ctrl+Shift+F). Reuses keymap_engine +
key_layout + the shared window_manager.kbd_state.

Hard-won rules baked in:
- The draw callback NEVER touches the operator instance (its RNA is freed after a
  script-invoked modal -> ReferenceError -> black viewport). All draw state is module-level.
- The whole draw body is guarded; a draw error can never corrupt GL.
- Draw handles are tracked in driver_namespace so reloads can always clean up.
- Drawing is confined to the dedicated window via a window-pointer check.
"""
import bpy
import gpu
import blf
from bpy.props import StringProperty
from gpu_extras.batch import batch_for_shader

from . import keymap_engine as engine
from . import key_layout
from . import library_db
from . import library_view

_shader = gpu.shader.from_builtin('UNIFORM_COLOR')
_FONT = 0

# key metrics
KEY = 48
GAP = 5
PAD = 14
UNIT = KEY + GAP

# colours
EMPTY_FILL = (0.20, 0.20, 0.23)
BORDER = (0.34, 0.34, 0.40)
BORDER_SEL = (0.97, 0.85, 0.20)
BOARD_BG = (0.10, 0.10, 0.12, 0.96)
PANEL_BG = (0.13, 0.13, 0.16, 0.97)

# Host the overlay in the TEXT EDITOR, not a 3D viewport — a flat 2D space with no
# scene, so there's no cube/grid behind our opaque background (the viewport always
# rendered the scene underneath). Draw handlers register per space type.
_DRAW_SPACE = bpy.types.SpaceTextEditor
_HOST_AREA_TYPE = 'TEXT_EDITOR'

# module-level draw state (never store on the operator)
_HANDLE_KEY = "_kbd_gpu_handles"
_KEY_RECTS = {}
_RIBBON_RECTS = {}
_TAB_RECTS = {}
_MOD_RECTS = {}
_BTN_RECTS = {}
_TARGET_WIN_PTR = None

# scripts panel + hover state
_MOUSE = (-1, -1)
_HOVER_ROWS = []          # [(rect, item)] hoverable rows -> tooltip (item has idname/label/desc)
_PANEL_ROWS = []          # [(rect, item)] script rows -> click to arm
_LIB_BTN_RECTS = []       # [(rect, "fav"|"hide", item)] per-row library toggles
_LIB_TOGGLE_RECT = None   # rect for the "show hidden" toggle in the library header
_SHOW_HIDDEN = False      # library: reveal hidden scripts
_LIB_REGION = None        # (x, y, w, h) of the embedded SQL table — for event routing
_SEARCH = ""
_SEARCH_FOCUSED = False
_SEARCH_RECT = None
_SCROLL = 0               # first visible row index in the script list
_ARMED = None             # operator armed for binding: {idname,label,...}
_HILITE = set()           # key_types the selected/armed operator is bound to
_FILTER_CACHE = {"sig": None, "items": []}
_SCROLLBAR = None         # {"track":(x,y,w,h), "track_top","track_h","thumb_h","max_scroll"}
_DRAGGING_SCROLLBAR = False
_TRACKPAD_ACCUM = 0.0     # fractional rows owed, for smooth-scroll mice/trackpads

# native-edit UI state (inspector combo rows + action bar)
_COMBO_ROW_RECTS = []     # [(rect, combo_dict)] — clickable combo rows in inspector
_NATIVE_ACTION_RECTS = {} # {"rebind"|"change_op"|"disable"|"restore": rect} — action bar buttons
_SELECTED_COMBO = None    # combo dict currently selected in the inspector
_ARMED_REBIND = None      # combo dict being moved (next key click = new destination)
_RESTORE_ALL_RECT = None  # rect for the "N native edits — Restore All" button
_CHANGE_OP = None         # change-op flow: {key,ctrl,alt,shift,old_label,new} or None
_CHANGE_RECTS = {}        # {"confirm"|"cancel": rect} for the change-op confirm bar

# inspector 8-slot redesign
_SHOW_ALL_SLOTS = False   # reveal all 8 modifier slots (empties shown as "+ assign")
_SLOT_RECTS = []          # [(rect, sig, combo_or_None)] — clickable binding slots
_SLOT_HOVER = []          # [(rect, sig, combo)] — conflicted slots (hover → doubles tooltip)
_SETTINGS_RECTS = {}      # {"show_all"|"restore_all": rect} — inspector top-right controls
_ASSIGN_PENDING = None    # {"key","ctrl","alt","shift"} — a "+ assign" slot awaiting a library pick
_BIND_ACTION_RECTS = []   # [(rect, "rebind"|"change"|"remove", binding, combo)] — per-binding buttons
_RESTORE_COMBO_RECT = None  # (rect, key_type, combo) — "restore this combo to factory" footer
_CHANGE_PENDING = None    # {"key","ctrl","alt","shift","idname","kc"} — awaiting a library pick
_BTN_TIPS = []            # [(rect, tip)] — hover tooltips for small icon buttons

# fixed slot order: plain, Ctrl, Shift, Alt, Ctrl+Shift, Ctrl+Alt, Alt+Shift, Ctrl+Alt+Shift
_SLOT_ORDER = [(False, False, False), (True, False, False), (False, False, True), (False, True, False),
               (True, False, True), (True, True, False), (False, True, True), (True, True, True)]


def _slot_label(sig):
    c, a, s = sig
    return " + ".join(x for x, on in (("Ctrl", c), ("Alt", a), ("Shift", s)) if on) or "(plain)"


def _in_lib(mx, my):
    """True if (mx,my) is inside the embedded SQL library region."""
    if _LIB_REGION is None:
        return False
    x, y, w, h = _LIB_REGION
    return x <= mx <= x + w and y <= my <= y + h


def _star(x, y, on):
    """Favourite star (drawn, not a font glyph): gold when on, dim when off."""
    col = (0.96, 0.78, 0.25, 1.0) if on else (0.30, 0.32, 0.37, 1.0)
    _rect(x + 4, y + 1, 4, 11, col)
    _rect(x + 1, y + 4, 10, 4, col)
    _rect(x + 2, y + 2, 8, 2, col)
    _rect(x + 2, y + 9, 8, 2, col)


def _eye(x, y, hidden):
    """Hide toggle: an eye; slashed + red when the row is hidden."""
    col = (0.90, 0.45, 0.42, 1.0) if hidden else (0.42, 0.45, 0.51, 1.0)
    _rect(x + 1, y + 4, 11, 5, col)
    _rect(x + 3, y + 5, 7, 3, (0.12, 0.12, 0.15, 1.0))
    _rect(x + 5, y + 6, 3, 1, col)
    if hidden:
        _rect(x, y + 2, 13, 2, (0.95, 0.35, 0.35, 0.9))


def _draw_slot_detail(context, tx, sy, inner_w, key_type, combo, slots_bot, enabled):
    """Inline expansion under a selected bound slot. EVERY binding at this combo gets its
    OWN row with a ↻ rebind + ✕ remove button (a combo can hold several — native + ours +
    other add-ons — and each must be actionable individually). A 'restore to Blender
    default' footer resets the whole combo. Returns the new sy."""
    global _RESTORE_COMBO_RECT
    allb = engine.bindings_at(context, key_type, combo["ctrl"], combo["alt"], combo["shift"], enabled)
    dy = sy - 2
    row_h, bsz = 22, 22
    for i, b in enumerate(allb):
        if dy - row_h < slots_bot + 26:                       # keep room for the footer
            _text(tx + 8, dy - 13, 10, (0.6, 0.62, 0.68, 1.0), f"+{len(allb) - i} more…")
            dy -= 14
            break
        rowy = dy - row_h
        armed = (_ARMED_REBIND is not None and _ARMED_REBIND.get("idname") == b["idname"]
                 and _ARMED_REBIND.get("_src_key") == key_type
                 and _ARMED_REBIND.get("ctrl") == combo["ctrl"]
                 and _ARMED_REBIND.get("alt") == combo["alt"]
                 and _ARMED_REBIND.get("shift") == combo["shift"])
        if armed:
            _rect(tx - 4, rowy, inner_w + 8, row_h, (0.14, 0.24, 0.42, 1.0))
            _text(tx + 6, rowy + 6, 10, (0.20, 0.70, 1.0, 1.0),
                  "press / click a key (with mods) to move it here · Esc cancels")
        else:
            tcol = (0.45, 0.85, 0.50, 1.0) if i == 0 else (0.85, 0.45, 0.40, 1.0)
            _text(tx + 6, rowy + 6, 11, tcol, "✓" if i == 0 else "✗")
            ncol = (0.96, 0.97, 1.0, 1.0) if i == 0 else (0.78, 0.80, 0.86, 1.0)
            # show a plugin/source tag only for non-native add-on bindings (native = no tag)
            src = b.get("source") or ""
            origin = f" · {src}" if src and src not in ("Blender", "Other") else ""
            _text(tx + 22, rowy + 6, 11, ncol, f"{b['label'][:18]}{origin}"[:28])
            # three right-aligned icon buttons: ↻ rebind key · op change · ✕ remove
            for j, (act, glyph, bg, fg, tip) in enumerate((
                ("rebind", "↻", (0.18, 0.30, 0.50, 1.0), (0.90, 0.93, 0.98, 1.0),
                 "Rebind — move this shortcut to a different key"),
                ("change", "op", (0.20, 0.32, 0.22, 1.0), (0.86, 0.95, 0.88, 1.0),
                 "Change — bind a different operator to this key"),
                ("remove", "✕", (0.50, 0.20, 0.18, 1.0), (1.0, 0.82, 0.80, 1.0),
                 "Remove this shortcut"),
            )):
                bx = tx + inner_w - (3 - j) * (bsz + 4) - 2
                r = (bx, rowy + 1, bsz, row_h - 2)
                _rect(*r, bg)
                blf.size(_FONT, 11)
                gw_, _gh = blf.dimensions(_FONT, glyph)
                _text(bx + (bsz - gw_) / 2, rowy + 6, 11, fg, glyph)
                _BIND_ACTION_RECTS.append((r, act, b, combo))
                _BTN_TIPS.append((r, tip))
        dy -= row_h
    # footer: restore this combo to Blender factory default
    fy = max(dy - 22, slots_bot)
    _rect(tx - 4, fy, inner_w + 8, 20, (0.24, 0.22, 0.14, 1.0))
    _text(tx + 6, fy + 5, 11, (0.95, 0.88, 0.62, 1.0),
          f"↺ restore {_slot_label((combo['ctrl'], combo['alt'], combo['shift']))}+{key_type} to default")
    _RESTORE_COMBO_RECT = ((tx - 4, fy, inner_w + 8, 20), key_type, combo)
    return fy - 8

# keyboard event types that are never "the key being bound" — mouse buttons/moves,
# and (separately) the bare modifier keys themselves (Ctrl+G binds under G, not under
# a press of Ctrl alone).
_MOUSE_EVENT_TYPES = {'LEFTMOUSE', 'RIGHTMOUSE', 'MIDDLEMOUSE', 'WHEELUPMOUSE',
                      'WHEELDOWNMOUSE', 'BUTTON4MOUSE', 'BUTTON5MOUSE', 'MOUSEMOVE',
                      'INBETWEEN_MOUSEMOVE', 'TRACKPADPAN', 'TRACKPADZOOM', 'MOUSEROTATE'}
_PURE_MODIFIER_KEYS = {'LEFT_SHIFT', 'RIGHT_SHIFT', 'LEFT_CTRL', 'RIGHT_CTRL',
                       'LEFT_ALT', 'RIGHT_ALT', 'OSKEY'}


_LIB_SYNCED = False


def _ensure_library_synced():
    """Mirror the live operator scan into SQLite once per session (Blender = truth).
    Lazy so it runs the first time the library is drawn, after all add-ons registered."""
    global _LIB_SYNCED
    if not _LIB_SYNCED:
        try:
            library_db.sync(engine.catalog())
        except Exception as e:
            print(f"[kbd] library sync failed: {e}")
        _LIB_SYNCED = True


def _filtered_catalog():
    _ensure_library_synced()
    q = _SEARCH.lower().strip()
    sig = (q, frozenset(_enabled_set()), _SHOW_HIDDEN, _FILTER_CACHE.get("bump", 0))
    if _FILTER_CACHE["sig"] != sig:
        out = []
        # DB gives favourites-first + hidden-excluded + persisted meta; source filter
        # (the ribbon is multi-select) + name/plugin search stay in Python.
        for it in library_db.query(include_hidden=_SHOW_HIDDEN):
            if not _SOURCE_ENABLED.get(it["source"], True):
                continue
            if q and q not in it["label"].lower() and q not in it["idname"].lower() \
               and q not in (it["source"] or "").lower():
                continue
            out.append(it)
        _FILTER_CACHE["sig"] = sig
        _FILTER_CACHE["items"] = out
    return _FILTER_CACHE["items"]


def _library_refresh():
    """Force the library list to re-query after a favourite/hide toggle."""
    _FILTER_CACHE["bump"] = _FILTER_CACHE.get("bump", 0) + 1

# source filter (the ribbon): label -> enabled bool. Populated from the live keymap.
_SOURCE_ENABLED = {}
# cache so continuous modal redraws don't re-scan the keymap every frame.
# src_mode uses a distinct sentinel because context.mode can read as None in a draw
# callback — a plain None init would falsely match and skip the first scan.
_UNSET = object()
_CACHE = {"src_mode": _UNSET, "sources": [], "state_sig": None, "states": {}}
RIBBON_ON = (0.24, 0.45, 0.78, 1.0)
RIBBON_OFF = (0.16, 0.16, 0.19, 1.0)


def _enabled_set():
    return {s for s, on in _SOURCE_ENABLED.items() if on}


def _invalidate():
    _CACHE["state_sig"] = None
    _CACHE["src_mode"] = _UNSET


def _get_draw_data(context, am):
    """Cached (sources, states). Re-scans only when mode/filter/enabled-set changes."""
    ktypes = [k["type"] for k in key_layout.all_keys()]
    mode = engine.get_view_mode() or getattr(context, "mode", None)
    if _CACHE["src_mode"] != mode:
        sources = engine.available_sources(context, ktypes)
        for s in sources:
            _SOURCE_ENABLED.setdefault(s, True)
        # also seed catalog sources so soloing a ribbon plugin correctly filters the
        # script library (otherwise catalog-only sources default-on and leak through solo)
        for it in engine.catalog():
            _SOURCE_ENABLED.setdefault(it["source"], True)
        _CACHE["sources"] = sources
        _CACHE["src_mode"] = mode
    sources = _CACHE["sources"]
    enabled = _enabled_set()
    sig = (am["ctrl"], am["alt"], am["shift"], frozenset(enabled), mode)
    if _CACHE["state_sig"] != sig:
        _CACHE["states"] = {
            k["id"]: engine.key_state(context, k["type"], am, enabled)
            for k in key_layout.all_keys()
        }
        _CACHE["bound_idx"] = engine.bound_index(context, enabled)  # idname -> hotkey label
        _CACHE["state_sig"] = sig
    return sources, _CACHE["states"]


def _clear_handles():
    for h in bpy.app.driver_namespace.get(_HANDLE_KEY, []):
        try:
            _DRAW_SPACE.draw_handler_remove(h, 'WINDOW')
        except Exception:
            pass
    bpy.app.driver_namespace[_HANDLE_KEY] = []


def _rgba(rgb, a=1.0):
    return (rgb[0], rgb[1], rgb[2], a)


def _rect(x, y, w, h, color):
    verts = ((x, y), (x + w, y), (x + w, y + h), (x, y + h))
    batch = batch_for_shader(_shader, 'TRI_FAN', {"pos": verts})
    _shader.bind()
    _shader.uniform_float("color", color)
    batch.draw(_shader)


def _text(x, y, size, color, s):
    blf.size(_FONT, size)
    blf.color(_FONT, *color)
    blf.position(_FONT, x, y, 0)
    blf.draw(_FONT, s)


def _wrap(text, size, max_w):
    """Word-wrap `text` to lines no wider than max_w pixels at the given font size."""
    if not text:
        return []
    blf.size(_FONT, size)
    lines, cur = [], ""
    for word in text.split():
        t = (cur + " " + word).strip()
        if blf.dimensions(_FONT, t)[0] <= max_w:
            cur = t
        else:
            if cur:
                lines.append(cur)
            cur = word
    if cur:
        lines.append(cur)
    return lines


def _update_scroll_from_mouse(my):
    """Map a track-relative mouse y to a scroll index (drag the thumb)."""
    global _SCROLL
    if not _SCROLLBAR:
        return
    track_top = _SCROLLBAR["track_top"]
    track_h = _SCROLLBAR["track_h"]
    thumb_h = _SCROLLBAR["thumb_h"]
    max_scroll = _SCROLLBAR["max_scroll"]
    usable = track_h - thumb_h
    if max_scroll <= 0 or usable <= 0:
        _SCROLL = 0
        return
    frac = (track_top - thumb_h / 2 - my) / usable
    _SCROLL = max(0, min(max_scroll, round(frac * max_scroll)))


def _board_size():
    cols, rows = key_layout.grid_extent()
    return cols * UNIT - GAP, rows * UNIT - GAP


def _active_mods(st):
    return {"shift": st.shift, "ctrl": st.ctrl, "alt": st.alt}


def _draw_callback():
    try:
        _draw_board()
    except Exception:
        import traceback
        traceback.print_exc()
    finally:
        try:
            gpu.state.blend_set('NONE')
        except Exception:
            pass


def _draw_board():
    global _SEARCH_RECT, _SCROLL, _SCROLLBAR, \
        _COMBO_ROW_RECTS, _NATIVE_ACTION_RECTS, _RESTORE_ALL_RECT, _RESTORE_COMBO_RECT, \
        _LIB_TOGGLE_RECT, _LIB_REGION
    context = bpy.context
    region = context.region
    win = context.window
    if region is None or win is None:
        return
    # confine drawing to the dedicated window
    if _TARGET_WIN_PTR is not None and win.as_pointer() != _TARGET_WIN_PTR:
        return

    st = context.window_manager.kbd_state
    am = _active_mods(st)
    bw, bh = _board_size()
    sources, states = _get_draw_data(context, am)
    enabled = _enabled_set()

    panel_w = 360
    total_w = bw + 40 + panel_w
    free = region.width - total_w
    ox = max(40, free * 0.25)                       # biased left → space on the right

    # vertically centre the whole [tabs | ribbon | board | scripts panel] stack
    PANEL_H = 360
    stack_h = 26 + 12 + 26 + 30 + bh + PAD + 16 + PANEL_H
    stack_top = (region.height + stack_h) / 2
    ty = stack_top - 26                             # tabs / modifier row
    ry = ty - 12 - 26                               # ribbon row
    oy = ry - 30 - bh                               # board bottom-edge region

    gpu.state.blend_set('ALPHA')
    _rect(0, 0, region.width, region.height, (0.11, 0.11, 0.13, 1.0))
    _HOVER_ROWS.clear()
    _PANEL_ROWS.clear()
    _LIB_BTN_RECTS.clear()
    _COMBO_ROW_RECTS.clear()
    _NATIVE_ACTION_RECTS.clear()
    _SLOT_RECTS.clear()
    _SLOT_HOVER.clear()
    _SETTINGS_RECTS.clear()
    _BIND_ACTION_RECTS.clear()
    _BTN_TIPS.clear()
    _RESTORE_ALL_RECT = None
    _RESTORE_COMBO_RECT = None

    # ---- context tabs + modifier toggles (same row) ----
    _TAB_RECTS.clear()
    _MOD_RECTS.clear()
    eff_mode = engine.get_view_mode() or getattr(context, "mode", None)
    _text(ox, ty + 30, 11, (0.5, 0.52, 0.58, 1.0), "CONTEXT")
    tx = ox
    for label, mode, _extra in engine.VIEW_MODES[:4]:
        on = (eff_mode == mode)
        blf.size(_FONT, 13)
        tw, _t = blf.dimensions(_FONT, label)
        bwid = tw + 24
        _rect(tx, ty, bwid, 26, (0.28, 0.42, 0.30, 1.0) if on else (0.16, 0.16, 0.19, 1.0))
        _text(tx + 12, ty + 7, 13, (1, 1, 1, 1) if on else (0.55, 0.55, 0.6, 1.0), label)
        _TAB_RECTS[mode] = (tx, ty, bwid, 26)
        tx += bwid + 6
    tx += 28
    _text(tx, ty + 30, 11, (0.5, 0.52, 0.58, 1.0), "MODIFIERS")
    for m, lbl in (("ctrl", "Ctrl"), ("alt", "Alt"), ("shift", "Shift")):
        on = getattr(st, m)
        col = _rgba(key_layout.MOD_COLORS[m]) if on else (0.16, 0.16, 0.19, 1.0)
        blf.size(_FONT, 13)
        tw, _t = blf.dimensions(_FONT, lbl)
        bwid = tw + 24
        _rect(tx, ty, bwid, 26, col)
        _text(tx + 12, ty + 7, 13, (0.05, 0.05, 0.05, 1.0) if on else (0.55, 0.55, 0.6, 1.0), lbl)
        _MOD_RECTS[m] = (tx, ty, bwid, 26)
        tx += bwid + 6

    # ---- source ribbon (Blender + plugins). click toggle · alt-click solo ----
    _RIBBON_RECTS.clear()
    _text(ox, ry + 30, 11, (0.5, 0.52, 0.58, 1.0), "PLUGIN FILTER")
    rx = ox
    for label in sources:
        on = _SOURCE_ENABLED.get(label, True)
        blf.size(_FONT, 13)
        tw, _t = blf.dimensions(_FONT, label)
        bwid = tw + 24
        _rect(rx, ry, bwid, 26, RIBBON_ON if on else RIBBON_OFF)
        _text(rx + 12, ry + 7, 13, (0.96, 0.97, 1.0, 1.0) if on else (0.5, 0.5, 0.55, 1.0), label)
        _RIBBON_RECTS[label] = (rx, ry, bwid, 26)
        rx += bwid + 6
    _text(rx + 10, ry + 7, 11, (0.42, 0.44, 0.5, 1.0), "click toggle · alt-click solo")

    # ---- keyboard board (full layout: grid units -> pixels) ----
    _rect(ox - PAD, oy - PAD, bw + 2 * PAD, bh + 2 * PAD, BOARD_BG)
    _KEY_RECTS.clear()
    for key in key_layout.placed_keys():
        left = ox + key["x"] * UNIT
        wpx = key["w"] * UNIT - GAP
        ky = (oy + bh - key["y"] * UNIT) - KEY
        state = states.get(key["id"]) or {"bound": False, "conflict": False, "variants": {}}
        fill = key_layout.FILL_BOUND if state["bound"] else EMPTY_FILL
        selected = (st.selected_key == key["id"])
        if selected:
            bcol = BORDER_SEL
        elif key["id"] in _HILITE:
            bcol = (0.20, 0.80, 0.92)        # armed/selected operator is bound here
        else:
            bcol = BORDER
        _rect(left - 2, ky - 2, wpx + 4, KEY + 4, _rgba(bcol))
        _rect(left, ky, wpx, KEY, _rgba(fill))
        v = state["variants"]
        dx = left + 5
        for m in ("shift", "ctrl", "alt"):
            if v.get(m):
                _rect(dx, ky + 5, 8, 8, _rgba(key_layout.MOD_COLORS[m]))
                dx += 11
        if state["conflict"]:
            _rect(left + wpx - 13, ky + KEY - 13, 10, 10, _rgba(key_layout.CONFLICT_COLOR))
        sz = 17 if len(key["label"]) <= 2 else 11
        blf.size(_FONT, sz)
        tw, th = blf.dimensions(_FONT, key["label"])
        _text(left + (wpx - tw) / 2, ky + (KEY - th) / 2, sz, (0.94, 0.94, 0.96, 1.0), key["label"])
        _KEY_RECTS[key["id"]] = (left, ky, wpx, KEY)

    # ---- side inspector: 8-slot binding panel ----
    px = ox + bw + 40
    py = oy - PAD
    ph = bh + 2 * PAD
    _rect(px, py, panel_w, ph, PANEL_BG)
    tx = px + 16
    inner_w = panel_w - 32
    _BTN_RECTS.clear()

    if not st.selected_key:
        _text(tx, py + ph - 44, 16, (0.7, 0.72, 0.78, 1.0), "Click a key to inspect")
        _text(tx, py + 14, 12, (0.5, 0.52, 0.57, 1.0), "Esc / right-click to close")
    else:
        combos = engine.key_combos(context, st.selected_key, enabled)
        sigmap = {(c["ctrl"], c["alt"], c["shift"]): c for c in combos}
        n_short = len(combos)
        n_conf = sum(1 for c in combos if c["conflict"])

        # header: explicit key name (no mods, no "plain") + summary
        _text(tx, py + ph - 34, 22, (0.95, 0.85, 0.30, 1.0), st.selected_key)
        summ = f"{n_short} shortcut{'s' if n_short != 1 else ''}"
        if n_conf:
            summ += f"   ·   {n_conf} conflict{'s' if n_conf != 1 else ''}"
        _text(tx, py + ph - 56, 12,
              (0.98, 0.62, 0.25, 1.0) if n_conf else (0.55, 0.58, 0.64, 1.0), summ)

        # top-right settings area: show-all toggle (+ Restore All when native edits exist)
        overrides = engine.list_overrides()
        sbw, sbh = 96, 22
        sx = px + panel_w - 16 - sbw
        sy_set = py + ph - 32
        on = _SHOW_ALL_SLOTS
        _rect(sx, sy_set, sbw, sbh, (0.26, 0.30, 0.40, 1.0) if on else (0.16, 0.17, 0.20, 1.0))
        _text(sx + 9, sy_set + 6, 11,
              (0.92, 0.94, 0.98, 1.0) if on else (0.60, 0.63, 0.70, 1.0),
              "✓ all 8 slots" if on else "show all 8")
        _SETTINGS_RECTS["show_all"] = (sx, sy_set, sbw, sbh)
        if overrides:
            ry_s = sy_set - sbh - 6
            _rect(sx, ry_s, sbw, sbh, (0.34, 0.20, 0.14, 1.0))
            _text(sx + 9, ry_s + 6, 11, (0.97, 0.80, 0.60, 1.0), f"restore {len(overrides)} edit(s)")
            _SETTINGS_RECTS["restore_all"] = (sx, ry_s, sbw, sbh)

        # ---- binding slots (fixed order; empties hidden unless "show all 8") ----
        ROW_H = 30
        slots_top = py + ph - 76
        slots_bot = py + 34
        show_sigs = _SLOT_ORDER if _SHOW_ALL_SLOTS else [s for s in _SLOT_ORDER if s in sigmap]
        if _SHOW_ALL_SLOTS:
            # clear box around the whole binding area (defined layout, 2px frame)
            fy, fh = slots_bot - 2, slots_top - slots_bot + 6
            _rect(tx - 8, fy, inner_w + 16, fh, (0.30, 0.32, 0.38, 1.0))
            _rect(tx - 6, fy + 2, inner_w + 12, fh - 4, PANEL_BG)
        sy = slots_top
        for sig in show_sigs:
            if sy - ROW_H < slots_bot:
                break
            combo = sigmap.get(sig)
            is_sel = (combo is not None and _SELECTED_COMBO is not None
                      and (_SELECTED_COMBO.get("ctrl"), _SELECTED_COMBO.get("alt"),
                           _SELECTED_COMBO.get("shift")) == sig)
            slot_rect = (tx - 4, sy - ROW_H + 4, inner_w + 8, ROW_H - 4)
            if _SHOW_ALL_SLOTS:
                _rect(*slot_rect, (0.10, 0.11, 0.13, 1.0))          # per-slot box
            if is_sel:
                _rect(*slot_rect, (0.18, 0.24, 0.36, 1.0))          # selected highlight
            _text(tx + 4, sy - 17, 12, (0.62, 0.66, 0.72, 1.0), _slot_label(sig))
            if combo:
                lab_col = (0.98, 0.62, 0.25, 1.0) if combo["conflict"] else (0.94, 0.96, 1.0, 1.0)
                _text(tx + 118, sy - 17, 13, lab_col, combo["label"][:24])
                if combo["conflict"]:
                    _rect(tx + inner_w - 14, sy - 19, 11, 11, (1.0, 0.55, 0.15, 1.0))  # orange flag
                    _SLOT_HOVER.append((slot_rect, sig, combo))
            else:
                _text(tx + 118, sy - 17, 13, (0.40, 0.72, 0.45, 1.0), "＋ assign")
            _SLOT_RECTS.append((slot_rect, sig, combo))
            sy -= ROW_H
            if _SHOW_ALL_SLOTS:
                _rect(tx - 6, sy + 3, inner_w + 12, 1, (0.20, 0.21, 0.25, 1.0))  # divider
            # expand the selected bound slot inline (one at a time): detail + action bar
            if is_sel:
                sy = _draw_slot_detail(context, tx, sy, inner_w, st.selected_key,
                                       combo, slots_bot, enabled)

        _text(tx, py + 14, 12, (0.5, 0.52, 0.57, 1.0), "Esc peels back  ·  right-click closes")

    # ---- script library panel (search + list), under the board ----
    pl = ox - PAD
    pw = bw + 2 * PAD
    ptop = oy - PAD - 14
    pbot = ptop - PANEL_H
    _rect(pl, pbot, pw, PANEL_H, (0.12, 0.12, 0.15, 0.98))
    _text(pl + 6, ptop - 15, 11, (0.5, 0.52, 0.58, 1.0),
          "SCRIPT LIBRARY   ·   SQL view — filters, saved views, pin/favourite/hide   ·   click a row then a key to bind")

    sb_x, sb_y, sb_w, sb_h = pl + 12, ptop - 42, 400, 26
    _rect(sb_x, sb_y, sb_w, sb_h, (0.06, 0.06, 0.08, 1.0))
    if _SEARCH_FOCUSED:
        _rect(sb_x, sb_y, sb_w, 2, (0.30, 0.60, 1.0, 1.0))
    shown = _SEARCH if (_SEARCH or _SEARCH_FOCUSED) else "Search actions…"
    scol = (0.95, 0.96, 1.0, 1.0) if _SEARCH else (0.45, 0.47, 0.52, 1.0)
    _text(sb_x + 10, sb_y + 7, 14, scol, shown + ("|" if _SEARCH_FOCUSED else ""))
    _SEARCH_RECT = (sb_x, sb_y, sb_w, sb_h)

    if _ARMED:
        _text(sb_x + sb_w + 20, sb_y + 6, 13, (0.20, 0.85, 0.95, 1.0),
              f"◆ binding: {_ARMED['label'][:22]} — click a key or press it")
    elif _ARMED_REBIND:
        _text(sb_x + sb_w + 20, sb_y + 6, 13, (0.40, 0.70, 1.0, 1.0),
              f"◆ moving: {_ARMED_REBIND['label'][:20]} — click target key · Esc")
    elif _ASSIGN_PENDING:
        ap = _ASSIGN_PENDING
        amods = "".join(x for x, on in (("Ctrl+", ap["ctrl"]), ("Alt+", ap["alt"]), ("Shift+", ap["shift"])) if on)
        _text(sb_x + sb_w + 20, sb_y + 6, 13, (0.40, 0.80, 0.50, 1.0),
              f"＋ assign to {amods}{ap['key']} — click a row · Esc")
    elif _CHANGE_PENDING:
        cp = _CHANGE_PENDING
        cmods = "".join(x for x, on in (("Ctrl+", cp["ctrl"]), ("Alt+", cp["alt"]), ("Shift+", cp["shift"])) if on)
        _text(sb_x + sb_w + 20, sb_y + 6, 13, (0.55, 0.85, 0.60, 1.0),
              f"change {cmods}{cp['key']} — click the new operator · Esc")

    # the embedded SQL table fills the region below the search box
    _ensure_library_synced()
    _LIB_REGION = (pl, pbot, pw, sb_y - 6 - pbot)
    library_view.draw(context, pl, pbot, pw, sb_y - 6 - pbot, _SEARCH,
                      hotkeys=_CACHE.get("bound_idx"))
    _SCROLLBAR = None   # library_view owns its own scrollbars

    # ---- hover tooltip (combo rows + script rows) ----
    mx, my = _MOUSE
    for rect, it in _HOVER_ROWS:
        x, y, w, h = rect
        if x <= mx <= x + w and y <= my <= y + h:
            lab, idn, desc = it.get("label", ""), it.get("idname", ""), it.get("desc", "")
            dlines = _wrap(desc, 11, 356)
            tw = 380
            th = 24 + 16 + len(dlines) * 15 + 12
            txx = min(mx + 16, region.width - tw - 8)
            tyy = max(my - th - 2, 8)
            _rect(txx, tyy, tw, th, (0.04, 0.04, 0.06, 0.98))
            _rect(txx, tyy + th - 3, tw, 3, (0.30, 0.60, 1.0, 1.0))
            yy = tyy + th - 22
            _text(txx + 12, yy, 14, (0.96, 0.97, 1.0, 1.0), lab[:48]); yy -= 18
            _text(txx + 12, yy, 11, (0.50, 0.68, 0.96, 1.0), idn); yy -= 16
            for dl in dlines:
                _text(txx + 12, yy, 11, (0.64, 0.66, 0.72, 1.0), dl); yy -= 15
            break

    # small-button tooltips (↻ rebind / op change / ✕ remove)
    for (x, y, w, h), tip in _BTN_TIPS:
        if x <= mx <= x + w and y <= my <= y + h:
            blf.size(_FONT, 11)
            tw2 = blf.dimensions(_FONT, tip)[0] + 20
            txx = min(mx + 14, region.width - tw2 - 8)
            tyy = max(my - 30, 8)
            _rect(txx, tyy, tw2, 22, (0.04, 0.04, 0.06, 0.98))
            _rect(txx, tyy + 19, tw2, 3, (0.30, 0.60, 1.0, 1.0))
            _text(txx + 10, tyy + 6, 11, (0.92, 0.94, 1.0, 1.0), tip)
            break

    # conflict tooltip: what's bound doubly on a flagged slot (fires vs shadowed)
    for rect, sig, combo in _SLOT_HOVER:
        x, y, w, h = rect
        if x <= mx <= x + w and y <= my <= y + h:
            allb = engine.bindings_at(context, st.selected_key, sig[0], sig[1], sig[2], enabled)
            tw = 380
            th = 26 + len(allb) * 15 + 12
            txx = min(mx + 16, region.width - tw - 8)
            tyy = max(my - th - 2, 8)
            _rect(txx, tyy, tw, th, (0.04, 0.04, 0.06, 0.98))
            _rect(txx, tyy + th - 3, tw, 3, (1.0, 0.55, 0.15, 1.0))
            yy = tyy + th - 22
            _text(txx + 12, yy, 13, (1.0, 0.70, 0.35, 1.0),
                  f"{_slot_label(sig)}+{st.selected_key} — {len(allb)} bound here"); yy -= 19
            for i, b in enumerate(allb):
                tcol = (0.45, 0.85, 0.50, 1.0) if i == 0 else (0.85, 0.45, 0.40, 1.0)
                _text(txx + 12, yy, 10, tcol, "✓ fires" if i == 0 else "✗ shadowed")
                _text(txx + 86, yy, 10, (0.82, 0.84, 0.90, 1.0),
                      f"{b['label'][:24]} · {b['keymap'][:14]}"); yy -= 15
            break

    gpu.state.blend_set('NONE')


def _biggest_area(screen):
    best = None
    for a in screen.areas:
        if best is None or a.width * a.height > best.width * best.height:
            best = a
    return best


class KBD_OT_assign_dialog(bpy.types.Operator):
    bl_idname = "kbd.assign_dialog"
    bl_label = "Assign Operator"
    bl_description = "Bind an operator to the selected key + active modifiers"

    idname: StringProperty(name="Operator", description="Operator id, e.g. transform.translate")

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=340)

    def draw(self, context):
        st = context.window_manager.kbd_state
        mods = "".join(x for x, on in (("Ctrl+", st.ctrl), ("Alt+", st.alt), ("Shift+", st.shift)) if on)
        self.layout.label(text=f"Bind to:  {mods}{st.selected_key}")
        self.layout.prop(self, "idname")

    def execute(self, context):
        st = context.window_manager.kbd_state
        if not st.selected_key:
            self.report({'WARNING'}, "No key selected")
            return {'CANCELLED'}
        res = engine.assign(self.idname.strip(), st.selected_key,
                            ctrl=st.ctrl, alt=st.alt, shift=st.shift)
        if not res.get("ok"):
            self.report({'ERROR'}, res.get("error") or "assign failed")
            return {'CANCELLED'}
        _invalidate()
        self.report({'INFO'}, f"Assigned {res['idname']}")
        return {'FINISHED'}


class KBD_OT_native_consent(bpy.types.Operator):
    """One-time consent dialog before any native (user) keymap edit.
    Mirrors KBD_OT_assign_dialog: invoke_props_dialog so it blocks until the user
    explicitly confirms or cancels — no accidental edits."""
    bl_idname = "kbd.native_consent"
    bl_label = "Edit Native Keymap?"
    bl_description = "Confirm before changing Blender's built-in keymap"
    bl_options = {'INTERNAL'}

    # pending_action is set by the caller before invoking so execute() can replay it.
    # ponytail: StringProperty instead of a cross-operator registry — simple & sufficient.
    pending_action: StringProperty(name="", default="", options={'HIDDEN'})

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=380)

    def draw(self, context):
        col = self.layout.column(align=True)
        col.label(text="This changes Blender's real keymap.", icon='ERROR')
        col.label(text="Every change is reversible via Restore / Restore All.")
        col.label(text="Continue?")

    def execute(self, context):
        engine.set_native_edits_consented(True)
        # ponytail: pending_action replay not needed yet — the user can just re-click
        # the button now that consent is granted. Add replay when callers need it.
        self.report({'INFO'}, "Native keymap editing enabled — changes are reversible")
        return {'FINISHED'}

    def cancel(self, context):
        return  # user said no; nothing to undo


class KBD_OT_keyboard_window(bpy.types.Operator):
    bl_idname = "kbd.keyboard_window"
    bl_label = "Keyboard Window"
    bl_description = "Open the visual keyboard in its own clean window (drag to another monitor)"

    def execute(self, context):
        prev = set(context.window_manager.windows)
        try:
            bpy.ops.wm.window_new()
        except Exception as e:
            self.report({'ERROR'}, f"could not open window: {e}")
            return {'CANCELLED'}
        new = [w for w in context.window_manager.windows if w not in prev]
        if not new:
            self.report({'ERROR'}, "no new window created")
            return {'CANCELLED'}
        win = new[-1]
        area = _biggest_area(win.screen)
        try:
            if area.type != _HOST_AREA_TYPE:
                area.type = _HOST_AREA_TYPE
            sp = area.spaces.active
            # a bare flat editor to paint the overlay onto — hide all its chrome.
            for attr in ("show_region_ui", "show_region_header", "show_region_footer",
                         "show_line_numbers", "show_syntax_highlight", "show_word_wrap"):
                if hasattr(sp, attr):
                    setattr(sp, attr, False)
        except Exception:
            pass
        region = next((r for r in area.regions if r.type == 'WINDOW'), None)
        # Invoke the modal INSIDE the new window so it receives that window's
        # events — otherwise clicks in the dedicated window never reach it.
        with context.temp_override(window=win, area=area, region=region):
            bpy.ops.kbd.gpu_keyboard('INVOKE_DEFAULT')
        return {'FINISHED'}


class KBD_OT_gpu_keyboard(bpy.types.Operator):
    bl_idname = "kbd.gpu_keyboard"
    bl_label = "Keyboard Overlay"
    bl_description = "Visual keyboard overlay (runs inside the keyboard window)"
    bl_options = {'INTERNAL'}

    def invoke(self, context, event):
        global _TARGET_WIN_PTR
        self._win = context.window
        _TARGET_WIN_PTR = context.window.as_pointer()
        _clear_handles()
        self._handle = _DRAW_SPACE.draw_handler_add(_draw_callback, (), 'WINDOW', 'POST_PIXEL')
        bpy.app.driver_namespace.setdefault(_HANDLE_KEY, []).append(self._handle)
        context.window_manager.modal_handler_add(self)
        for a in context.window.screen.areas:
            a.tag_redraw()
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        global _MOUSE, _SEARCH, _SEARCH_FOCUSED, _SCROLL, _ARMED, _HILITE, \
            _DRAGGING_SCROLLBAR, _TRACKPAD_ACCUM, \
            _SELECTED_COMBO, _ARMED_REBIND, _CHANGE_OP, \
            _SHOW_ALL_SLOTS, _ASSIGN_PENDING, _CHANGE_PENDING, _SHOW_HIDDEN
        if self._win is not None:
            try:
                for a in self._win.screen.areas:
                    a.tag_redraw()
            except Exception:
                pass

        in_win = (context.window is not None and _TARGET_WIN_PTR is not None
                  and context.window.as_pointer() == _TARGET_WIN_PTR)

        if event.type == 'MOUSEMOVE':
            if in_win:
                _MOUSE = (event.mouse_region_x, event.mouse_region_y)
                if _DRAGGING_SCROLLBAR:
                    _update_scroll_from_mouse(event.mouse_region_y)
                    return {'RUNNING_MODAL'}
                if library_view.handle_motion(event.mouse_region_x, event.mouse_region_y):
                    return {'RUNNING_MODAL'}
            return {'PASS_THROUGH'}

        if event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
            library_view.end_drag()

        if event.type == 'LEFTMOUSE' and event.value == 'RELEASE' and _DRAGGING_SCROLLBAR:
            _DRAGGING_SCROLLBAR = False
            return {'RUNNING_MODAL'}

        # live search typing — ONLY capture keyboard keys while focused.
        # Mouse events are also value=='PRESS'; capturing them would swallow every
        # click and lock the UI, so they must fall through to the handlers below.
        if _SEARCH_FOCUSED and event.value == 'PRESS' and event.type not in _MOUSE_EVENT_TYPES:
            if event.type in {'ESC', 'RET', 'NUMPAD_ENTER'}:
                _SEARCH_FOCUSED = False
            elif event.type == 'BACK_SPACE':
                _SEARCH = _SEARCH[:-1]
                _SCROLL = 0
            elif event.type == 'V' and (event.ctrl or event.oskey):
                # paste from the clipboard — sanitised: printable only, single-line,
                # length-capped, so a big/odd paste can never wedge the search or draw.
                try:
                    clip = bpy.context.window_manager.clipboard or ""
                except Exception:
                    clip = ""
                clip = "".join(c for c in clip if c.isprintable())[:120]
                _SEARCH = (_SEARCH + clip)[:200]
                _SCROLL = 0
            elif event.ascii and event.ascii.isprintable():
                _SEARCH = (_SEARCH + event.ascii)[:200]
                _SCROLL = 0
            return {'RUNNING_MODAL'}

        # assign-from-row capture: a library "Assign" click queued a row; the next real
        # key (with held modifiers) binds that operator to it.
        _cap = library_view.capture_row()
        if (_cap is not None and not _SEARCH_FOCUSED and in_win and event.value == 'PRESS'
                and event.type not in _MOUSE_EVENT_TYPES and event.type not in _PURE_MODIFIER_KEYS
                and event.type != 'ESC'):
            library_view.take_capture()
            r = engine.assign_native(context, _cap["idname"], event.type,
                                     ctrl=event.ctrl, alt=event.alt, shift=event.shift)
            if r.get("error") == "needs_consent":
                bpy.ops.kbd.native_consent('INVOKE_DEFAULT')
            _invalidate()
            library_view.invalidate()
            return {'RUNNING_MODAL'}

        # armed-rebind physical-key-press: moving an existing native binding to a new key.
        if (_ARMED_REBIND is not None and not _SEARCH_FOCUSED and in_win
                and event.value == 'PRESS' and event.type not in _MOUSE_EVENT_TYPES
                and event.type not in _PURE_MODIFIER_KEYS and event.type != 'ESC'):
            c = _ARMED_REBIND
            src_key = c.get("_src_key") or context.window_manager.kbd_state.selected_key
            res = engine.rebind_binding(
                context, src_key, c["ctrl"], c["alt"], c["shift"], c.get("idname"), c.get("kc"),
                event.type, event.ctrl, event.alt, event.shift,
            )
            if res.get("error") == "needs_consent":
                bpy.ops.kbd.native_consent('INVOKE_DEFAULT')
            elif not res.get("ok"):
                # surface error without crashing the modal
                print(f"[kbd] rebind failed: {res.get('error')}")
            else:
                st = context.window_manager.kbd_state
                st.selected_key = event.type
                _SELECTED_COMBO = None
                _invalidate()
            _ARMED_REBIND = None
            return {'RUNNING_MODAL'}

        # real-keypress binding: an operator is armed -> the next physical key (with
        # whatever ctrl/alt/shift is held) binds it directly, no click needed.
        if (_ARMED is not None and not _SEARCH_FOCUSED and in_win
                and event.value == 'PRESS' and event.type not in _MOUSE_EVENT_TYPES
                and event.type not in _PURE_MODIFIER_KEYS and event.type != 'ESC'):
            kid = event.type
            if kid in _KEY_RECTS:
                st = context.window_manager.kbd_state
                if _ARMED.get("_native_retarget"):
                    orig_key = _ARMED.get("_key_type", kid)
                    c = _ARMED
                    res = engine.set_operator_of(
                        context, orig_key, c["ctrl"], c["alt"], c["shift"], c["idname"],
                    )
                    if res.get("error") == "needs_consent":
                        bpy.ops.kbd.native_consent('INVOKE_DEFAULT')
                    elif not res.get("ok"):
                        print(f"[kbd] change_op failed: {res.get('error')}")
                else:
                    r = engine.assign_native(context, _ARMED["idname"], kid,
                                             ctrl=event.ctrl, alt=event.alt, shift=event.shift)
                    if r.get("error") == "needs_consent":
                        bpy.ops.kbd.native_consent('INVOKE_DEFAULT')
                st.selected_key = kid
                _ARMED = None
                _HILITE = set()
                _invalidate()
            return {'RUNNING_MODAL'}

        if event.type == 'ESC' and event.value == 'PRESS':
            if _CHANGE_OP is not None:
                _CHANGE_OP = None
                return {'RUNNING_MODAL'}
            if _ARMED_REBIND is not None:
                _ARMED_REBIND = None
                return {'RUNNING_MODAL'}
            if _ARMED is not None:
                _ARMED = None
                _HILITE = set()
                return {'RUNNING_MODAL'}
            if _ASSIGN_PENDING is not None:
                _ASSIGN_PENDING = None
                return {'RUNNING_MODAL'}
            if _CHANGE_PENDING is not None:
                _CHANGE_PENDING = None
                return {'RUNNING_MODAL'}
            if library_view.capture_row() is not None:
                library_view.take_capture()
                return {'RUNNING_MODAL'}
            # peel selection back: expanded binding -> key -> close window
            if _SELECTED_COMBO is not None:
                _SELECTED_COMBO = None
                return {'RUNNING_MODAL'}
            _st = context.window_manager.kbd_state
            if _st.selected_key:
                _st.selected_key = ""
                return {'RUNNING_MODAL'}
            self._finish(context)
            return {'CANCELLED'}

        if event.type == 'RIGHTMOUSE' and event.value == 'PRESS':
            self._finish(context)
            return {'CANCELLED'}

        if event.type in {'WHEELUPMOUSE', 'WHEELDOWNMOUSE'} and in_win:
            if _in_lib(*_MOUSE):
                library_view.handle_wheel(event.type == 'WHEELUPMOUSE', event.shift, _MOUSE[0], _MOUSE[1])
            else:
                _SCROLL = max(0, _SCROLL + (-3 if event.type == 'WHEELUPMOUSE' else 3))
            return {'RUNNING_MODAL'}

        # smooth-scroll mice / trackpads send TRACKPADPAN instead of discrete wheel
        # events — without this branch they fall through to PASS_THROUGH and the
        # hidden 3D viewport's own pan/zoom eats them instead of our list.
        if event.type == 'TRACKPADPAN' and in_win:
            _TRACKPAD_ACCUM += (event.mouse_y - event.mouse_prev_y) / 6.0
            step = int(_TRACKPAD_ACCUM)
            if step:
                if _in_lib(*_MOUSE):
                    library_view.handle_wheel(step < 0, event.shift, _MOUSE[0], _MOUSE[1])
                else:
                    _SCROLL = max(0, _SCROLL + step)
                _TRACKPAD_ACCUM -= step
            return {'RUNNING_MODAL'}

        if event.type == 'LEFTMOUSE' and event.value == 'PRESS' and in_win:
            _TRACKPAD_ACCUM = 0.0   # drop any owed fractional scroll so a click can't fire it
            mx, my = event.mouse_region_x, event.mouse_region_y
            st = context.window_manager.kbd_state
            # scrollbar track / thumb (drag to scroll)
            if _SCROLLBAR is not None:
                x, y, w, h = _SCROLLBAR["track"]
                if x <= mx <= x + w and y <= my <= y + h:
                    _DRAGGING_SCROLLBAR = True
                    _update_scroll_from_mouse(my)
                    return {'RUNNING_MODAL'}
            # search box focus
            if _SEARCH_RECT:
                x, y, w, h = _SEARCH_RECT
                if x <= mx <= x + w and y <= my <= y + h:
                    _SEARCH_FOCUSED = True
                    return {'RUNNING_MODAL'}
            _SEARCH_FOCUSED = False
            # context tabs
            for mode, (x, y, w, h) in list(_TAB_RECTS.items()):
                if x <= mx <= x + w and y <= my <= y + h:
                    engine.set_view_mode(mode)
                    _invalidate()
                    return {'RUNNING_MODAL'}
            # modifier filter toggles
            for m, (x, y, w, h) in list(_MOD_RECTS.items()):
                if x <= mx <= x + w and y <= my <= y + h:
                    setattr(st, m, not getattr(st, m))
                    _invalidate()
                    return {'RUNNING_MODAL'}
            # inspector settings area: show-all toggle, restore-all
            for sk, (x, y, w, h) in list(_SETTINGS_RECTS.items()):
                if x <= mx <= x + w and y <= my <= y + h:
                    if sk == "show_all":
                        _SHOW_ALL_SLOTS = not _SHOW_ALL_SLOTS
                    elif sk == "restore_all":
                        engine.restore_all()
                        _SELECTED_COMBO = None
                        _invalidate()
                    return {'RUNNING_MODAL'}
            # Restore All button
            if _RESTORE_ALL_RECT is not None:
                x, y, w, h = _RESTORE_ALL_RECT
                if x <= mx <= x + w and y <= my <= y + h:
                    engine.restore_all()
                    _SELECTED_COMBO = None
                    _invalidate()
                    return {'RUNNING_MODAL'}
            # change-op confirm / cancel bar
            for ck, (x, y, w, h) in list(_CHANGE_RECTS.items()):
                if x <= mx <= x + w and y <= my <= y + h:
                    if ck == "confirm" and _CHANGE_OP and _CHANGE_OP.get("new"):
                        co = _CHANGE_OP
                        res = engine.set_operator_of(context, co["key"], co["ctrl"], co["alt"],
                                                     co["shift"], co["new"]["idname"])
                        if res.get("error") == "needs_consent":
                            bpy.ops.kbd.native_consent('INVOKE_DEFAULT')
                            return {'RUNNING_MODAL'}   # keep staged; confirm again after consent
                        if not res.get("ok"):
                            print(f"[kbd] change_op failed: {res.get('error')}")
                        _CHANGE_OP = None
                        _SELECTED_COMBO = None
                        _invalidate()
                    else:
                        _CHANGE_OP = None              # cancel
                        _invalidate()
                    return {'RUNNING_MODAL'}
            # per-binding action buttons (↻ rebind / ✕ remove) in the expanded slot
            for (x, y, w, h), action, b, c in list(_BIND_ACTION_RECTS):
                if x <= mx <= x + w and y <= my <= y + h:
                    key_type = st.selected_key
                    if action == "rebind":
                        # arm THIS specific binding (idname+kc), capture its source coords;
                        # the next key press/click moves it and clears the old spot.
                        _ARMED_REBIND = {"idname": b["idname"], "kc": b.get("kc"),
                                         "_src_key": key_type, "ctrl": c["ctrl"],
                                         "alt": c["alt"], "shift": c["shift"]}
                        _ARMED = None
                        _HILITE = set()
                        _ASSIGN_PENDING = None
                        _CHANGE_PENDING = None
                    elif action == "change":
                        # arm change-operator: next library pick swaps the op on this binding.
                        _CHANGE_PENDING = {"key": key_type, "ctrl": c["ctrl"], "alt": c["alt"],
                                           "shift": c["shift"], "idname": b["idname"], "kc": b.get("kc")}
                        _ARMED = None
                        _HILITE = set()
                        _ASSIGN_PENDING = None
                        _ARMED_REBIND = None
                    elif action == "remove":
                        res = engine.remove_binding(context, key_type, c["ctrl"], c["alt"],
                                                    c["shift"], idname=b["idname"], kc=b.get("kc"))
                        if res.get("error") == "needs_consent":
                            bpy.ops.kbd.native_consent('INVOKE_DEFAULT')
                        _invalidate()
                    return {'RUNNING_MODAL'}
            # restore this combo to Blender factory default
            if _RESTORE_COMBO_RECT is not None:
                (x, y, w, h), rk, rc = _RESTORE_COMBO_RECT
                if x <= mx <= x + w and y <= my <= y + h:
                    engine.restore_combo(context, rk, rc["ctrl"], rc["alt"], rc["shift"])
                    _SELECTED_COMBO = None
                    _invalidate()
                    return {'RUNNING_MODAL'}
            # inspector binding slots — bound: toggle expand + sync mods; empty: arm "+ assign"
            for rect, sig, combo in list(_SLOT_RECTS):
                x, y, w, h = rect
                if x <= mx <= x + w and y <= my <= y + h:
                    # ponytail: sync modifier toggles to the slot — kills the papercut where
                    # toggle state and selection diverged.
                    st.ctrl, st.alt, st.shift = sig
                    if combo is None:
                        # empty slot: next library pick binds straight to this key+mods
                        _ASSIGN_PENDING = {"key": st.selected_key,
                                           "ctrl": sig[0], "alt": sig[1], "shift": sig[2]}
                        _SELECTED_COMBO = None
                    else:
                        already = (_SELECTED_COMBO is not None
                                   and (_SELECTED_COMBO.get("ctrl"), _SELECTED_COMBO.get("alt"),
                                        _SELECTED_COMBO.get("shift")) == sig)
                        _SELECTED_COMBO = None if already else combo  # click again = collapse
                        _ASSIGN_PENDING = None
                    _invalidate()
                    return {'RUNNING_MODAL'}
            # ribbon toggles (alt-click = solo)
            for label, (x, y, w, h) in list(_RIBBON_RECTS.items()):
                if x <= mx <= x + w and y <= my <= y + h:
                    if event.alt:
                        is_solo = _SOURCE_ENABLED.get(label) and all(
                            not v for s, v in _SOURCE_ENABLED.items() if s != label)
                        for s in _SOURCE_ENABLED:
                            _SOURCE_ENABLED[s] = True if is_solo else (s == label)
                    else:
                        _SOURCE_ENABLED[label] = not _SOURCE_ENABLED.get(label, True)
                    _invalidate()
                    return {'RUNNING_MODAL'}
            # embedded SQL library: delegate clicks in that region to library_view.
            # It handles filters/views/chips/pin-fav-hide/scroll/resize internally and
            # returns ("pick", row) when a row label is clicked (arm / change / assign).
            if _in_lib(mx, my):
                res = library_view.handle_click(mx, my)
                if isinstance(res, tuple) and res[0] == "pick":
                    it = res[1]
                    if _CHANGE_PENDING is not None:
                        cp = _CHANGE_PENDING
                        if cp.get("kc") == "addon":
                            engine.remove_binding(context, cp["key"], cp["ctrl"], cp["alt"],
                                                  cp["shift"], idname=cp["idname"], kc="addon")
                            r = engine.assign_native(context, it["idname"], cp["key"],
                                                     ctrl=cp["ctrl"], alt=cp["alt"], shift=cp["shift"])
                        else:
                            r = engine.set_operator_of(context, cp["key"], cp["ctrl"], cp["alt"],
                                                       cp["shift"], it["idname"], idname=cp["idname"])
                        if r.get("error") == "needs_consent":
                            bpy.ops.kbd.native_consent('INVOKE_DEFAULT')
                        else:
                            _CHANGE_PENDING = None
                        _invalidate()
                    elif _ASSIGN_PENDING is not None:
                        ap = _ASSIGN_PENDING
                        r = engine.assign_native(context, it["idname"], ap["key"],
                                                 ctrl=ap["ctrl"], alt=ap["alt"], shift=ap["shift"])
                        if r.get("error") == "needs_consent":
                            bpy.ops.kbd.native_consent('INVOKE_DEFAULT')
                        else:
                            _ASSIGN_PENDING = None
                        _invalidate()
                    else:
                        _ARMED = it
                        bound = engine.keys_bound_to(context, it["idname"])
                        _HILITE = {k[0] for k in bound}
                        if bound:
                            st.selected_key = bound[0][0]
                return {'RUNNING_MODAL'}
            # keys: if rebind is armed, the clicked key is the destination; if assign is
            # armed, bind it here; else just select.
            for kid, (x, y, w, h) in list(_KEY_RECTS.items()):
                if x <= mx <= x + w and y <= my <= y + h:
                    if _ARMED_REBIND is not None:
                        c = _ARMED_REBIND
                        src_key = c.get("_src_key") or st.selected_key
                        res = engine.rebind_binding(
                            context, src_key, c["ctrl"], c["alt"], c["shift"], c.get("idname"), c.get("kc"),
                            kid, st.ctrl, st.alt, st.shift,
                        )
                        if res.get("error") == "needs_consent":
                            bpy.ops.kbd.native_consent('INVOKE_DEFAULT')
                        elif not res.get("ok"):
                            print(f"[kbd] rebind failed: {res.get('error')}")
                        else:
                            _SELECTED_COMBO = None
                            _invalidate()
                        _ARMED_REBIND = None
                        st.selected_key = kid
                        return {'RUNNING_MODAL'}
                    if _ARMED is not None:
                        if _ARMED.get("_native_retarget"):
                            # Change-op flow: retarget an existing native binding's operator.
                            orig_key = _ARMED.get("_key_type", kid)
                            c = _ARMED
                            res = engine.set_operator_of(
                                context, orig_key, c["ctrl"], c["alt"], c["shift"],
                                c["idname"],
                            )
                            if res.get("error") == "needs_consent":
                                bpy.ops.kbd.native_consent('INVOKE_DEFAULT')
                            elif not res.get("ok"):
                                print(f"[kbd] change_op failed: {res.get('error')}")
                            _invalidate()
                        else:
                            r = engine.assign_native(context, _ARMED["idname"], kid,
                                                     ctrl=st.ctrl, alt=st.alt, shift=st.shift)
                            if r.get("error") == "needs_consent":
                                bpy.ops.kbd.native_consent('INVOKE_DEFAULT')
                        _ARMED = None
                        _HILITE = set()
                        _invalidate()
                    st.selected_key = kid
                    return {'RUNNING_MODAL'}
            return {'PASS_THROUGH'}

        return {'PASS_THROUGH'}

    def _finish(self, context):
        global _TARGET_WIN_PTR
        h = getattr(self, "_handle", None)
        if h is not None:
            try:
                _DRAW_SPACE.draw_handler_remove(h, 'WINDOW')
            except Exception:
                pass
            handles = bpy.app.driver_namespace.get(_HANDLE_KEY, [])
            if h in handles:
                handles.remove(h)
            self._handle = None
        _TARGET_WIN_PTR = None
        win = getattr(self, "_win", None)
        if win is not None:
            try:
                with context.temp_override(window=win):
                    bpy.ops.wm.window_close()
            except Exception:
                pass


def selftest_native(context):
    """Headless consent-gate + rebind/restore round-trip via the engine. No window needed.

    Asserts:
      1. consent=False blocks edit ops with 'needs_consent'.
      2. set_native_edits_consented(True) unblocks them.
      3. rebind_existing moves the binding and records an override.
      4. restore_one returns it and drops the override.
    Restores prior consent + overrides state — leaves no trace.

    Run in Blender's Python console / Script editor:
        import keyboard_proto.gpu_keyboard as gk; print(gk.selftest_native(bpy.context))
    Or via execute_blender_code:
        import keyboard_proto.gpu_keyboard as gk; print(gk.selftest_native(bpy.context))
    """
    checks = []
    ok = True

    def check(name, cond):
        nonlocal ok
        cond = bool(cond)
        ok = ok and cond
        checks.append({name: cond})

    prior_consent = engine.native_edits_consented()
    try:
        # 1. Consent gate: without consent, edit ops refuse.
        engine.set_native_edits_consented(False)
        res = engine.rebind_existing(context, "F19", True, True, True, "F20", True, True, True)
        check("no-consent blocks rebind", not res.get("ok") and res.get("error") == "needs_consent")

        # 2. After consent, the full round-trip (seeding a temp binding if needed).
        # ponytail: delegate to engine.demo_native which already owns this logic exactly.
        engine.set_native_edits_consented(True)
        demo = engine.demo_native(context)
        check("demo_native ok", demo.get("ok"))
        for sub in demo.get("checks", []):
            checks.append(sub)
    except Exception as e:
        ok = False
        checks.append({"exception": str(e)})
    finally:
        engine.set_native_edits_consented(prior_consent)

    return {"ok": ok, "checks": checks}


def register():
    _clear_handles()
    bpy.utils.register_class(KBD_OT_assign_dialog)
    bpy.utils.register_class(KBD_OT_native_consent)
    bpy.utils.register_class(KBD_OT_gpu_keyboard)
    bpy.utils.register_class(KBD_OT_keyboard_window)


def unregister():
    _clear_handles()
    library_db.close()
    bpy.utils.unregister_class(KBD_OT_keyboard_window)
    bpy.utils.unregister_class(KBD_OT_gpu_keyboard)
    bpy.utils.unregister_class(KBD_OT_native_consent)
    bpy.utils.unregister_class(KBD_OT_assign_dialog)
