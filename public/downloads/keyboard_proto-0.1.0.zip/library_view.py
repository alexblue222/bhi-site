"""Embedded SQL library table — the Action DB view folded into the keyboard, drawn
INSIDE the keyboard window's library region (not its own window).

Box-relative: draw(context, ox, oy, w, h, search) renders the sidebar + table within
that rectangle in absolute region coords; click/scroll/drag are delegated from the
keyboard's modal. Free-tier surface: quick filters, saved views (apply), source chips,
pin/favourite/hide, search (driven by the keyboard's search box), scroll + drag-resize.
Widget-based editing (inline cells, +Add Column) is the PAID Command Centre — not here.

Drawing uses the base's gpu_widgets toolkit directly (same process, no base_api hop).
"""
import blf

from . import gpu_widgets as gw
from . import library_db as db
from . import keymap_engine as engine

ROW_H = 22

# data + view state
_ROWS = []
_DIRTY = True
_LAST_SEARCH = object()          # sentinel so first draw always refreshes
_SCROLL = 0
_HSCROLL = 0
_FILTER = {"source": None, "quick": "all"}   # quick: all|pinned|favourite|hidden
_VIEW_NAME = None
_SHOW_HIDDEN = False
_COL_W = {}                      # drag-resize overrides by column key
_HOTKEYS = {}                    # idname -> hotkey label (from engine.bound_index)
_CAPTURE_ROW = None              # row awaiting an assign key-press (consumed by the keyboard)

# drag state
_DRAGGING = False                # vertical scrollbar
_DRAGGING_H = False              # horizontal scrollbar
_RESIZING = None                 # {"key","start_mx","start_w"}

# click-target rects (absolute), rebuilt each draw
_ROW_RECTS = []                  # [(rect, row, col)]
_CHIP_RECTS = []
_QUICK_RECTS = []
_VIEW_RECTS = []
_SRC_SCROLL = 0                  # scroll offset for the (often long) SOURCES list
_SIDEBAR_RECT = None             # sidebar hit-region — wheel here scrolls sources, not the table
_SHOW_HIDDEN_RECT = None
_SCROLLBAR = None
_HSCROLLBAR = None
_DIVIDER_RECTS = []


def invalidate():
    global _DIRTY
    _DIRTY = True


def take_capture():
    """The keyboard polls this: returns (and clears) a row queued for assign-key-capture."""
    global _CAPTURE_ROW
    r = _CAPTURE_ROW
    _CAPTURE_ROW = None
    return r


def capture_row():
    return _CAPTURE_ROW


def _refresh(search):
    global _ROWS, _DIRTY, _LAST_SEARCH
    kw = {"include_hidden": _SHOW_HIDDEN, "search": (search or None), "with_cells": True}
    if _VIEW_NAME:
        _ROWS = db.run_view(_VIEW_NAME)
    else:
        q = _FILTER["quick"]
        if q == "pinned":
            kw["pinned"] = True
        elif q == "favourite":
            kw["favourite"] = True
        elif q == "hidden":
            kw["hidden"] = True
            kw["include_hidden"] = True
        if _FILTER["source"]:
            kw["source"] = _FILTER["source"]
        _ROWS = db.query(**kw)
    _DIRTY = False
    _LAST_SEARCH = search


# --- glyphs (drawn, not fonts) ------------------------------------------------

def _pin(x, y, active):
    col = (0.95, 0.75, 0.2, 1.0) if active else (0.28, 0.30, 0.35, 1.0)
    gw.rect(x + 3, y + 8, 6, 6, col)
    gw.rect(x + 5, y + 2, 2, 7, col)


def _star(x, y, active):
    col = (0.95, 0.35, 0.45, 1.0) if active else (0.28, 0.30, 0.35, 1.0)
    gw.rect(x + 4, y + 2, 4, 10, col)
    gw.rect(x + 1, y + 5, 10, 4, col)
    gw.rect(x + 2, y + 3, 8, 2, col)
    gw.rect(x + 2, y + 9, 8, 2, col)


def _eye(x, y, hidden):
    col = (0.90, 0.45, 0.42, 1.0) if hidden else (0.42, 0.45, 0.51, 1.0)
    gw.rect(x + 1, y + 4, 11, 5, col)
    gw.rect(x + 3, y + 5, 7, 3, (0.12, 0.12, 0.15, 1.0))
    gw.rect(x + 5, y + 6, 3, 1, col)
    if hidden:
        gw.rect(x, y + 2, 13, 2, (0.95, 0.35, 0.35, 0.9))


# --- draw (all coords absolute, offset by ox/oy) ------------------------------

def draw(context, ox, oy, w, h, search, hotkeys=None):
    global _ROW_RECTS, _CHIP_RECTS, _QUICK_RECTS, _VIEW_RECTS, _SHOW_HIDDEN_RECT
    global _SCROLL, _HSCROLL, _SCROLLBAR, _HSCROLLBAR, _DIVIDER_RECTS
    if _DIRTY or search != _LAST_SEARCH:
        _refresh(search)
    _HOTKEYS = hotkeys if hotkeys is not None else engine.bound_index(context)

    pad = 10
    side_w = 176
    top = oy + h - 12

    # ---- top row: quick filters + show-hidden + count ----
    _QUICK_RECTS = []
    qx = ox + pad
    qy = top - 22
    for key, label in (("all", "All"), ("pinned", "Pinned"), ("favourite", "Favourites"), ("hidden", "Hidden")):
        on = (_FILTER["quick"] == key and not _VIEW_NAME)
        bw = gw.text_w(label, 12) + 20
        gw.draw_toggle((qx, qy, bw, 22), label, on)
        _QUICK_RECTS.append(((qx, qy, bw, 22), key))
        qx += bw + 6
    qx += 8
    shl = "Show hidden"
    shw = gw.text_w(shl, 12) + 20
    gw.draw_toggle((qx, qy, shw, 22), shl, _SHOW_HIDDEN, on_col=(0.45, 0.30, 0.55, 1.0))
    _SHOW_HIDDEN_RECT = (qx, qy, shw, 22)
    gw.text(qx + shw + 14, qy + 6, 12, (0.55, 0.57, 0.63, 1.0), f"{len(_ROWS)} actions")

    # ---- left sidebar: saved views + sources ----
    _VIEW_RECTS = []
    _CHIP_RECTS = []
    sx = ox + pad
    sy = qy - 28          # start the sidebar clearly BELOW the quick-filter band
    gw.rect(ox + pad - 4, oy + 6, side_w, sy - (oy + 6) + 4, (0.13, 0.13, 0.16, 0.96))
    views = db.list_views()
    if views:
        gw.text(sx, sy, 10, (0.5, 0.52, 0.58, 1.0), "SAVED VIEWS")
        sy -= 18
        for name, _q in views:
            on = (_VIEW_NAME == name)
            gw.draw_toggle((sx, sy - 18, side_w - 14, 20), name, on, on_col=(0.28, 0.42, 0.30, 1.0))
            _VIEW_RECTS.append(((sx, sy - 18, side_w - 14, 20), name))
            sy -= 22
        sy -= 8
    gw.text(sx, sy, 10, (0.5, 0.52, 0.58, 1.0), "SOURCES")
    sy -= 18
    srcs = db.all_sources()
    global _SRC_SCROLL, _SIDEBAR_RECT
    src_top = sy
    src_bot = oy + 24                      # leave a line for the "more" hint
    n_src_vis = max(1, int((src_top - src_bot) / 22))
    _SRC_SCROLL = max(0, min(_SRC_SCROLL, max(0, len(srcs) - n_src_vis)))
    _SIDEBAR_RECT = (ox + pad - 4, oy + 6, side_w, src_top - (oy + 6) + 16)
    for src in srcs[_SRC_SCROLL:_SRC_SCROLL + n_src_vis]:
        on = (_FILTER["source"] == src)
        gw.draw_toggle((sx, sy - 18, side_w - 14, 20), src, on)
        _CHIP_RECTS.append(((sx, sy - 18, side_w - 14, 20), src))
        sy -= 22
    more = len(srcs) - (_SRC_SCROLL + n_src_vis)
    if _SRC_SCROLL > 0 or more > 0:
        bits = []
        if _SRC_SCROLL > 0:
            bits.append("^%d" % _SRC_SCROLL)
        if more > 0:
            bits.append("%d more v" % more)
        gw.text(sx, oy + 10, 9, (0.5, 0.52, 0.58, 1.0), "scroll  " + "  ".join(bits))

    # ---- main table (sized columns, h-scroll, drag-resize) ----
    tbl_x = ox + pad + side_w + 8
    tbl_r = ox + w - pad
    tbl_top = qy - 28     # header sits below the quick-filter band (was overlapping it)
    tbl_bot = oy + 26
    tbl_w = tbl_r - tbl_x

    custom_cols = db.list_columns()
    assign_w = gw.text_w("Assign", 10) + 12
    cols_def = [("pin", 20, ""), ("fav", 20, ""), ("hide", 20, ""),
                ("assign", assign_w, ""), ("label", 280, "ACTION"),
                ("hotkey", 96, "HOTKEY"), ("source", 120, "SOURCE"),
                ("category", 120, "CATEGORY"), ("tags", 140, "TAGS")]
    for c in custom_cols:
        cols_def.append(("cell:" + c["name"], 120, c["name"]))
    cols = [(k, _COL_W.get(k, dw), lbl) for (k, dw, lbl) in cols_def]
    offs, acc = [], 0
    for _k, _w, _l in cols:
        offs.append(acc); acc += _w
    content_w = acc
    _DIVIDER_RECTS = []

    list_top = tbl_top - 6
    list_bot = tbl_bot
    n_vis = max(1, int((list_top - list_bot) / ROW_H))
    _SCROLL = max(0, min(_SCROLL, max(0, len(_ROWS) - n_vis)))
    has_vsb = len(_ROWS) > n_vis
    vgut = 14 if has_vsb else 0
    view_w = tbl_w - vgut
    max_hs = max(0, content_w - view_w)
    _HSCROLL = max(0, min(_HSCROLL, max_hs))
    has_hsb = content_w > view_w
    clip_r = tbl_x + view_w

    def cxof(i):
        return tbl_x + offs[i] - _HSCROLL

    def visible(cx, cw):
        return cx + cw > tbl_x and cx < clip_r

    blf.enable(0, blf.CLIPPING)
    blf.clipping(0, tbl_x, list_bot, clip_r, list_top + 16)

    # header
    for i, (key, cw, label) in enumerate(cols):
        cx = cxof(i)
        if not visible(cx, cw):
            continue
        if key == "pin":
            _pin(cx, tbl_top + 3, False)
        elif key == "fav":
            _star(cx, tbl_top + 3, False)
        elif key == "hide":
            _eye(cx, tbl_top + 3, False)
        elif label:
            hc = (0.68, 0.60, 0.85, 1.0) if key.startswith("cell:") else (0.5, 0.52, 0.58, 1.0)
            gw.text(cx + 2, tbl_top + 6, 11, hc, label)
        dvx = cx + cw - 1
        if tbl_x <= dvx <= clip_r:
            gw.rect(dvx, list_bot, 1, list_top - list_bot + 16, (0.24, 0.25, 0.30, 1.0))
            if key not in ("pin", "fav", "hide"):
                _DIVIDER_RECTS.append(((dvx - 3, list_bot, 7, list_top - list_bot + 16), key, cw))
                if _RESIZING and _RESIZING["key"] == key:
                    gw.rect(dvx - 1, list_bot, 3, list_top - list_bot + 16, (0.35, 0.6, 1.0, 1.0))
    gw.rect(tbl_x, tbl_top, view_w, 1, (0.3, 0.31, 0.36, 1.0))

    _ROW_RECTS = []
    for ri in range(_SCROLL, min(len(_ROWS), _SCROLL + n_vis)):
        r = _ROWS[ri]
        ry = list_top - (ri - _SCROLL + 1) * ROW_H
        is_hidden = bool(r["hidden"])
        if (ri - _SCROLL) % 2 == 0:
            gw.rect(tbl_x, ry, view_w, ROW_H, (0.145, 0.145, 0.17, 1.0))
        ta = 0.45 if (is_hidden and _SHOW_HIDDEN) else 1.0

        def tc(b):
            return (b[0], b[1], b[2], b[3] * ta)

        cells = r.get("cells", {})
        for i2, (key, cw, label) in enumerate(cols):
            cx = cxof(i2)
            if not visible(cx, cw):
                continue
            dx = cx + 4
            chars = max(1, int(cw / 7))
            if key == "pin":
                _pin(cx, ry + 5, r["pinned"]); _ROW_RECTS.append(((cx - 2, ry + 2, cw, ROW_H - 4), r, "pin"))
            elif key == "fav":
                _star(cx, ry + 5, r["favourite"]); _ROW_RECTS.append(((cx - 2, ry + 2, cw, ROW_H - 4), r, "fav"))
            elif key == "hide":
                _eye(cx, ry + 5, is_hidden); _ROW_RECTS.append(((cx - 2, ry + 2, cw, ROW_H - 4), r, "hide"))
            elif key == "assign":
                ac = (0.55, 0.75, 0.55, 1.0) if (_CAPTURE_ROW and _CAPTURE_ROW["idname"] == r["idname"]) \
                    else (0.35, 0.55, 0.35, 1.0)
                gw.text(dx, ry + 5, 10, ac, "Assign"); _ROW_RECTS.append(((cx, ry + 2, cw, ROW_H - 4), r, "assign"))
            elif key == "label":
                gw.text(dx, ry + 5, 12, tc((0.95, 0.96, 1.0, 1.0)), r["label"][:chars])
                _ROW_RECTS.append(((cx, ry, cw, ROW_H), r, "row"))
            elif key == "hotkey":
                gw.text(dx, ry + 5, 11, tc((0.75, 0.85, 0.65, 1.0)), _HOTKEYS.get(r["idname"], "")[:chars])
            elif key == "source":
                gw.text(dx, ry + 5, 11, tc((0.55, 0.7, 0.95, 1.0)), (r["source"] or "")[:chars])
            elif key == "category":
                gw.text(dx, ry + 5, 11,
                        tc((0.7, 0.85, 0.7, 1.0) if r["category"] else (0.4, 0.42, 0.47, 1.0)),
                        (r["category"] or "—")[:chars])
            elif key == "tags":
                tg = db.tags_for(r["idname"])
                gw.text(dx, ry + 5, 11, tc((0.6, 0.62, 0.68, 1.0)), (", ".join(tg))[:chars] if tg else "")
            elif key.startswith("cell:"):
                cval = cells.get(key[5:], "")
                gw.text(dx, ry + 5, 11, tc((0.75, 0.70, 0.90, 1.0)), (cval[:chars] if cval else "—"))
            dvx = cx + cw - 1
            if tbl_x <= dvx <= clip_r:
                gw.rect(dvx, ry, 1, ROW_H, (0.18, 0.18, 0.21, 1.0))

    blf.disable(0, blf.CLIPPING)

    # vertical scrollbar
    if has_vsb:
        track_x = tbl_r - 10
        track_h = list_top - list_bot
        thumb_h = max(24, track_h * n_vis / len(_ROWS))
        maxs = len(_ROWS) - n_vis
        frac = _SCROLL / maxs if maxs else 0
        thumb_top = list_top - frac * (track_h - thumb_h)
        gw.rect(track_x, list_bot, 6, track_h, (0.07, 0.07, 0.09, 1.0))
        gw.rect(track_x, thumb_top - thumb_h, 6, thumb_h,
                (0.45, 0.48, 0.55, 1.0) if _DRAGGING else (0.32, 0.34, 0.40, 1.0))
        _SCROLLBAR = {"track": (track_x - 5, list_bot, 16, track_h), "track_top": list_top,
                      "track_h": track_h, "thumb_h": thumb_h, "max_scroll": maxs}
    else:
        _SCROLLBAR = None

    # horizontal scrollbar
    if has_hsb:
        hy = list_bot - 12
        thumb_w = max(40, view_w * view_w / content_w)
        hf = _HSCROLL / max_hs if max_hs else 0
        thumb_x = tbl_x + hf * (view_w - thumb_w)
        gw.rect(tbl_x, hy, view_w, 6, (0.07, 0.07, 0.09, 1.0))
        gw.rect(thumb_x, hy, thumb_w, 6, (0.40, 0.42, 0.48, 1.0) if _DRAGGING_H else (0.30, 0.32, 0.38, 1.0))
        _HSCROLLBAR = {"track": (tbl_x, hy - 3, view_w, 12), "x": tbl_x, "w": view_w,
                       "thumb_w": thumb_w, "max": max_hs}
    else:
        _HSCROLLBAR = None

    gpu_state_reset()


def gpu_state_reset():
    try:
        import gpu
        gpu.state.blend_set('NONE')
    except Exception:
        pass


# --- interaction (delegated from the keyboard modal) --------------------------

def _scroll_from_mouse(my):
    global _SCROLL
    if not _SCROLLBAR:
        return
    tt, th, thu, maxs = (_SCROLLBAR["track_top"], _SCROLLBAR["track_h"],
                         _SCROLLBAR["thumb_h"], _SCROLLBAR["max_scroll"])
    usable = th - thu
    if maxs <= 0 or usable <= 0:
        _SCROLL = 0; return
    _SCROLL = max(0, min(maxs, round((tt - thu / 2 - my) / usable * maxs)))


def _hscroll_from_mouse(mx):
    global _HSCROLL
    if not _HSCROLLBAR:
        return
    x, wv, tw, mxs = (_HSCROLLBAR["x"], _HSCROLLBAR["w"], _HSCROLLBAR["thumb_w"], _HSCROLLBAR["max"])
    usable = wv - tw
    if mxs <= 0 or usable <= 0:
        _HSCROLL = 0; return
    _HSCROLL = max(0, min(mxs, round((mx - x - tw / 2) / usable * mxs)))


def handle_wheel(up, shift, mx=None, my=None):
    global _SCROLL, _HSCROLL, _SRC_SCROLL
    if _SIDEBAR_RECT and mx is not None and gw.hit(_SIDEBAR_RECT, mx, my):
        _SRC_SCROLL = max(0, _SRC_SCROLL + (-1 if up else 1))   # clamped in draw
        return
    if shift:
        _HSCROLL = max(0, _HSCROLL + (-60 if up else 60))
    else:
        _SCROLL = max(0, _SCROLL + (-3 if up else 3))


def handle_motion(mx, my):
    """Return True if a drag/resize consumed the motion."""
    global _COL_W
    if _DRAGGING:
        _scroll_from_mouse(my); return True
    if _DRAGGING_H:
        _hscroll_from_mouse(mx); return True
    if _RESIZING:
        _COL_W[_RESIZING["key"]] = max(40, _RESIZING["start_w"] + (mx - _RESIZING["start_mx"]))
        return True
    return False


def end_drag():
    global _DRAGGING, _DRAGGING_H, _RESIZING
    _DRAGGING = _DRAGGING_H = False
    _RESIZING = None


def handle_click(mx, my):
    """Route a LEFTMOUSE press at (mx,my). Return True if consumed."""
    global _DRAGGING, _DRAGGING_H, _RESIZING, _FILTER, _VIEW_NAME, _SHOW_HIDDEN, _CAPTURE_ROW
    if _SCROLLBAR and gw.hit(_SCROLLBAR["track"], mx, my):
        _DRAGGING = True; _scroll_from_mouse(my); return True
    if _HSCROLLBAR and gw.hit(_HSCROLLBAR["track"], mx, my):
        _DRAGGING_H = True; _hscroll_from_mouse(mx); return True
    for hr, key, wv in _DIVIDER_RECTS:
        if gw.hit(hr, mx, my):
            _RESIZING = {"key": key, "start_mx": mx, "start_w": wv}; return True
    if _SHOW_HIDDEN_RECT and gw.hit(_SHOW_HIDDEN_RECT, mx, my):
        _SHOW_HIDDEN = not _SHOW_HIDDEN; invalidate(); return True
    for r, key in _QUICK_RECTS:
        if gw.hit(r, mx, my):
            _FILTER["quick"] = key; _VIEW_NAME = None; invalidate(); return True
    for r, name in _VIEW_RECTS:
        if gw.hit(r, mx, my):
            _VIEW_NAME = None if _VIEW_NAME == name else name; invalidate(); return True
    for r, src in _CHIP_RECTS:
        if gw.hit(r, mx, my):
            _FILTER["source"] = None if _FILTER["source"] == src else src
            _VIEW_NAME = None; invalidate(); return True
    for r, row, col in _ROW_RECTS:
        if gw.hit(r, mx, my):
            if col in ("pin", "fav", "hide"):
                db.toggle(row["idname"], {"pin": "pinned", "fav": "favourite", "hide": "hidden"}[col])
                invalidate()
                return True
            if col == "assign":
                _CAPTURE_ROW = row       # keyboard picks this up and captures the next key
                return True
            return ("pick", row)         # label/row click → keyboard arms / changes / assigns
    return False
