"""Keyboard layout data + colour constants for the shortcut editor.

Pure data, no bpy. Two layouts:
- KEY_ROWS: the compact core block (used by the native N-panel).
- placed_keys(): the FULL keyboard (function row, typing block with proper-width
  modifiers, nav cluster, numpad) as grid-positioned keys, used by the GPU window.
  Full range matters because many add-on shortcuts live on the numpad / F-keys.

Each placed key: {"id","type","label","x","y","w"} where x/y are in key-units from
the top-left and w is width in key-units (height is always 1).
"""

# --- Colour constants (RGB 0..1) ---
FILL_BOUND = (0.22, 0.70, 0.38)      # green: bound under the active modifier filter
FILL_EMPTY = (0.13, 0.13, 0.15)      # dark: nothing bound under active filter
CONFLICT_COLOR = (1.00, 0.50, 0.05)  # orange: top-right conflict light

MOD_COLORS = {
    "shift": (0.25, 0.55, 1.00),     # blue
    "ctrl":  (0.90, 0.25, 0.25),     # red
    "alt":   (0.95, 0.80, 0.20),     # yellow
}
NONE_DOT = (0.75, 0.75, 0.78)

# --- compact core block (native N-panel) ---
KEY_ROWS = [
    [{"id": t, "type": t, "label": l} for t, l in r]
    for r in (
        [("ACCENT_GRAVE", "`"), ("ONE", "1"), ("TWO", "2"), ("THREE", "3"), ("FOUR", "4"),
         ("FIVE", "5"), ("SIX", "6"), ("SEVEN", "7"), ("EIGHT", "8"), ("NINE", "9"),
         ("ZERO", "0"), ("MINUS", "-"), ("EQUAL", "=")],
        [("Q", "Q"), ("W", "W"), ("E", "E"), ("R", "R"), ("T", "T"), ("Y", "Y"), ("U", "U"),
         ("I", "I"), ("O", "O"), ("P", "P"), ("LEFT_BRACKET", "["), ("RIGHT_BRACKET", "]")],
        [("A", "A"), ("S", "S"), ("D", "D"), ("F", "F"), ("G", "G"), ("H", "H"), ("J", "J"),
         ("K", "K"), ("L", "L"), ("SEMI_COLON", ";"), ("QUOTE", "'")],
        [("Z", "Z"), ("X", "X"), ("C", "C"), ("V", "V"), ("B", "B"), ("N", "N"), ("M", "M"),
         ("COMMA", ","), ("PERIOD", "."), ("SLASH", "/")],
    )
]


# --- full keyboard (GPU window) ---
def _build_full():
    keys = []

    def add(y, items, x0=0.0):
        x = x0
        for it in items:
            if it[0] == "gap":
                x += it[1]
                continue
            typ, label, w = it
            keys.append({"id": typ, "type": typ, "label": label, "x": x, "y": y, "w": w})
            x += w

    # function row
    add(0.0, [("ESC", "Esc", 1), ("gap", 1),
              ("F1", "F1", 1), ("F2", "F2", 1), ("F3", "F3", 1), ("F4", "F4", 1), ("gap", 0.5),
              ("F5", "F5", 1), ("F6", "F6", 1), ("F7", "F7", 1), ("F8", "F8", 1), ("gap", 0.5),
              ("F9", "F9", 1), ("F10", "F10", 1), ("F11", "F11", 1), ("F12", "F12", 1)])
    # number row
    add(1.25, [("ACCENT_GRAVE", "`", 1), ("ONE", "1", 1), ("TWO", "2", 1), ("THREE", "3", 1),
               ("FOUR", "4", 1), ("FIVE", "5", 1), ("SIX", "6", 1), ("SEVEN", "7", 1),
               ("EIGHT", "8", 1), ("NINE", "9", 1), ("ZERO", "0", 1), ("MINUS", "-", 1),
               ("EQUAL", "=", 1), ("BACK_SPACE", "Bksp", 2)])
    # tab row
    add(2.25, [("TAB", "Tab", 1.5), ("Q", "Q", 1), ("W", "W", 1), ("E", "E", 1), ("R", "R", 1),
               ("T", "T", 1), ("Y", "Y", 1), ("U", "U", 1), ("I", "I", 1), ("O", "O", 1),
               ("P", "P", 1), ("LEFT_BRACKET", "[", 1), ("RIGHT_BRACKET", "]", 1),
               ("BACK_SLASH", "\\", 1.5)])
    # home row
    add(3.25, [("CAPS_LOCK", "Caps", 1.75), ("A", "A", 1), ("S", "S", 1), ("D", "D", 1),
               ("F", "F", 1), ("G", "G", 1), ("H", "H", 1), ("J", "J", 1), ("K", "K", 1),
               ("L", "L", 1), ("SEMI_COLON", ";", 1), ("QUOTE", "'", 1), ("RET", "Enter", 2.25)])
    # shift row
    add(4.25, [("LEFT_SHIFT", "Shift", 2.25), ("Z", "Z", 1), ("X", "X", 1), ("C", "C", 1),
               ("V", "V", 1), ("B", "B", 1), ("N", "N", 1), ("M", "M", 1), ("COMMA", ",", 1),
               ("PERIOD", ".", 1), ("SLASH", "/", 1), ("RIGHT_SHIFT", "Shift", 2.75)])
    # ctrl/space row
    add(5.25, [("LEFT_CTRL", "Ctrl", 1.25), ("OSKEY", "Os", 1.25), ("LEFT_ALT", "Alt", 1.25),
               ("SPACE", "Space", 6.25), ("RIGHT_ALT", "Alt", 1.25), ("RIGHT_CTRL", "Ctrl", 1.25)])

    # nav cluster
    nx = 15.75
    add(1.25, [("INSERT", "Ins", 1), ("HOME", "Hm", 1), ("PAGE_UP", "PgU", 1)], x0=nx)
    add(2.25, [("DEL", "Del", 1), ("END", "End", 1), ("PAGE_DOWN", "PgD", 1)], x0=nx)
    add(4.25, [("gap", 1), ("UP_ARROW", "↑", 1)], x0=nx)
    add(5.25, [("LEFT_ARROW", "←", 1), ("DOWN_ARROW", "↓", 1), ("RIGHT_ARROW", "→", 1)], x0=nx)

    # numpad
    px = 19.25
    add(1.25, [("gap", 1), ("NUMPAD_SLASH", "/", 1), ("NUMPAD_ASTERIX", "*", 1), ("NUMPAD_MINUS", "-", 1)], x0=px)
    add(2.25, [("NUMPAD_7", "7", 1), ("NUMPAD_8", "8", 1), ("NUMPAD_9", "9", 1), ("NUMPAD_PLUS", "+", 1)], x0=px)
    add(3.25, [("NUMPAD_4", "4", 1), ("NUMPAD_5", "5", 1), ("NUMPAD_6", "6", 1)], x0=px)
    add(4.25, [("NUMPAD_1", "1", 1), ("NUMPAD_2", "2", 1), ("NUMPAD_3", "3", 1), ("NUMPAD_ENTER", "Ent", 1)], x0=px)
    add(5.25, [("NUMPAD_0", "0", 2), ("NUMPAD_PERIOD", ".", 1)], x0=px)

    return keys


_FULL = _build_full()


def placed_keys():
    return _FULL


def grid_extent():
    """(cols, rows) of the full keyboard in key-units."""
    cols = max(k["x"] + k["w"] for k in _FULL)
    rows = max(k["y"] for k in _FULL) + 1
    return cols, rows


def all_keys():
    """Flat list of every key (full keyboard) — used for state scans + source enumeration."""
    return _FULL
