"""UI layer for the visual keyboard editor: state, operators, and the panel.

Draws the core key block as native operator buttons whose icon encodes colour
state (via key_icons). The active Ctrl/Alt/Shift toggles act as BOTH the visual
filter (recolour the grid for that combo) AND the target combo for assign/clear.
"""
import bpy
from bpy.props import StringProperty, BoolProperty, PointerProperty

from . import keymap_engine as engine
from . import key_icons as icons
from . import key_layout as layout
from . import window

# --- per-redraw state cache -------------------------------------------------
# key_state() is moderately expensive, so we cache the full {key_id: state} map
# and only rebuild when the modifier filter or the Blender mode changes (or when
# an assign/clear invalidates it). Panel redraws on mouse-move stay cheap.
_states_cache = {"sig": None, "states": {}}


def invalidate():
    _states_cache["sig"] = None


def _active_mods(st):
    return {"shift": st.shift, "ctrl": st.ctrl, "alt": st.alt}


def _get_states(context, st):
    am = _active_mods(st)
    sig = (am["shift"], am["ctrl"], am["alt"], getattr(context, "mode", None))
    if _states_cache["sig"] != sig:
        states = {}
        for k in layout.all_keys():
            states[k["id"]] = engine.key_state(context, k["type"], am)
        _states_cache["sig"] = sig
        _states_cache["states"] = states
    return _states_cache["states"]


def _find_key(key_id):
    for k in layout.all_keys():
        if k["id"] == key_id:
            return k
    return None


def _combo_label(st):
    parts = []
    if st.ctrl:
        parts.append("Ctrl")
    if st.alt:
        parts.append("Alt")
    if st.shift:
        parts.append("Shift")
    return " + ".join(parts) + (" + " if parts else "")


def _redraw_all(context):
    for area in context.screen.areas:
        area.tag_redraw()


# --- state -------------------------------------------------------------------

def _on_filter_change(self, context):
    invalidate()


class KBD_State(bpy.types.PropertyGroup):
    shift: BoolProperty(name="Shift", default=False, update=_on_filter_change)
    ctrl: BoolProperty(name="Ctrl", default=False, update=_on_filter_change)
    alt: BoolProperty(name="Alt", default=False, update=_on_filter_change)
    selected_key: StringProperty(default="")
    assign_idname: StringProperty(name="Operator", default="")


# --- operators ---------------------------------------------------------------

class KBD_OT_select_key(bpy.types.Operator):
    bl_idname = "kbd.select_key"
    bl_label = "Select Key"
    bl_description = "Inspect this key's bindings"
    bl_options = {'INTERNAL'}

    key_id: StringProperty()

    def execute(self, context):
        context.window_manager.kbd_state.selected_key = self.key_id
        _redraw_all(context)
        return {'FINISHED'}


class KBD_OT_assign(bpy.types.Operator):
    bl_idname = "kbd.assign"
    bl_label = "Assign"
    bl_description = "Bind the operator to the selected key + active modifiers (addon keyconfig)"

    def execute(self, context):
        st = context.window_manager.kbd_state
        key = _find_key(st.selected_key)
        if not key:
            self.report({'WARNING'}, "No key selected")
            return {'CANCELLED'}
        if not st.assign_idname.strip():
            self.report({'WARNING'}, "Enter an operator id (e.g. transform.translate)")
            return {'CANCELLED'}
        res = engine.assign(
            st.assign_idname.strip(), key["type"],
            ctrl=st.ctrl, alt=st.alt, shift=st.shift,
        )
        if not res.get("ok"):
            self.report({'ERROR'}, res.get("error") or "assign failed")
            return {'CANCELLED'}
        invalidate()
        _redraw_all(context)
        self.report({'INFO'}, f"Assigned {res['idname']} to {_combo_label(st)}{key['label']}")
        return {'FINISHED'}


class KBD_OT_clear(bpy.types.Operator):
    bl_idname = "kbd.clear"
    bl_label = "Clear"
    bl_description = "Remove our assignment on the selected key + active modifiers"

    def execute(self, context):
        st = context.window_manager.kbd_state
        key = _find_key(st.selected_key)
        if not key:
            self.report({'WARNING'}, "No key selected")
            return {'CANCELLED'}
        res = engine.clear_assignment(key["type"], ctrl=st.ctrl, alt=st.alt, shift=st.shift)
        invalidate()
        _redraw_all(context)
        self.report({'INFO'}, f"Cleared {res.get('removed', 0)} assignment(s)")
        return {'FINISHED'}


class KBD_OT_open_window(bpy.types.Operator):
    bl_idname = "kbd.open_window"
    bl_label = "Open in New Window"
    bl_description = "Open the keyboard editor in its own window (drag to another monitor)"

    def execute(self, context):
        res = window.open_tool_window(context)
        if not res.get("ok"):
            self.report({'ERROR'}, res.get("error") or "could not open window")
            return {'CANCELLED'}
        self.report({'INFO'}, "Opened keyboard window — click the 'Keyboard' N-panel tab")
        return {'FINISHED'}


# --- panel -------------------------------------------------------------------

class KBD_PT_keyboard(bpy.types.Panel):
    bl_label = "Visual Keyboard"
    bl_idname = "KBD_PT_keyboard"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Keyboard"

    def draw(self, context):
        lay = self.layout
        st = context.window_manager.kbd_state
        am = _active_mods(st)

        # modifier filter / target toggles
        row = lay.row(align=True)
        row.prop(st, "ctrl", toggle=True)
        row.prop(st, "alt", toggle=True)
        row.prop(st, "shift", toggle=True)
        row.separator()
        row.operator("kbd.keyboard_window", text="", icon='DESKTOP')
        row.operator("kbd.open_window", text="", icon='WINDOW')

        # the key grid
        states = _get_states(context, st)
        grid = lay.column(align=True)
        grid.scale_y = 1.5
        for krow in layout.KEY_ROWS:
            r = grid.row(align=True)
            for key in krow:
                state = states.get(key["id"])
                icon_id = icons.get_icon_id(key["id"], state, am) if state else 0
                op = r.operator(
                    "kbd.select_key", text=key["label"],
                    icon_value=icon_id,
                    depress=(st.selected_key == key["id"]),
                )
                op.key_id = key["id"]

        # inspector / assignment
        box = lay.box()
        if st.selected_key:
            key = _find_key(st.selected_key)
            box.label(text=f"Key:  {key['label'] if key else st.selected_key}", icon='EVENT_OS')
            combos = engine.all_combo_bindings(context, st.selected_key)
            col = box.column(align=True)
            for name in ("none", "shift", "ctrl", "alt"):
                b = combos.get(name)
                pretty = {"none": "(plain)", "shift": "Shift", "ctrl": "Ctrl", "alt": "Alt"}[name]
                col.label(text=f"{pretty}:  {b['label'] if b else '—'}")
            box.separator()
            box.label(text=f"Target:  {_combo_label(st)}{key['label'] if key else ''}")
            box.prop(st, "assign_idname")
            r2 = box.row(align=True)
            r2.operator("kbd.assign", icon='ADD')
            r2.operator("kbd.clear", icon='X')
        else:
            box.label(text="Click a key to inspect / assign")


classes = (
    KBD_State,
    KBD_OT_select_key,
    KBD_OT_assign,
    KBD_OT_clear,
    KBD_OT_open_window,
    KBD_PT_keyboard,
)


def register():
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.WindowManager.kbd_state = PointerProperty(type=KBD_State)


def unregister():
    del bpy.types.WindowManager.kbd_state
    for c in reversed(classes):
        bpy.utils.unregister_class(c)
