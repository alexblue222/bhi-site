"""SQLite backend for the base's script library (folded in from Action DB).

A curation/visualisation MIRROR of the live operator scan — never the source of
truth (Blender is). Tables are deliberately separate so a re-sync never clobbers
user work:
  - actions      : scanned operators (idname/label/desc/source), refreshed each sync.
  - action_meta  : per-action curation (category/pinned/hidden/favourite/notes).
  - tags         : many-to-many action↔tag.
  - views        : saved filter configs.
  - columns/cell_values : user-defined custom columns (EAV). PAID-tier; present but the
    free embedded library doesn't expose editing them.

sqlite3 is stdlib (ships with Blender). DB file: <config>/keyboard_proto/library.db.
"""
import os
import json
import sqlite3

import bpy

_DIRNAME = "keyboard_proto"
_DBFILE = "library.db"
_conn = None


def _path():
    d = bpy.utils.user_resource('CONFIG', path=_DIRNAME, create=True)
    return os.path.join(d, _DBFILE)


def connect(path=None):
    global _conn
    if _conn is None:
        _conn = sqlite3.connect(path or _path())
        _conn.row_factory = sqlite3.Row
        _init_schema(_conn)
    return _conn


def close():
    global _conn
    if _conn is not None:
        try:
            _conn.commit()
            _conn.close()
        except Exception:
            pass
        _conn = None


_COLUMN_TYPES = frozenset(("category", "tag", "number", "text"))


def _init_schema(c):
    c.executescript("""
        CREATE TABLE IF NOT EXISTS actions(
            idname TEXT PRIMARY KEY, label TEXT, desc TEXT, source TEXT,
            last_seen INTEGER DEFAULT 1
        );
        CREATE TABLE IF NOT EXISTS action_meta(
            idname TEXT PRIMARY KEY, category TEXT,
            pinned INTEGER DEFAULT 0, hidden INTEGER DEFAULT 0,
            favourite INTEGER DEFAULT 0, notes TEXT DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS tags(idname TEXT, tag TEXT, UNIQUE(idname, tag));
        CREATE TABLE IF NOT EXISTS views(name TEXT PRIMARY KEY, query TEXT);
        CREATE TABLE IF NOT EXISTS columns(name TEXT PRIMARY KEY, type TEXT, position INTEGER DEFAULT 0);
        CREATE TABLE IF NOT EXISTS cell_values(idname TEXT, column TEXT, value TEXT, UNIQUE(idname, column));
    """)
    # self-heal: an earlier trimmed dev schema lacked these columns — add if missing.
    for tbl, col, decl in (("actions", "last_seen", "INTEGER DEFAULT 1"),
                           ("action_meta", "category", "TEXT"),
                           ("action_meta", "pinned", "INTEGER DEFAULT 0"),
                           ("action_meta", "notes", "TEXT DEFAULT ''")):
        try:
            c.execute(f"ALTER TABLE {tbl} ADD COLUMN {col} {decl}")
        except Exception:
            pass
    c.commit()


def sync(actions):
    """Upsert the scanned actions. User curation untouched. Returns row count."""
    c = connect()
    c.execute("UPDATE actions SET last_seen=0")
    c.executemany(
        """INSERT INTO actions(idname,label,desc,source,last_seen)
           VALUES(:idname,:label,:desc,:source,1)
           ON CONFLICT(idname) DO UPDATE SET
             label=excluded.label, desc=excluded.desc, source=excluded.source, last_seen=1""",
        [{"idname": a["idname"], "label": a["label"], "desc": a["desc"], "source": a["source"]}
         for a in actions],
    )
    c.commit()
    return c.execute("SELECT COUNT(*) FROM actions").fetchone()[0]


def _ensure_meta(c, idname):
    c.execute("INSERT OR IGNORE INTO action_meta(idname) VALUES(?)", (idname,))


def set_category(idname, category):
    c = connect(); _ensure_meta(c, idname)
    c.execute("UPDATE action_meta SET category=? WHERE idname=?", (category, idname)); c.commit()


def toggle(idname, field):
    assert field in ("pinned", "hidden", "favourite"), field
    c = connect(); _ensure_meta(c, idname)
    c.execute(f"UPDATE action_meta SET {field}=1-{field} WHERE idname=?", (idname,)); c.commit()


def set_notes(idname, notes):
    c = connect(); _ensure_meta(c, idname)
    c.execute("UPDATE action_meta SET notes=? WHERE idname=?", (notes, idname)); c.commit()


def add_tag(idname, tag):
    c = connect()
    c.execute("INSERT OR IGNORE INTO tags(idname,tag) VALUES(?,?)", (idname, tag)); c.commit()


def remove_tag(idname, tag):
    c = connect()
    c.execute("DELETE FROM tags WHERE idname=? AND tag=?", (idname, tag)); c.commit()


def tags_for(idname):
    c = connect()
    return [r["tag"] for r in c.execute("SELECT tag FROM tags WHERE idname=? ORDER BY tag", (idname,))]


def all_categories():
    c = connect()
    return [r["category"] for r in c.execute(
        "SELECT DISTINCT category FROM action_meta WHERE category IS NOT NULL AND category!='' ORDER BY category")]


def all_sources():
    c = connect()
    rows = [r["source"] for r in c.execute(
        "SELECT DISTINCT source FROM actions WHERE source IS NOT NULL AND source!='' ORDER BY source")]
    rest = [s for s in rows if s != "Blender"]
    return (["Blender"] if "Blender" in rows else []) + rest


def query(source=None, category=None, tag=None, pinned=None, hidden=None,
          favourite=None, search=None, include_hidden=False, with_cells=False):
    """Filtered action list joined with meta. Each row is a dict."""
    c = connect()
    sql = ["""SELECT a.idname, a.label, a.desc, a.source,
                     m.category, COALESCE(m.pinned,0) AS pinned,
                     COALESCE(m.hidden,0) AS hidden, COALESCE(m.favourite,0) AS favourite,
                     COALESCE(m.notes,'') AS notes
              FROM actions a LEFT JOIN action_meta m ON a.idname=m.idname"""]
    where, args = [], []
    if tag is not None:
        sql.append("JOIN tags t ON t.idname=a.idname")
        where.append("t.tag=?"); args.append(tag)
    if source:
        where.append("a.source=?"); args.append(source)
    if category:
        where.append("m.category=?"); args.append(category)
    if pinned is not None:
        where.append("COALESCE(m.pinned,0)=?"); args.append(1 if pinned else 0)
    if favourite is not None:
        where.append("COALESCE(m.favourite,0)=?"); args.append(1 if favourite else 0)
    if hidden is not None:
        where.append("COALESCE(m.hidden,0)=?"); args.append(1 if hidden else 0)
    elif not include_hidden:
        where.append("COALESCE(m.hidden,0)=0")
    if search:
        where.append("(a.label LIKE ? OR a.idname LIKE ? OR a.desc LIKE ?)")
        s = f"%{search}%"; args += [s, s, s]
    if where:
        sql.append("WHERE " + " AND ".join(where))
    sql.append("ORDER BY pinned DESC, favourite DESC, a.label")
    rows = [dict(r) for r in c.execute(" ".join(sql), args)]
    if with_cells and rows:
        idnames = [r["idname"] for r in rows]
        placeholders = ",".join("?" * len(idnames))
        cell_map = {}
        for cv in c.execute(
                f"SELECT idname,column,value FROM cell_values WHERE idname IN ({placeholders})", idnames):
            cell_map.setdefault(cv["idname"], {})[cv["column"]] = cv["value"]
        for r in rows:
            r["cells"] = cell_map.get(r["idname"], {})
    return rows


def save_view(name, query_dict):
    c = connect()
    c.execute("""INSERT INTO views(name,query) VALUES(?,?)
                 ON CONFLICT(name) DO UPDATE SET query=excluded.query""",
              (name, json.dumps(query_dict))); c.commit()


def delete_view(name):
    c = connect()
    c.execute("DELETE FROM views WHERE name=?", (name,)); c.commit()


def list_views():
    c = connect()
    return [(r["name"], json.loads(r["query"]))
            for r in c.execute("SELECT name,query FROM views ORDER BY name")]


def run_view(name):
    c = connect()
    r = c.execute("SELECT query FROM views WHERE name=?", (name,)).fetchone()
    return query(**json.loads(r["query"])) if r else []


def add_column(name, type):
    assert type in _COLUMN_TYPES, f"type must be one of {_COLUMN_TYPES}"
    c = connect()
    pos = (c.execute("SELECT COUNT(*) FROM columns").fetchone()[0])
    c.execute("INSERT OR IGNORE INTO columns(name,type,position) VALUES(?,?,?)", (name, type, pos)); c.commit()


def remove_column(name):
    c = connect()
    c.execute("DELETE FROM cell_values WHERE column=?", (name,))
    c.execute("DELETE FROM columns WHERE name=?", (name,)); c.commit()


def list_columns():
    c = connect()
    return [dict(r) for r in c.execute("SELECT name, type FROM columns ORDER BY position, name")]


def set_cell(idname, column, value):
    c = connect()
    c.execute("""INSERT INTO cell_values(idname,column,value) VALUES(?,?,?)
                 ON CONFLICT(idname,column) DO UPDATE SET value=excluded.value""",
              (idname, column, value)); c.commit()


def get_cells(idname):
    c = connect()
    return {r["column"]: r["value"]
            for r in c.execute("SELECT column,value FROM cell_values WHERE idname=?", (idname,))}


def column_values(name):
    c = connect()
    return [r["value"] for r in c.execute(
        "SELECT DISTINCT value FROM cell_values WHERE column=? AND value!='' ORDER BY value", (name,))]


def demo():
    """Headless self-check: sync, favourite/pin sort, hide excludes, meta survives re-sync."""
    close()
    connect(":memory:")
    try:
        scan1 = [{"idname": "mesh.foo", "label": "Foo", "desc": "d", "source": "Blender"},
                 {"idname": "obj.bar", "label": "Bar", "desc": "d2", "source": "Hard Ops"}]
        assert sync(scan1) == 2
        toggle("obj.bar", "favourite")
        assert query()[0]["idname"] == "obj.bar", "favourite sorts up"
        toggle("mesh.foo", "hidden")
        assert all(r["idname"] != "mesh.foo" for r in query()), "hidden excluded"
        set_category("obj.bar", "Modeling")
        assert "Modeling" in all_categories()
        sync([{"idname": "obj.bar", "label": "Bar v2", "desc": "d2", "source": "Hard Ops"},
              {"idname": "mesh.foo", "label": "Foo", "desc": "d", "source": "Blender"}])
        top = query()[0]
        assert top["idname"] == "obj.bar" and top["label"] == "Bar v2" and top["favourite"] == 1
        return {"ok": True, "sources": all_sources()}
    finally:
        close()
