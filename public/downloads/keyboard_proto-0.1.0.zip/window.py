"""Reusable 'open this tool in its own window' helper.

Lives at the package root (not inside the keyboard system) on purpose: the planned
dashboard will reuse the exact same mechanism. v1 hosts our panel inside a fresh
window's 3D-viewport N-panel region — a known-working approach, since add-ons can't
easily register a fully custom editor/space type. A real custom space type is a later
polish item (same bucket as the GPU-drawn keyboard).
"""
import bpy

# ponytail: new window = duplicate of current via wm.window_new, then coerce its biggest
# area to VIEW_3D and open the N-panel. Auto-selecting the "Keyboard" tab has no clean API,
# so we just open the sidebar and let the user click the tab once. Upgrade path: custom space type.


def _biggest_area(screen):
    best = None
    for area in screen.areas:
        if best is None or (area.width * area.height) > (best.width * best.height):
            best = area
    return best


def open_tool_window(context=None, category="Keyboard"):
    context = context or bpy.context
    wm = context.window_manager
    before = set(wm.windows)

    bpy.ops.wm.window_new()

    new_windows = [w for w in wm.windows if w not in before]
    if not new_windows:
        return {"ok": False, "error": "window_new created no new window"}
    win = new_windows[-1]

    try:
        area = _biggest_area(win.screen)
        if area is not None:
            if area.type != 'VIEW_3D':
                area.type = 'VIEW_3D'
            space = area.spaces.active
            if space is not None and hasattr(space, "show_region_ui"):
                space.show_region_ui = True
    except Exception as e:  # noqa: BLE001 - best-effort window coercion
        return {"ok": True, "warning": f"window opened but setup partial: {e!r}"}

    return {"ok": True}
