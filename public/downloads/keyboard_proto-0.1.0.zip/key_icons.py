"""Procedural 64x64 RGBA preview icons encoding each key's bound/conflict/variant state.

Native Blender buttons can't be tinted, but their icon can be any image, so we draw
the colour state into a preview icon and pass it as icon_value.

One previews collection, one persistent preview per key_id (pixels rewritten on change).

image_pixels_float origin is BOTTOM-LEFT: pixel index 0 is the bottom-left pixel,
rows go upward. _set(px, x, y, ...) takes y=0 as the BOTTOM row to match that.
"""

import bpy

from . import key_layout

SIZE = 64

# Module-level state
_pcoll = None
_previews_by_key = {}  # key_id -> bpy preview object (reused; pixels rewritten in place)
_sig_by_key = {}       # key_id -> last signature tuple (cache invalidation)


def init():
    """Create the previews collection (idempotent)."""
    global _pcoll
    if _pcoll is None:
        _pcoll = bpy.utils.previews.new()


def cleanup():
    """Remove the previews collection and clear caches. Safe if never inited."""
    global _pcoll
    if _pcoll is not None:
        bpy.utils.previews.remove(_pcoll)
        _pcoll = None
    _previews_by_key.clear()
    _sig_by_key.clear()


# --- Pixel helpers (y=0 is the BOTTOM row) ---

def _set(px, x, y, rgba):
    """Write an RGBA pixel at (x, y). y=0 = BOTTOM row (matches image_pixels_float)."""
    if 0 <= x < SIZE and 0 <= y < SIZE:
        i = (y * SIZE + x) * 4
        px[i:i + 4] = rgba


def _fill_rect(px, x0, y0, w, h, rgba):
    """Fill a w x h rect with lower-left corner at (x0, y0)."""
    for y in range(y0, y0 + h):
        for x in range(x0, x0 + w):
            _set(px, x, y, rgba)


def _build_pixels(state):
    """Return a flat list of floats (SIZE*SIZE*4) for the given state."""
    bg = key_layout.FILL_BOUND if state["bound"] else key_layout.FILL_EMPTY
    bg_rgba = [bg[0], bg[1], bg[2], 1.0]
    px = bg_rgba * (SIZE * SIZE)  # row-major, every pixel = background

    # 1px darker border so keys read as distinct tiles
    border = [bg[0] * 0.45, bg[1] * 0.45, bg[2] * 0.45, 1.0]
    for x in range(SIZE):
        _set(px, x, 0, border)          # bottom
        _set(px, x, SIZE - 1, border)   # top
    for y in range(SIZE):
        _set(px, 0, y, border)          # left
        _set(px, SIZE - 1, y, border)   # right

    # BOTTOM-LEFT: modifier-variant dots, stacked horizontally just inside the border.
    # ponytail: square dots, not circles — index math stays trivial.
    variants = state["variants"]
    dot = 10
    pad = 3          # gap from border / between dots
    x = 2
    y = 2            # sits along the bottom, inside the 1px border
    if variants.get("none"):
        _fill_rect(px, x, y, dot, dot, [*key_layout.NONE_DOT, 1.0])
        x += dot + pad
    for m in ("shift", "ctrl", "alt"):
        if variants.get(m):
            c = key_layout.MOD_COLORS[m]
            _fill_rect(px, x, y, dot, dot, [c[0], c[1], c[2], 1.0])
            x += dot + pad

    # TOP-RIGHT: conflict square. Top-right = high y, high x (origin is bottom-left).
    if state["conflict"]:
        sq = 12
        c = key_layout.CONFLICT_COLOR
        x0 = SIZE - 2 - sq      # right edge, inside border
        y0 = SIZE - 2 - sq      # top edge, inside border
        _fill_rect(px, x0, y0, sq, sq, [c[0], c[1], c[2], 1.0])

    return px


def _signature(state, active_mods):
    """Hashable cache key. Includes active_mods so a filter change forces a redraw."""
    v = state["variants"]
    return (
        bool(state["bound"]),
        bool(state["conflict"]),
        bool(v.get("none")), bool(v.get("shift")),
        bool(v.get("ctrl")), bool(v.get("alt")),
        bool(active_mods.get("shift")),
        bool(active_mods.get("ctrl")),
        bool(active_mods.get("alt")),
    )


def get_icon_id(key_id: str, state: dict, active_mods: dict) -> int:
    """Build/refresh this key's icon, return preview.icon_id (int). Lazy-inits."""
    if _pcoll is None:
        init()

    sig = _signature(state, active_mods)
    prev = _previews_by_key.get(key_id)

    if prev is not None and _sig_by_key.get(key_id) == sig:
        return prev.icon_id  # unchanged — no pixel rewrite

    if prev is None:
        prev = _pcoll.new(key_id)
        prev.image_size = (SIZE, SIZE)
        _previews_by_key[key_id] = prev

    prev.image_pixels_float = _build_pixels(state)
    _sig_by_key[key_id] = sig
    return prev.icon_id


def refresh_all(states: dict, active_mods: dict):
    """Regenerate icons for all {key_id: state}. Bulk refresh after a keymap change."""
    for key_id, state in states.items():
        get_icon_id(key_id, state, active_mods)
